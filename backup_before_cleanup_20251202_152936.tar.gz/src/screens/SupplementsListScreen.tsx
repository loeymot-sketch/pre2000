import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, TextInput } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Supplement } from '../types';
import { theme } from '../theme';
import { Card } from '../components/common/Card';
import { Tag } from '../components/common/Tag';
import { useNavigation } from '@react-navigation/native';

const SAFETY_CONFIG = {
    ok: { icon: '✓', label: 'OK', color: theme.colors.success, bgColor: '#E8F5E9' },
    a_surveiller: { icon: '⚠', label: 'À surveiller', color: theme.colors.warning, bgColor: '#FFF3E0' },
    deconseille: { icon: '✗', label: 'Déconseillé', color: theme.colors.error, bgColor: '#FFEBEE' },
};

export const SupplementsListScreen = () => {
    const [supplements, setSupplements] = useState<Supplement[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [loading, setLoading] = useState(true);
    const navigation = useNavigation<any>();

    useEffect(() => {
        const fetchSupplements = async () => {
            try {
                const snapshot = await getDocs(collection(db, 'supplements'));
                const fetchedSupplements = snapshot.docs.map(doc => doc.data() as Supplement);
                setSupplements(fetchedSupplements);
            } catch (error) {
                console.error('Error fetching supplements:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchSupplements();
    }, []);

    const filteredSupplements = React.useMemo(() => {
        if (!searchQuery.trim()) return supplements;

        const query = searchQuery.toLowerCase().trim();
        return supplements.filter(supplement => {
            const name = (supplement.name_fr || '').toLowerCase();
            const description = (supplement.short_description_fr || '').toLowerCase();
            const category = (supplement.category || '').toLowerCase();

            return name.includes(query) || description.includes(query) || category.includes(query);
        });
    }, [supplements, searchQuery]);

    const getSafetyConfig = (safety: string) => {
        return SAFETY_CONFIG[safety as keyof typeof SAFETY_CONFIG] || SAFETY_CONFIG.ok;
    };

    const renderItem = ({ item }: { item: Supplement }) => {
        const safetyConfig = getSafetyConfig(item.pregnancy_safety);

        return (
            <TouchableOpacity
                onPress={() => navigation.navigate('SupplementDetail', { supplementId: item.supplement_id })}
                activeOpacity={0.7}
            >
                <Card style={styles.card}>
                    <View style={[styles.safetyIndicator, { backgroundColor: safetyConfig.bgColor }]}>
                        <Text style={[styles.safetyIcon, { color: safetyConfig.color }]}>{safetyConfig.icon}</Text>
                        <Text style={[styles.safetyLabel, { color: safetyConfig.color }]}>{safetyConfig.label}</Text>
                    </View>
                    <View style={styles.content}>
                        <View style={styles.headerRow}>
                            <Text style={[theme.typography.h3, styles.title] as any}>{item.name_fr}</Text>
                        </View>
                        <View style={styles.categoryRow}>
                            <Text style={styles.categoryEmoji}>💊</Text>
                            <Text style={theme.typography.caption}>{item.category}</Text>
                        </View>
                        <Text numberOfLines={2} style={[theme.typography.body, styles.description]}>
                            {item.short_description_fr}
                        </Text>
                        <View style={styles.footer}>
                            <Text style={styles.readMore}>Voir détails →</Text>
                        </View>
                    </View>
                </Card>
            </TouchableOpacity>
        );
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.searchContainer}>
                <View style={styles.searchBar}>
                    <Text style={styles.searchIcon}>🔍</Text>
                    <TextInput
                        style={styles.searchInput}
                        placeholder="Rechercher un complément..."
                        placeholderTextColor="#999"
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                        returnKeyType="search"
                    />
                    {searchQuery.length > 0 && (
                        <TouchableOpacity onPress={() => setSearchQuery('')}>
                            <Text style={styles.clearIcon}>✕</Text>
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            <FlatList
                data={filteredSupplements}
                renderItem={renderItem}
                keyExtractor={item => item.supplement_id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                    <View style={styles.emptyState}>
                        <Text style={styles.emptyEmoji}>🤷‍♀️</Text>
                        <Text style={styles.emptyText}>Aucun complément trouvé pour "{searchQuery}"</Text>
                    </View>
                }
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    searchContainer: {
        padding: 16,
        backgroundColor: '#FFF',
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    searchBar: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F5F5F5',
        borderRadius: 12,
        paddingHorizontal: 12,
        height: 44,
    },
    searchIcon: {
        fontSize: 16,
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#333',
        height: '100%',
    },
    clearIcon: {
        fontSize: 16,
        color: '#999',
        padding: 4,
    },
    listContent: {
        padding: theme.spacing.m,
    },
    card: {
        marginBottom: theme.spacing.m,
        flexDirection: 'row',
        overflow: 'hidden',
    },
    safetyIndicator: {
        width: 70,
        alignItems: 'center',
        justifyContent: 'center',
        paddingVertical: theme.spacing.s,
    },
    safetyIcon: {
        fontSize: 28,
        fontWeight: 'bold',
        marginBottom: 4,
    },
    safetyLabel: {
        fontSize: 10,
        fontWeight: 'bold',
        textAlign: 'center',
    },
    content: {
        flex: 1,
        padding: theme.spacing.m,
    },
    headerRow: {
        marginBottom: theme.spacing.xs,
    },
    title: {
        marginBottom: theme.spacing.xs,
    },
    categoryRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: theme.spacing.s,
    },
    categoryEmoji: {
        fontSize: 14,
        marginRight: 4,
    },
    description: {
        color: theme.colors.textLight,
        lineHeight: 20,
    },
    footer: {
        marginTop: theme.spacing.s,
        flexDirection: 'row',
        alignItems: 'center',
    },
    readMore: {
        color: theme.colors.primary,
        fontSize: 14,
        fontWeight: 'bold',
    },
    emptyState: {
        alignItems: 'center',
        marginTop: 40,
        padding: 20,
    },
    emptyEmoji: {
        fontSize: 48,
        marginBottom: 16,
    },
    emptyText: {
        fontSize: 16,
        color: '#666',
        textAlign: 'center',
    },
});

