import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { theme } from '../theme';
import { useNavigation } from '@react-navigation/native';

export const AuthChoiceScreen = () => {
    const navigation = useNavigation<any>();

    return (
        <View style={styles.container}>
            <View style={styles.header}>
                <Text style={theme.typography.h1}>Commençons 🤰</Text>
                <Text style={[theme.typography.body, styles.subtitle]}>
                    Suivez votre grossesse jour après jour
                </Text>
            </View>

            <View style={styles.buttonsContainer}>
                <TouchableOpacity
                    style={[styles.button, styles.primaryButton]}
                    onPress={() => navigation.navigate('Register')}
                >
                    <Text style={styles.primaryButtonText}>Créer un compte</Text>
                    <Text style={styles.buttonSubtext}>Sauvegardez vos données</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={[styles.button, styles.secondaryButton]}
                    onPress={() => navigation.navigate('Login')}
                >
                    <Text style={styles.secondaryButtonText}>Se connecter</Text>
                </TouchableOpacity>

                <TouchableOpacity
                    style={styles.guestButton}
                    onPress={() => navigation.navigate('Onboarding')}
                >
                    <Text style={styles.guestButtonText}>Continuer en invité →</Text>
                </TouchableOpacity>
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
        padding: theme.spacing.l,
        justifyContent: 'center',
    },
    header: {
        alignItems: 'center',
        marginBottom: theme.spacing.xl,
    },
    subtitle: {
        marginTop: theme.spacing.s,
        textAlign: 'center',
        color: theme.colors.textLight,
    },
    buttonsContainer: {
        gap: theme.spacing.m,
    },
    button: {
        padding: theme.spacing.l,
        borderRadius: theme.borderRadius.m,
        alignItems: 'center',
    },
    primaryButton: {
        backgroundColor: theme.colors.primary,
    },
    primaryButtonText: {
        color: theme.colors.white,
        fontSize: 18,
        fontWeight: 'bold',
    },
    buttonSubtext: {
        color: theme.colors.white,
        fontSize: 14,
        marginTop: 4,
        opacity: 0.9,
    },
    secondaryButton: {
        backgroundColor: theme.colors.white,
        borderWidth: 2,
        borderColor: theme.colors.primary,
    },
    secondaryButtonText: {
        color: theme.colors.primary,
        fontSize: 18,
        fontWeight: 'bold',
    },
    guestButton: {
        padding: theme.spacing.m,
        alignItems: 'center',
    },
    guestButtonText: {
        color: theme.colors.textLight,
        fontSize: 16,
    },
});
