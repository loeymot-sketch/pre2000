import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity, Animated, Modal, Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useCurrentWeek } from '../services/useCurrentWeek';
import { useAuth } from '../context/AuthContext';
import { usePregnancy } from '../context/PregnancyContext';
import { theme } from '../theme';
import { Card } from '../components/common/Card';
import { SectionHeader } from '../components/common/SectionHeader';
import { useNavigation } from '@react-navigation/native';
import { getArticlesByIds, getSupplementsByIds } from '../services/contentService';
import { getUpcomingAppointments } from '../services/calendarService';
import { getTipForDay } from '../services/tipsService'; // ANTIGRAVITY
import { getMessageForDay } from '../services/babyMessageService'; // BABY MESSAGES
import { Article, Supplement, UserEvent, Tip, BabyMessage } from '../types';
import { format, addDays } from 'date-fns';
import { fr } from 'date-fns/locale';
// V3 NEW COMPONENTS
import { BabyFactsCard } from '../components/home/BabyFactsCard';
import { MomTipsCard } from '../components/home/MomTipsCard';
import { WeekRemindersCard } from '../components/home/WeekRemindersCard';
import { BabyMessageCard } from '../components/home/BabyMessageCard'; // Quick Win #1
import { CollapsibleCard } from '../components/common/CollapsibleCard'; // Reorganization

const { width } = Dimensions.get('window');

export const HomeScreen = () => {
    const [overrideWeek, setOverrideWeek] = useState<number | null>(null);
    const [overrideDay, setOverrideDay] = useState<number | null>(null);
    const { weekData, loading, error, currentWeekNumber, currentDay } = useCurrentWeek(overrideWeek ?? undefined);
    const { user, logout } = useAuth();
    const { profile } = usePregnancy();
    const navigation = useNavigation<any>();

    const [articles, setArticles] = useState<Article[]>([]);
    const [supplements, setSupplements] = useState<Supplement[]>([]);
    const [appointments, setAppointments] = useState<UserEvent[]>([]);
    const [dailyTip, setDailyTip] = useState<Tip | null>(null); // ANTIGRAVITY
    const [babyMessage, setBabyMessage] = useState<BabyMessage | null>(null); // BABY MESSAGES
    const [showProfileMenu, setShowProfileMenu] = useState(false);
    const [showPersonalData, setShowPersonalData] = useState(false);

    // Animation values
    const [fadeAnim] = useState(new Animated.Value(0));
    const [scaleAnim] = useState(new Animated.Value(0.95));
    const [pulseAnim] = useState(new Animated.Value(1));

    useEffect(() => {
        // Entrance animation
        Animated.parallel([
            Animated.timing(fadeAnim, {
                toValue: 1,
                duration: 600,
                useNativeDriver: true,
            }),
            Animated.spring(scaleAnim, {
                toValue: 1,
                tension: 50,
                friction: 7,
                useNativeDriver: true,
            }),
        ]).start();

        // Pulse animation for profile button
        Animated.loop(
            Animated.sequence([
                Animated.timing(pulseAnim, {
                    toValue: 1.05,
                    duration: 1000,
                    useNativeDriver: true,
                }),
                Animated.timing(pulseAnim, {
                    toValue: 1,
                    duration: 1000,
                    useNativeDriver: true,
                }),
            ])
        ).start();
    }, []);

    useEffect(() => {
        const fetchRecommendations = async () => {

            if (weekData) {
                // V3: Parse CSV string to array
                const articleIds = weekData.recommended_articles_ids
                    ? weekData.recommended_articles_ids.split(',').map(id => id.trim()).filter(id => id)
                    : [];
                const supplementIds = weekData.recommended_supplements_ids
                    ? weekData.recommended_supplements_ids.split(',').map(id => id.trim()).filter(id => id)
                    : [];



                if (articleIds.length > 0) {
                    const arts = await getArticlesByIds(articleIds);

                    setArticles([]);
                }

                if (supplementIds.length > 0) {
                    const supps = await getSupplementsByIds(supplementIds);

                    setSupplements([]);
                }
            }
        };
        fetchRecommendations();
    }, [weekData]);

    useEffect(() => {
        const fetchAppointments = async () => {
            if (user?.uid) {
                const apps = await getUpcomingAppointments(user.uid);
                setAppointments(apps);
            }
        };
        fetchAppointments();
    }, [user?.uid]);

    // ANTIGRAVITY: Fetch daily tip
    useEffect(() => {
        const fetchDailyTip = async () => {
            if (currentWeekNumber && (overrideDay || currentDay)) {
                const dayToUse = overrideDay || currentDay;
            }
        };
        fetchDailyTip();
    }, [currentWeekNumber, currentDay, overrideDay]);

    // BABY MESSAGES: Fetch daily message from baby (Quick Win #1)
    useEffect(() => {
        const fetchBabyMessage = async () => {
            if (currentWeekNumber && (overrideDay || currentDay)) {
                const dayToUse = overrideDay || currentDay;
            }
        };
        fetchBabyMessage();
    }, [currentWeekNumber, currentDay, overrideDay]);

    const handlePrevWeek = () => {
        if (currentWeekNumber > 1) {
            setOverrideWeek(currentWeekNumber - 1);
            // Animate transition
            Animated.sequence([
                Animated.timing(fadeAnim, { toValue: 0.7, duration: 150, useNativeDriver: true }),
                Animated.timing(fadeAnim, { toValue: 1, duration: 150, useNativeDriver: true }),
            ]).start();
        }
    };

    const handleNextWeek = () => {
        if (currentWeekNumber < 40) {
            setOverrideWeek(currentWeekNumber + 1);
            setOverrideDay(null); // Reset day when changing week
            // Animate transition
            Animated.sequence([
                Animated.timing(fadeAnim, { toValue: 0.7, duration: 150, useNativeDriver: true }),
                Animated.timing(fadeAnim, { toValue: 1, duration: 150, useNativeDriver: true }),
            ]).start();
        }
    };

    const handlePrevDay = () => {
        const currentDayToUse = overrideDay ?? currentDay;
        if (currentDayToUse > 1) {
            setOverrideDay(currentDayToUse - 1);
        } else if (currentWeekNumber > 1) {
            // Go to previous week, last day
            setOverrideWeek(currentWeekNumber - 1);
            setOverrideDay(7);
        }
    };

    const handleNextDay = () => {
        const currentDayToUse = overrideDay ?? currentDay;
        if (currentDayToUse < 7) {
            setOverrideDay(currentDayToUse + 1);
        } else if (currentWeekNumber < 40) {
            // Go to next week, first day
            setOverrideWeek(currentWeekNumber + 1);
            setOverrideDay(1);
        }
    };

    const handleLogout = async () => {
        setShowProfileMenu(false);
        await logout();
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color="#FF6B9D" />
                <Text style={[theme.typography.body, { marginTop: 16, color: theme.colors.textLight }]}>
                    Chargement de vos données...
                </Text>
            </View>
        );
    }

    if (error || !weekData) {
        return (
            <View style={styles.centerContainer}>
                <Text style={styles.errorEmoji}>😔</Text>
                <Text style={theme.typography.body}>{error || 'Aucune donnée disponible'}</Text>
            </View>
        );
    }

    const cleanTitle = weekData.title_fr.replace(/###\s*/g, '').trim();
    const babyFacts = weekData.baby_facts_fr?.split('•').filter(f => f.trim()).map(f => f.trim()) || [];
    const momTips = weekData.mom_tips_fr?.split('•').filter(t => t.trim()).map(t => t.trim()) || [];

    const displayName = profile?.firstName || user?.firstName || 'Belle maman';
    const userEmail = user?.email || 'Utilisateur invité';
    const trimesterText = weekData.trimester === 1 ? '1er' : weekData.trimester === 2 ? '2ème' : '3ème';

    const renderDayProgressBar = () => {
        const displayDay = overrideDay ?? currentDay;
        return (
            <View style={styles.progressContainer}>
                {/* Day Navigation */}
                <View style={styles.dayNavContainer}>
                    <TouchableOpacity
                        onPress={handlePrevDay}
                        disabled={currentWeekNumber === 1 && displayDay === 1}
                        style={styles.dayNavButton}
                    >
                        <Text style={[
                            styles.dayNavText,
                            (currentWeekNumber === 1 && displayDay === 1) && styles.disabledText
                        ]}>‹</Text>
                    </TouchableOpacity>

                    <View style={styles.progressBarWrapper}>
                        <View style={styles.progressBar}>
                            {[1, 2, 3, 4, 5, 6, 7].map((day) => (
                                <TouchableOpacity
                                    key={day}
                                    onPress={() => setOverrideDay(day)}
                                    style={[
                                        styles.progressSegment,
                                        day <= displayDay ? styles.progressSegmentActive : styles.progressSegmentInactive,
                                        day === 1 && styles.roundedLeft,
                                        day === 7 && styles.roundedRight,
                                        day === displayDay && {
                                            backgroundColor: '#FFFFFF',
                                            shadowColor: '#FFFFFF',
                                            shadowOffset: { width: 0, height: 0 },
                                            shadowOpacity: 0.8,
                                            shadowRadius: 4,
                                            elevation: 4,
                                        },
                                    ]}
                                />
                            ))}
                        </View>
                        <Text style={styles.progressText}>Jour {displayDay} / 7</Text>
                    </View>

                    <TouchableOpacity
                        onPress={handleNextDay}
                        disabled={currentWeekNumber === 40 && displayDay === 7}
                        style={styles.dayNavButton}
                    >
                        <Text style={[
                            styles.dayNavText,
                            (currentWeekNumber === 40 && displayDay === 7) && styles.disabledText
                        ]}>›</Text>
                    </TouchableOpacity>
                </View>
            </View>
        );
    };

    const renderRecommendationCard = ({ item }: { item: Article | Supplement }) => {
        const isArticle = 'article_id' in item;
        const title = isArticle ? (item as Article).title_fr : (item as Supplement).name_fr;
        const subtitle = isArticle ? (item as Article).category : 'Complément';

        return (
            <TouchableOpacity
                activeOpacity={0.8}
                onPress={() => {
                    if (isArticle) {
                        navigation.navigate('ArticleDetail', { articleId: (item as Article).article_id });
                    } else {
                        navigation.navigate('SupplementDetail', { supplementId: (item as Supplement).supplement_id });
                    }
                }}
            >
                <View style={styles.recommendationCard}>
                    <LinearGradient
                        colors={isArticle ? ['#FFE5F1', '#FFF0F7'] : ['#E3F2FD', '#F0F7FF']}
                        style={styles.recommendationGradient}
                    >
                        <View style={styles.recHeader}>
                            <Text style={styles.recEmoji}>{isArticle ? '📰' : '💊'}</Text>
                        </View>
                        <Text style={styles.recTitle} numberOfLines={2}>{title}</Text>
                        <View style={styles.recBadge}>
                            <Text style={styles.recBadgeText}>{subtitle}</Text>
                        </View>
                    </LinearGradient>
                </View>
            </TouchableOpacity>
        );
    };

    return (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
            {/* Gradient Header */}
            <LinearGradient
                colors={['#FF6B9D', '#C2185B', '#880E4F']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.headerGradient}
            >
                <Animated.View style={[styles.header, { opacity: fadeAnim, transform: [{ scale: scaleAnim }] }]}>
                    {/* Profile Button - Absolute Top Right */}
                    <Animated.View style={[styles.profileButtonContainer, { transform: [{ scale: pulseAnim }] }]}>
                        <TouchableOpacity
                            style={styles.profileButton}
                            onPress={() => setShowPersonalData(true)}
                            activeOpacity={0.8}
                        >
                            <LinearGradient
                                colors={['rgba(255, 255, 255, 0.3)', 'rgba(255, 255, 255, 0.1)']}
                                style={styles.profileGradient}
                            >
                                <Text style={styles.profileButtonText}>
                                    {displayName.charAt(0).toUpperCase()}
                                </Text>
                            </LinearGradient>
                        </TouchableOpacity>
                    </Animated.View>

                    {/* Centered Content */}
                    <View style={styles.centerContent}>
                        {/* Greeting */}
                        <Text style={styles.greeting}>
                            💖 Bonjour, {displayName}
                        </Text>

                        {/* Week Navigation */}
                        <View style={styles.weekNavContainer}>
                            <TouchableOpacity
                                onPress={handlePrevWeek}
                                disabled={currentWeekNumber <= 1}
                                style={styles.navButton}
                                activeOpacity={0.7}
                            >
                                <Text style={[styles.navButtonText, currentWeekNumber <= 1 && styles.disabledText]}>
                                    ‹
                                </Text>
                            </TouchableOpacity>
                            <View style={styles.weekBadge}>
                                <Text style={styles.weekTitle}>Semaine {currentWeekNumber}</Text>
                                <Text style={styles.trimesterBadge}>{trimesterText} Trimestre</Text>
                            </View>
                            <TouchableOpacity
                                onPress={handleNextWeek}
                                disabled={currentWeekNumber >= 40}
                                style={styles.navButton}
                                activeOpacity={0.7}
                            >
                                <Text style={[styles.navButtonText, currentWeekNumber >= 40 && styles.disabledText]}>
                                    ›
                                </Text>
                            </TouchableOpacity>
                        </View>

                        {/* Week Subtitle */}
                        <Text style={styles.weekSubtitle}>
                            {cleanTitle} {weekData.emoji}
                        </Text>

                        {/* Day Progress Bar */}
                        {renderDayProgressBar()}

                        {/* Minimal Quick Links - Single Row */}
                        <View style={styles.quickLinksRow}>
                            <TouchableOpacity onPress={() => navigation.navigate('Calendrier')} activeOpacity={0.7}>
                                <Text style={styles.quickLink}>📅 Mes RDV</Text>
                            </TouchableOpacity>
                            <Text style={styles.linkDivider}>•</Text>
                            <TouchableOpacity onPress={() => navigation.navigate('Rappels', { screen: 'RemindersMain', params: { screen: 'TasksTab' } })} activeOpacity={0.7}>
                                <Text style={styles.quickLink}>✓ Mes Tâches</Text>
                            </TouchableOpacity>
                            <Text style={styles.linkDivider}>•</Text>
                            <TouchableOpacity onPress={() => {
                                // Calculate date for the current view (Week + Day)
                                let targetDate = new Date();
                                if (profile?.lmp && currentWeekNumber) {
                                    const dayOffset = (overrideDay || currentDay || 1) - 1;
                                    const weekOffset = (currentWeekNumber - 1) * 7;
                                    targetDate = addDays(new Date(profile.lmp), weekOffset + dayOffset);
                                }

                                navigation.navigate('Calendrier', {
                                    screen: 'AddAppointment',
                                    params: { selectedDate: targetDate.toISOString() }
                                });
                            }} activeOpacity={0.7}>
                                <Text style={styles.quickLink}>➕ RDV</Text>
                            </TouchableOpacity>
                            <Text style={styles.linkDivider}>•</Text>
                            <TouchableOpacity onPress={() => navigation.navigate('Ressources', { screen: 'ResourcesMain', params: { openSearch: true } })} activeOpacity={0.7}>
                                <Text style={styles.quickLink}>🔍 Rechercher</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </Animated.View>
            </LinearGradient>

            {/* Personal Data Modal */}
            <Modal
                visible={showPersonalData}
                transparent
                animationType="slide"
                onRequestClose={() => setShowPersonalData(false)}
            >
                <View style={styles.modalOverlay}>
                    <View style={styles.personalDataModal}>
                        {/* Header */}
                        <LinearGradient
                            colors={['#FF6B9D', '#C2185B']}
                            style={styles.modalHeader}
                        >
                            <View style={styles.modalProfileCircle}>
                                <Text style={styles.modalProfileText}>
                                    {displayName.charAt(0).toUpperCase()}
                                </Text>
                            </View>
                            <Text style={styles.modalName}>{displayName}</Text>
                            <Text style={styles.modalEmail}>{userEmail}</Text>
                        </LinearGradient>

                        {/* Personal Data */}
                        <ScrollView style={styles.modalContent}>
                            <View style={styles.dataSection}>
                                <Text style={styles.sectionTitle}>📊 Informations Personnelles</Text>

                                <View style={styles.dataRow}>
                                    <Text style={styles.dataLabel}>Prénom</Text>
                                    <Text style={styles.dataValue}>{profile?.firstName || 'Non renseigné'}</Text>
                                </View>

                                <View style={styles.dataRow}>
                                    <Text style={styles.dataLabel}>Nom</Text>
                                    <Text style={styles.dataValue}>{profile?.lastName || 'Non renseigné'}</Text>
                                </View>

                                <View style={styles.dataRow}>
                                    <Text style={styles.dataLabel}>Pays</Text>
                                    <Text style={styles.dataValue}>{profile?.country || 'Non renseigné'}</Text>
                                </View>
                            </View>

                            <View style={styles.dataSection}>
                                <Text style={styles.sectionTitle}>🤰 Grossesse</Text>

                                <View style={styles.dataRow}>
                                    <Text style={styles.dataLabel}>Semaine actuelle</Text>
                                    <Text style={styles.dataValue}>{currentWeekNumber} / 40</Text>
                                </View>

                                <View style={styles.dataRow}>
                                    <Text style={styles.dataLabel}>Trimestre</Text>
                                    <Text style={styles.dataValue}>{trimesterText} Trimestre</Text>
                                </View>

                                {profile?.lmp && (
                                    <View style={styles.dataRow}>
                                        <Text style={styles.dataLabel}>Début de grossesse (LMP)</Text>
                                        <Text style={styles.dataValue}>
                                            {format(new Date(profile.lmp), 'dd MMMM yyyy', { locale: fr })}
                                        </Text>
                                    </View>
                                )}

                                {profile?.dpa && (
                                    <View style={styles.dataRow}>
                                        <Text style={styles.dataLabel}>Date prévue d'accouchement</Text>
                                        <Text style={[styles.dataValue, styles.highlightValue]}>
                                            {format(new Date(profile.dpa), 'dd MMMM yyyy', { locale: fr })}
                                        </Text>
                                    </View>
                                )}
                            </View>
                        </ScrollView>

                        {/* Actions */}
                        <View style={styles.modalActions}>
                            <TouchableOpacity
                                style={styles.modalActionButton}
                                onPress={() => {
                                    setShowPersonalData(false);
                                    navigation.navigate('Profile');
                                }}
                            >
                                <Text style={styles.modalActionIcon}>✏️</Text>
                                <Text style={styles.modalActionText}>Modifier</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.modalActionButton}
                                onPress={() => setShowPersonalData(false)}
                            >
                                <Text style={styles.modalActionIcon}>✖️</Text>
                                <Text style={styles.modalActionText}>Fermer</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={[styles.modalActionButton, styles.logoutButton]}
                                onPress={handleLogout}
                            >
                                <Text style={styles.modalActionIcon}>🚪</Text>
                                <Text style={[styles.modalActionText, styles.logoutText]}>Déconnexion</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            <View style={styles.contentContainer}>
                {/* GROUP 1: L'ESSENTIEL DU JOUR (Message + Tip) */}
                <View style={styles.sectionContainer}>
                    <Text style={styles.sectionTitleMain}>🌟 L'essentiel du jour</Text>

                    {/* Baby Message */}
                    {babyMessage && (
                        <BabyMessageCard
                            message={babyMessage.message_fr}
                            week={currentWeekNumber}
                            day={overrideDay || currentDay}
                        />
                    )}

                    {/* Daily Tip */}
                    {dailyTip && babyMessage && (
                        <View style={styles.divider} />
                    )}
                    {dailyTip && (
                        <View style={styles.unifiedContent}>
                            <View style={styles.tipHeader}>
                                <Text style={styles.tipEmoji}>💡</Text>
                                <Text style={styles.tipTitle}>Astuce du Jour</Text>
                            </View>
                            <Text style={styles.tipShort}>{dailyTip.short_fr}</Text>
                            <View style={styles.tipCategory}>
                                <Text style={styles.tipCategoryText}>🏷️ {dailyTip.category}</Text>
                            </View>
                        </View>
                    )}
                </View>

                {/* GROUP 2: CETTE SEMAINE (Insights + Body + Warnings) */}
                <View style={styles.sectionContainer}>
                    <Text style={styles.sectionTitleMain}>📅 Cette semaine</Text>

                    {/* Collapsible Cards */}
                    <CollapsibleCard
                        title="Bébé cette semaine"
                        emoji="🍼"
                        shortContent={weekData.baby_facts_short_fr || ''}
                        bullets={weekData.baby_facts_bullets_fr}
                        defaultExpanded={false}
                        accentColor="#FF6B9D"
                    />

                    <View style={styles.divider} />

                    <CollapsibleCard
                        title="Conseils pour toi"
                        emoji="💖"
                        shortContent={weekData.mom_tips_short_fr || ''}
                        bullets={weekData.mom_tips_bullets_fr}
                        defaultExpanded={false}
                        accentColor="#C2185B"
                    />

                    {/* Body Changes */}
                    <View style={styles.divider} />
                    <Animated.View style={{ opacity: fadeAnim }}>
                        <View style={styles.unifiedContent}>
                            <Text style={styles.cardTitle}>💆‍♀️ Votre Corps</Text>
                            <Text style={styles.cardDescription}>{weekData.mom_body_text_fr}</Text>
                        </View>
                    </Animated.View>

                    {/* Warnings */}
                    <View style={styles.divider} />
                    <Animated.View style={{ opacity: fadeAnim }}>
                        <View style={[styles.unifiedContent, styles.warningContainer]}>
                            <Text style={styles.warningTitle}>⚠️ À surveiller</Text>
                            <Text style={styles.cardDescription}>{weekData.warnings_text_fr}</Text>
                        </View>
                    </Animated.View>
                </View>

                {/* GROUP 3: ORGANISATION (Reminders + Appointments) */}
                <View style={styles.sectionContainer}>
                    <Text style={styles.sectionTitleMain}>📝 Organisation</Text>

                    <WeekRemindersCard
                        weekNumber={currentWeekNumber}
                        onViewAll={() => navigation.navigate('Rappels')}
                    />

                    {appointments.length > 0 && (
                        <>
                            <View style={styles.divider} />
                            <Animated.View style={{ opacity: fadeAnim }}>
                                <View style={styles.unifiedContent}>
                                    <SectionHeader
                                        title="📅 Prochains Rendez-vous"
                                        actionLabel="Voir tout"
                                        onAction={() => navigation.navigate('Calendrier')}
                                    />
                                    {appointments.slice(0, 2).map((app) => (
                                        <View key={app.event_id} style={styles.appointmentItem}>
                                            <View style={styles.appointmentDate}>
                                                <Text style={styles.appointmentDay}>{new Date(app.date).getDate()}</Text>
                                                <Text style={styles.appointmentMonth}>
                                                    {format(new Date(app.date), 'MMM', { locale: fr })}
                                                </Text>
                                            </View>
                                            <View style={styles.appointmentDetails}>
                                                <Text style={styles.appointmentTitle}>{app.title}</Text>
                                                <Text style={styles.appointmentTime}>
                                                    {format(new Date(app.date), 'HH:mm')}
                                                </Text>
                                            </View>
                                        </View>
                                    ))}
                                </View>
                            </Animated.View>
                        </>
                    )}
                </View>

                {/* 9. RECOMMENDATIONS (All Articles + Supplements) */}
                {([...articles, ...supplements].length > 0) && (
                    <Animated.View style={{ opacity: fadeAnim }}>
                        <SectionHeader
                            title="📚 Recommandations"
                            actionLabel="Tout voir"
                            onAction={() => navigation.navigate('Ressources')}
                        />

                        <ScrollView
                            horizontal
                            showsHorizontalScrollIndicator={false}
                            style={styles.recommendationsList}
                            contentContainerStyle={{ paddingRight: 16 }}
                        >
                            {[...articles, ...supplements].map((item, index) => (
                                <View key={index} style={{ marginRight: 12 }}>
                                    {renderRecommendationCard({ item })}
                                </View>
                            ))}
                        </ScrollView>
                    </Animated.View>
                )}
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    // NEW STYLES FOR UNIFIED DESIGN
    sectionContainer: {
        backgroundColor: '#FFFFFF',
        borderRadius: 24,
        padding: 20,
        marginBottom: 24,
        marginHorizontal: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.05,
        shadowRadius: 8,
        elevation: 2,
    },
    sectionTitleMain: {
        fontSize: 18,
        fontWeight: '700',
        color: '#1A1A1A',
        marginBottom: 16,
        marginLeft: 4,
    },
    unifiedCard: {
        marginBottom: 8,
    },
    unifiedContent: {
        paddingVertical: 8,
    },
    divider: {
        height: 1,
        backgroundColor: '#F0F0F0',
        marginVertical: 16,
    },
    warningContainer: {
        backgroundColor: '#FFF8F8',
        borderRadius: 12,
        padding: 12,
        marginTop: 8,
    },
    // EXISTING STYLES (Kept for compatibility)
    container: {
        flex: 1,
        backgroundColor: '#F8F9FA',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F8F9FA',
        padding: 20,
    },
    errorEmoji: {
        fontSize: 48,
        marginBottom: 16,
    },
    headerGradient: {
        paddingTop: 60,
        paddingBottom: 24,
        paddingHorizontal: 20,
        borderBottomLeftRadius: 30,
        borderBottomRightRadius: 30,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
    },
    header: {
        width: '100%',
        paddingBottom: 24,
    },
    profileButtonContainer: {
        position: 'absolute',
        top: 16,
        right: 16,
        zIndex: 10,
    },
    profileButton: {
        width: 50,
        height: 50,
        borderRadius: 25,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
    },
    profileGradient: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 3,
        borderColor: 'rgba(255, 255, 255, 0.5)',
        borderRadius: 28,
    },
    profileButtonText: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        fontSize: 24,
    },
    centerContent: {
        alignItems: 'center',
        width: '100%',
    },
    greeting: {
        fontSize: 18,
        color: '#FFFFFF',
        fontWeight: '600',
        marginBottom: 12,
        textAlign: 'center',
    },
    weekNavContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginBottom: 8,
    },
    navButton: {
        paddingHorizontal: 12,
        paddingVertical: 4,
    },
    navButtonText: {
        fontSize: 36,
        color: '#FFFFFF',
        fontWeight: 'bold',
    },
    disabledText: {
        color: 'rgba(255, 255, 255, 0.3)',
    },
    weekBadge: {
        alignItems: 'center',
        marginHorizontal: 16,
    },
    weekTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textAlign: 'center',
    },
    trimesterBadge: {
        fontSize: 12,
        color: 'rgba(255, 255, 255, 0.8)',
        fontWeight: '600',
        marginTop: 4,
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        paddingHorizontal: 8,
        paddingVertical: 2,
        borderRadius: 10,
    },
    weekSubtitle: {
        fontSize: 16,
        color: '#FFFFFF',
        textAlign: 'center',
        fontWeight: '600',
        marginTop: 4,
    },
    progressContainer: {
        marginTop: 16,
        width: '100%',
        alignItems: 'center',
    },
    dayNavContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        width: '90%',
        justifyContent: 'space-between',
    },
    dayNavButton: {
        padding: 8,
        minWidth: 40,
        alignItems: 'center',
        justifyContent: 'center',
    },
    dayNavText: {
        fontSize: 28,
        color: '#FFFFFF',
        fontWeight: 'bold',
    },
    progressBarWrapper: {
        flex: 1,
        alignItems: 'center',
        marginHorizontal: 8,
    },
    progressBar: {
        flexDirection: 'row',
        height: 10,
        width: '100%',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        borderRadius: 5,
        overflow: 'hidden',
    },
    progressSegment: {
        flex: 1,
        marginHorizontal: 1,
    },
    progressSegmentActive: {
        backgroundColor: '#FFFFFF',
    },
    progressSegmentInactive: {
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
    },
    roundedLeft: {
        borderTopLeftRadius: 5,
        borderBottomLeftRadius: 5,
    },
    roundedRight: {
        borderTopRightRadius: 5,
        borderBottomRightRadius: 5,
    },
    progressText: {
        fontSize: 13,
        color: 'rgba(255, 255, 255, 0.9)',
        marginTop: 8,
        fontWeight: '600',
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.6)',
        justifyContent: 'flex-end',
    },
    personalDataModal: {
        backgroundColor: '#FFFFFF',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
        maxHeight: '85%',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 10,
    },
    modalHeader: {
        paddingTop: 32,
        paddingBottom: 24,
        paddingHorizontal: 24,
        alignItems: 'center',
        borderTopLeftRadius: 30,
        borderTopRightRadius: 30,
    },
    modalProfileCircle: {
        width: 80,
        height: 80,
        borderRadius: 40,
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 4,
        borderColor: 'rgba(255, 255, 255, 0.5)',
        marginBottom: 16,
    },
    modalProfileText: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    modalName: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#FFFFFF',
        marginBottom: 4,
    },
    modalEmail: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    modalContent: {
        maxHeight: 400,
    },
    dataSection: {
        padding: 24,
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 16,
    },
    dataRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 12,
    },
    dataLabel: {
        fontSize: 15,
        color: '#666',
        flex: 1,
    },
    dataValue: {
        fontSize: 15,
        color: '#1A1A1A',
        fontWeight: '600',
        flex: 1,
        textAlign: 'right',
    },
    highlightValue: {
        color: '#FF6B9D',
        fontWeight: 'bold',
    },
    modalActions: {
        flexDirection: 'row',
        padding: 16,
        borderTopWidth: 1,
        borderTopColor: '#F0F0F0',
        gap: 12,
    },
    modalActionButton: {
        flex: 1,
        flexDirection: 'column',
        alignItems: 'center',
        padding: 12,
        borderRadius: 12,
        backgroundColor: '#F8F9FA',
    },
    modalActionIcon: {
        fontSize: 24,
        marginBottom: 4,
    },
    modalActionText: {
        fontSize: 12,
        fontWeight: '600',
        color: '#1A1A1A',
    },
    logoutButton: {
        backgroundColor: '#FFEBEE',
    },
    logoutText: {
        color: '#D32F2F',
    },
    contentContainer: {
        paddingBottom: 100,
    },
    quickNavContainer: {
        flexDirection: 'row',
        gap: 8,
        marginHorizontal: 16,
        marginTop: 12,
        marginBottom: 8,
        justifyContent: 'center',
    },
    quickNavButton: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: 'rgba(255, 255, 255, 0.25)',
        borderRadius: 8,
        paddingVertical: 6,
        paddingHorizontal: 12,
        gap: 4,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.4)',
    },
    quickNavIcon: {
        fontSize: 12,
    },
    quickNavLabel: {
        fontSize: 11,
        fontWeight: '600',
        color: '#FFF',
    },
    quickLinksRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        marginTop: 12,
        marginBottom: 12,
        gap: 8,
    },
    quickLink: {
        fontSize: 11,
        color: '#FFF',
        fontWeight: '600',
        opacity: 0.9,
    },
    linkDivider: {
        fontSize: 10,
        color: '#FFF',
        opacity: 0.5,
    },
    quickActionsContainer: {
        flexDirection: 'row',
        gap: 10,
        marginHorizontal: 16,
        marginTop: 12,
        marginBottom: 16,
    },
    quickActionButton: {
        flex: 1,
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#FFF',
        borderRadius: 12,
        paddingVertical: 10,
        paddingHorizontal: 14,
        gap: 6,
        shadowColor: '#000',
        shadowOpacity: 0.15,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
        elevation: 3,
    },
    quickActionIcon: {
        fontSize: 16,
    },
    quickActionLabel: {
        fontSize: 13,
        fontWeight: '700',
        color: '#C2185B',
    },
    glassCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        padding: 20,
        marginBottom: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
        elevation: 3,
    },
    quickFactsCard: {
        backgroundColor: '#F0F7FF',
        borderWidth: 1,
        borderColor: '#BBDEFB',
    },
    factsSection: {
        marginTop: 4,
    },
    factItem: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        marginBottom: 12,
    },
    factIconContainer: {
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        justifyContent: 'center',
        alignItems: 'center',
        marginRight: 12,
    },
    factIcon: {
        fontSize: 16,
    },
    factText: {
        flex: 1,
        fontSize: 15,
        color: '#1A1A1A',
        lineHeight: 22,
    },
    cardTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 12,
    },
    cardDescription: {
        fontSize: 15,
        color: '#4A4A4A',
        lineHeight: 22,
    },
    babyCard: {
        backgroundColor: '#FFF0F7',
        borderWidth: 1,
        borderColor: '#FFD6E8',
    },
    babyHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginBottom: 16,
    },
    babyInfo: {
        flex: 1,
    },
    babyStats: {
        flexDirection: 'row',
        gap: 12,
        marginTop: 8,
        marginBottom: 8,
    },
    statItem: {
        backgroundColor: 'rgba(255, 107, 157, 0.15)',
        paddingHorizontal: 14,
        paddingVertical: 10,
        borderRadius: 12,
    },
    statLabel: {
        fontSize: 11,
        color: '#888',
        fontWeight: '600',
        textTransform: 'uppercase',
    },
    statValue: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#C2185B',
        marginTop: 2,
    },
    babyLabel: {
        fontSize: 14,
        color: '#666',
        fontStyle: 'italic',
    },
    emojiContainer: {
        width: 100,
        height: 100,
        backgroundColor: '#FFFFFF',
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        shadowColor: '#FF6B9D',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 6,
        elevation: 4,
    },
    emojiLarge: {
        fontSize: 52,
    },
    emojiWeek: {
        fontSize: 12,
        color: '#888',
        fontWeight: 'bold',
        marginTop: 4,
    },
    warningCard: {
        backgroundColor: '#FFF8E1',
        borderWidth: 1,
        borderColor: '#FFE082',
    },
    warningTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#F57C00',
        marginBottom: 12,
    },
    appointmentItem: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    appointmentDate: {
        backgroundColor: '#E3F2FD',
        borderRadius: 14,
        padding: 14,
        alignItems: 'center',
        marginRight: 16,
        minWidth: 64,
    },
    appointmentDay: {
        fontSize: 26,
        fontWeight: 'bold',
        color: '#1976D2',
    },
    appointmentMonth: {
        fontSize: 11,
        color: '#1976D2',
        textTransform: 'uppercase',
        fontWeight: '600',
        marginTop: 2,
    },
    appointmentDetails: {
        flex: 1,
    },
    appointmentTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#1A1A1A',
        marginBottom: 4,
    },
    appointmentTime: {
        fontSize: 14,
        color: '#888',
    },
    recommendationsList: {
        marginTop: 12,
        marginBottom: 16,
    },
    recommendationCard: {
        width: width * 0.45,
        minWidth: 180,
        height: 140,
        borderRadius: 16,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.15,
        shadowRadius: 6,
        elevation: 4,
    },
    recommendationGradient: {
        flex: 1,
        padding: 16,
        justifyContent: 'space-between',
    },
    recHeader: {
        alignSelf: 'flex-start',
    },
    recEmoji: {
        fontSize: 32,
    },
    recTitle: {
        fontSize: 15,
        fontWeight: 'bold',
        color: '#1A1A1A',
        lineHeight: 20,
    },
    recSummary: {
        fontSize: 13,
        color: '#666',
        lineHeight: 18,
        marginTop: 6,
    },
    recBadge: {
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        paddingHorizontal: 10,
        paddingVertical: 4,
        borderRadius: 12,
        alignSelf: 'flex-start',
        marginTop: 8,
    },
    recBadgeText: {
        color: theme.colors.white,
        fontSize: 11,
        fontWeight: '600',
    },
    // ANTIGRAVITY: Tip Card Styles
    tipCard: {
        marginHorizontal: 16,
        marginBottom: 16,
        padding: 16,
        backgroundColor: '#FFF9E6',
        borderLeftWidth: 4,
        borderLeftColor: '#FFC107',
    },
    tipHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    tipEmoji: {
        fontSize: 24,
        marginRight: 8,
    },
    tipTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1A1A1A',
    },
    tipShort: {
        fontSize: 15,
        fontWeight: '600',
        color: '#333',
        marginBottom: 8,
        lineHeight: 22,
    },
    tipLong: {
        fontSize: 14,
        color: '#666',
        lineHeight: 20,
        marginBottom: 12,
    },
    tipCategory: {
        backgroundColor: '#FFF',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 12,
        alignSelf: 'flex-start',
    },
    tipCategoryText: {
        fontSize: 12,
        color: '#F57C00',
        fontWeight: '600',
    },
});
