import React, { useEffect, useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    ScrollView,
    TouchableOpacity,
    ActivityIndicator,
    TextInput,
    Modal,
} from 'react-native';
import { LineChart } from 'react-native-chart-kit';
import { Dimensions } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { usePregnancy } from '../context/PregnancyContext';
import { useNavigation } from '@react-navigation/native';
import {
    getHealthStats,
    getWeightHistory,
    getBloodPressureHistory,
    saveWeightEntry,
    saveBloodPressureEntry,
} from '../services/healthService';
import { HealthStats, HealthMetric } from '../types';
import { theme } from '../theme';

const screenWidth = Dimensions.get('window').width;

export const HealthDashboardScreen = () => {
    const { user } = useAuth();
    const { pregnancyInfo } = usePregnancy();
    const navigation = useNavigation<any>();

    const [stats, setStats] = useState<HealthStats | null>(null);
    const [weightHistory, setWeightHistory] = useState<HealthMetric[]>([]);
    const [bpHistory, setBpHistory] = useState<HealthMetric[]>([]);
    const [loading, setLoading] = useState(true);

    // Modals
    const [showWeightModal, setShowWeightModal] = useState(false);
    const [showBPModal, setShowBPModal] = useState(false);
    const [newWeight, setNewWeight] = useState('');
    const [newBPSystolic, setNewBPSystolic] = useState('');
    const [newBPDiastolic, setNewBPDiastolic] = useState('');

    useEffect(() => {
        loadData();
    }, [user?.uid, pregnancyInfo?.week]);

    const loadData = async () => {
        if (!user?.uid || !pregnancyInfo?.week) return;

        setLoading(true);
        try {
            const [healthStats, weights, bps] = await Promise.all([
                getHealthStats(user.uid, pregnancyInfo.week),
                getWeightHistory(user.uid),
                getBloodPressureHistory(user.uid),
            ]);

            setStats(healthStats);
            setWeightHistory(weights);
            setBpHistory(bps);
        } catch (error) {
            console.error('[HealthDashboard] Error loading data:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleAddWeight = async () => {
        if (!user?.uid || !pregnancyInfo?.week || !newWeight) return;

        try {
            await saveWeightEntry(user.uid, parseFloat(newWeight), new Date(), pregnancyInfo.week);
            setNewWeight('');
            setShowWeightModal(false);
            loadData(); // Refresh
        } catch (error) {
            console.error('[HealthDashboard] Error saving weight:', error);
        }
    };

    const handleAddBP = async () => {
        if (!user?.uid || !pregnancyInfo?.week || !newBPSystolic || !newBPDiastolic) return;

        try {
            await saveBloodPressureEntry(
                user.uid,
                parseInt(newBPSystolic),
                parseInt(newBPDiastolic),
                new Date(),
                pregnancyInfo.week
            );
            setNewBPSystolic('');
            setNewBPDiastolic('');
            setShowBPModal(false);
            loadData(); // Refresh
        } catch (error) {
            console.error('[HealthDashboard] Error saving BP:', error);
        }
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color="#FF6B9D" />
                <Text style={styles.loadingText}>Chargement...</Text>
            </View>
        );
    }

    const weightData = weightHistory.map(w => w.value as number);
    const weightLabels = weightHistory.map((w, i) => `S${w.week}`);

    return (
        <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
            {/* Header */}
            <LinearGradient colors={['#FF6B9D', '#C2185B']} style={styles.header}>
                <Text style={styles.headerTitle}>📊 Ma Santé</Text>
                <Text style={styles.headerSubtitle}>Semaine {pregnancyInfo?.week || '—'}</Text>
            </LinearGradient>

            {/* Section 1: Poids */}
            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>⚖️ Suivi de Poids</Text>
                    <TouchableOpacity style={styles.addButton} onPress={() => setShowWeightModal(true)}>
                        <Text style={styles.addButtonText}>+ Ajouter</Text>
                    </TouchableOpacity>
                </View>

                {weightHistory.length > 0 ? (
                    <>
                        <View style={styles.statsRow}>
                            <View style={styles.statBox}>
                                <Text style={styles.statLabel}>Actuel</Text>
                                <Text style={styles.statValue}>{stats?.weightCurrent || '—'} kg</Text>
                            </View>
                            <View style={styles.statBox}>
                                <Text style={styles.statLabel}>Gain</Text>
                                <Text style={[styles.statValue, { color: '#4CAF50' }]}>
                                    +{stats?.weightGain?.toFixed(1) || '0'} kg
                                </Text>
                            </View>
                        </View>

                        {weightData.length >= 2 && (
                            <LineChart
                                data={{
                                    labels: weightLabels.slice(-6), // Last 6 weeks
                                    datasets: [{ data: weightData.slice(-6) }],
                                }}
                                width={screenWidth - 48}
                                height={180}
                                chartConfig={{
                                    backgroundColor: '#FFF',
                                    backgroundGradientFrom: '#FFF',
                                    backgroundGradientTo: '#FFF',
                                    decimalPlaces: 1,
                                    color: (opacity = 1) => `rgba(255, 107, 157, ${opacity})`,
                                    labelColor: (opacity = 1) => `rgba(0, 0, 0, ${opacity})`,
                                    style: { borderRadius: 16 },
                                    propsForDots: {
                                        r: '4',
                                        strokeWidth: '2',
                                        stroke: '#FF6B9D',
                                    },
                                }}
                                bezier
                                style={styles.chart}
                            />
                        )}
                    </>
                ) : (
                    <Text style={styles.emptyText}>Aucune donnée. Ajoutez votre premier poids !</Text>
                )}
            </View>

            {/* Section 2: Tension */}
            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>💓 Tension Artérielle</Text>
                    <TouchableOpacity style={styles.addButton} onPress={() => setShowBPModal(true)}>
                        <Text style={styles.addButtonText}>+ Ajouter</Text>
                    </TouchableOpacity>
                </View>

                {bpHistory.length > 0 ? (
                    <>
                        <View style={styles.bpCard}>
                            <Text style={styles.bpLabel}>Dernière mesure</Text>
                            <Text style={styles.bpValue}>
                                {stats?.lastBP?.systolic || '—'} / {stats?.lastBP?.diastolic || '—'}
                            </Text>
                            <Text style={styles.bpDate}>
                                {stats?.lastBP?.date
                                    ? new Date(stats.lastBP.date).toLocaleDateString('fr-FR')
                                    : ''}
                            </Text>
                        </View>

                        {bpHistory.slice(0, 3).map((bp, index) => {
                            const value = bp.value as { systolic: number; diastolic: number };
                            return (
                                <View key={bp.metric_id} style={styles.bpHistoryItem}>
                                    <Text style={styles.bpHistoryValue}>
                                        {value.systolic} / {value.diastolic}
                                    </Text>
                                    <Text style={styles.bpHistoryDate}>
                                        {new Date(bp.date).toLocaleDateString('fr-FR')} • S{bp.week}
                                    </Text>
                                </View>
                            );
                        })}
                    </>
                ) : (
                    <Text style={styles.emptyText}>Aucune mesure. Ajoutez votre première tension !</Text>
                )}
            </View>

            {/* Section 3: Rendez-vous */}
            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>📅 Rendez-vous</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('CalendarScreen')}>
                        <Text style={styles.linkText}>Voir tout →</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.appointmentsRow}>
                    <View style={[styles.appointmentBox, { backgroundColor: '#E3F2FD' }]}>
                        <Text style={styles.appointmentNumber}>{stats?.upcomingAppointments || 0}</Text>
                        <Text style={styles.appointmentLabel}>À venir</Text>
                    </View>
                    <View style={[styles.appointmentBox, { backgroundColor: '#F3E5F5' }]}>
                        <Text style={styles.appointmentNumber}>{stats?.pastAppointments || 0}</Text>
                        <Text style={styles.appointmentLabel}>Passés</Text>
                    </View>
                </View>
            </View>

            {/* Section 4: Rappels */}
            <View style={[styles.section, { marginBottom: 40 }]}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>🔔 Rappels Cette Semaine</Text>
                    <TouchableOpacity onPress={() => navigation.navigate('Rappels')}>
                        <Text style={styles.linkText}>Voir tout →</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.progressContainer}>
                    <Text style={styles.progressText}>
                        {stats?.remindersCompletedThisWeek || 0} / {stats?.remindersTotalThisWeek || 0} complétés
                    </Text>
                    <View style={styles.progressBar}>
                        <View
                            style={[
                                styles.progressFill,
                                {
                                    width: `${((stats?.remindersCompletedThisWeek || 0) /
                                        (stats?.remindersTotalThisWeek || 1)) *
                                        100}%`,
                                },
                            ]}
                        />
                    </View>
                    <Text style={styles.progressPercentage}>
                        {Math.round(
                            ((stats?.remindersCompletedThisWeek || 0) / (stats?.remindersTotalThisWeek || 1)) * 100
                        )}
                        %
                    </Text>
                </View>
            </View>

            {/* Modal: Add Weight */}
            <Modal visible={showWeightModal} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modal}>
                        <Text style={styles.modalTitle}>Ajouter Poids</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Poids (kg)"
                            keyboardType="decimal-pad"
                            value={newWeight}
                            onChangeText={setNewWeight}
                        />
                        <View style={styles.modalActions}>
                            <TouchableOpacity
                                style={[styles.modalButton, styles.modalButtonCancel]}
                                onPress={() => {
                                    setShowWeightModal(false);
                                    setNewWeight('');
                                }}
                            >
                                <Text style={styles.modalButtonText}>Annuler</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={[styles.modalButton, styles.modalButtonSave]}
                                onPress={handleAddWeight}
                            >
                                <Text style={[styles.modalButtonText, { color: '#FFF' }]}>Enregistrer</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>

            {/* Modal: Add Blood Pressure */}
            <Modal visible={showBPModal} transparent animationType="slide">
                <View style={styles.modalOverlay}>
                    <View style={styles.modal}>
                        <Text style={styles.modalTitle}>Ajouter Tension</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Systolique (ex: 120)"
                            keyboardType="number-pad"
                            value={newBPSystolic}
                            onChangeText={setNewBPSystolic}
                        />
                        <TextInput
                            style={styles.input}
                            placeholder="Diastolique (ex: 80)"
                            keyboardType="number-pad"
                            value={newBPDiastolic}
                            onChangeText={setNewBPDiastolic}
                        />
                        <View style={styles.modalActions}>
                            <TouchableOpacity
                                style={[styles.modalButton, styles.modalButtonCancel]}
                                onPress={() => {
                                    setShowBPModal(false);
                                    setNewBPSystolic('');
                                    setNewBPDiastolic('');
                                }}
                            >
                                <Text style={styles.modalButtonText}>Annuler</Text>
                            </TouchableOpacity>
                            <TouchableOpacity
                                style={[styles.modalButton, styles.modalButtonSave]}
                                onPress={handleAddBP}
                            >
                                <Text style={[styles.modalButtonText, { color: '#FFF' }]}>Enregistrer</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                </View>
            </Modal>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8F9FA',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F8F9FA',
    },
    loadingText: {
        marginTop: 16,
        fontSize: 16,
        color: '#666',
    },
    header: {
        padding: 24,
        paddingTop: 40,
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFF',
    },
    headerSubtitle: {
        fontSize: 16,
        color: 'rgba(255, 255, 255, 0.9)',
        marginTop: 4,
    },
    section: {
        backgroundColor: '#FFF',
        margin: 16,
        padding: 20,
        borderRadius: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
    },
    sectionHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#333',
    },
    addButton: {
        backgroundColor: '#FF6B9D',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 12,
    },
    addButtonText: {
        color: '#FFF',
        fontSize: 14,
        fontWeight: '600',
    },
    linkText: {
        color: '#FF6B9D',
        fontSize: 14,
        fontWeight: '600',
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
        marginBottom: 20,
    },
    statBox: {
        alignItems: 'center',
    },
    statLabel: {
        fontSize: 14,
        color: '#999',
        marginBottom: 4,
    },
    statValue: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333',
    },
    chart: {
        marginVertical: 8,
        borderRadius: 16,
    },
    emptyText: {
        textAlign: 'center',
        color: '#999',
        fontSize: 14,
        fontStyle: 'italic',
        paddingVertical: 20,
    },
    bpCard: {
        backgroundColor: '#F3E5F5',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 16,
    },
    bpLabel: {
        fontSize: 14,
        color: '#666',
        marginBottom: 4,
    },
    bpValue: {
        fontSize: 32,
        fontWeight: 'bold',
        color: '#9C27B0',
    },
    bpDate: {
        fontSize: 12,
        color: '#999',
        marginTop: 4,
    },
    bpHistoryItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    bpHistoryValue: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
    },
    bpHistoryDate: {
        fontSize: 14,
        color: '#999',
    },
    appointmentsRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 12,
    },
    appointmentBox: {
        flex: 1,
        padding: 20,
        borderRadius: 12,
        alignItems: 'center',
    },
    appointmentNumber: {
        fontSize: 36,
        fontWeight: 'bold',
        color: '#333',
    },
    appointmentLabel: {
        fontSize: 14,
        color: '#666',
        marginTop: 4,
    },
    progressContainer: {
        alignItems: 'center',
    },
    progressText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
        marginBottom: 12,
    },
    progressBar: {
        width: '100%',
        height: 12,
        backgroundColor: '#E0E0E0',
        borderRadius: 6,
        overflow: 'hidden',
        marginBottom: 8,
    },
    progressFill: {
        height: '100%',
        backgroundColor: '#4CAF50',
    },
    progressPercentage: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#4CAF50',
    },
    modalOverlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modal: {
        width: '85%',
        backgroundColor: '#FFF',
        borderRadius: 20,
        padding: 24,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 5,
    },
    modalTitle: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 20,
        textAlign: 'center',
    },
    input: {
        borderWidth: 1,
        borderColor: '#E0E0E0',
        borderRadius: 12,
        padding: 12,
        fontSize: 16,
        marginBottom: 16,
    },
    modalActions: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        gap: 12,
    },
    modalButton: {
        flex: 1,
        padding: 14,
        borderRadius: 12,
        alignItems: 'center',
    },
    modalButtonCancel: {
        backgroundColor: '#F0F0F0',
    },
    modalButtonSave: {
        backgroundColor: '#FF6B9D',
    },
    modalButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
    },
});
