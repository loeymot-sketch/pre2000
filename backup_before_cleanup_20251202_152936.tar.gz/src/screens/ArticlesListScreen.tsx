import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity, ActivityIndicator, TextInput } from 'react-native';
import { collection, getDocs } from 'firebase/firestore';
import { LinearGradient } from 'expo-linear-gradient';
import { db } from '../config/firebase';
import { Article, ArticleAntigravity } from '../types';
import { getAntigravityArticlesByCategory } from '../services/contentService'; // ANTIGRAVITY
import { theme } from '../theme';
import { Card } from '../components/common/Card';
import { Tag } from '../components/common/Tag';
import { useNavigation, useRoute } from '@react-navigation/native';

const CATEGORY_ICONS: Record<string, string> = {
    nutrition: '🍎',
    examens: '🩺',
    sante: '❤️',
    developpement: '👶',
    preparation: '🎒',
    lifestyle: '🌸',
    administratif: '📄',
    medical: '⚕️',
};

export const ArticlesListScreen = () => {
    const [articles, setArticles] = useState<(Article | ArticleAntigravity)[]>([]);
    const [searchQuery, setSearchQuery] = useState('');
    const [loading, setLoading] = useState(true);
    const navigation = useNavigation<any>();
    const route = useRoute<any>();
    const searchInputRef = React.useRef<TextInput>(null);

    useEffect(() => {
        if (route.params?.openSearch && searchInputRef.current) {
            setTimeout(() => {
                searchInputRef.current?.focus();
            }, 500);
        }
    }, [route.params?.openSearch]);

    useEffect(() => {
        const fetchArticles = async () => {
            console.log('[ArticlesListScreen] 📚 Fetching all articles (old + Antigravity)...');
            try {
                // Fetch old articles
                console.log('[ArticlesListScreen] 🔍 Fetching old articles...');
                const oldSnapshot = await getDocs(collection(db, 'articles'));
                const oldArts = oldSnapshot.docs.map(doc => doc.data() as Article);
                console.log('[ArticlesListScreen] ✅ Loaded', oldArts.length, 'old articles');

                // ANTIGRAVITY: Fetch Antigravity articles
                console.log('[ArticlesListScreen] 🔍 Fetching Antigravity articles...');
                const agSnapshot = await getDocs(collection(db, 'articlesAntigravity'));
                const agArts = agSnapshot.docs.map(doc => doc.data() as ArticleAntigravity);
                console.log('[ArticlesListScreen] ✅ Loaded', agArts.length, 'Antigravity articles');

                // Merge both
                const allArticles = [...oldArts, ...agArts];
                console.log('[ArticlesListScreen] 📦 Total articles:', allArticles.length);
                setArticles(allArticles);
            } catch (error) {
                console.error('[ArticlesListScreen] ❌ Error fetching articles:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchArticles();
    }, []);

    const filteredArticles = React.useMemo(() => {
        if (!searchQuery.trim()) return articles;

        const query = searchQuery.toLowerCase().trim();
        return articles.filter(article => {
            const title = ('title_fr' in article ? article.title_fr : '').toLowerCase();
            const summary = ('summary_fr' in article ? article.summary_fr : '').toLowerCase();
            const category = (article.category || '').toLowerCase();

            return title.includes(query) || summary.includes(query) || category.includes(query);
        });
    }, [articles, searchQuery]);

    const getCategoryIcon = (category: string) => {
        return CATEGORY_ICONS[category] || '📚';
    };

    const renderItem = ({ item }: { item: Article | ArticleAntigravity }) => {
        // Handle both old and Antigravity article types
        const articleId = item.article_id;
        const title = 'title_fr' in item ? item.title_fr : '';
        const summary = 'summary_fr' in item ? item.summary_fr : '';
        const category = item.category;

        return (
            <TouchableOpacity
                onPress={() => navigation.navigate('ArticleDetail', { articleId })}
                activeOpacity={0.7}
            >
                <Card style={styles.card}>
                    <View style={styles.iconContainer}>
                        <Text style={styles.categoryIcon}>{getCategoryIcon(category)}</Text>
                    </View>
                    <View style={styles.content}>
                        <View style={styles.headerRow}>
                            <Text style={[theme.typography.h3, styles.title] as any}>{title}</Text>
                        </View>
                        <Tag label={category} />
                        <Text numberOfLines={2} style={[theme.typography.body, styles.summary]}>
                            {summary || 'En savoir plus...'}
                        </Text>
                        <View style={styles.footer}>
                            <Text style={styles.readMore}>Lire l'article →</Text>
                        </View>
                    </View>
                </Card>
            </TouchableOpacity>
        );
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <View style={styles.searchContainer}>
                <View style={styles.searchBar}>
                    <Text style={styles.searchIcon}>🔍</Text>
                    <TextInput
                        ref={searchInputRef}
                        style={styles.searchInput}
                        placeholder="Rechercher un article..."
                        placeholderTextColor="#999"
                        value={searchQuery}
                        onChangeText={setSearchQuery}
                        returnKeyType="search"
                    />
                    {searchQuery.length > 0 && (
                        <TouchableOpacity onPress={() => setSearchQuery('')}>
                            <Text style={styles.clearIcon}>✕</Text>
                        </TouchableOpacity>
                    )}
                </View>
            </View>

            <FlatList<Article | ArticleAntigravity>
                data={filteredArticles}
                renderItem={renderItem}
                keyExtractor={item => item.article_id}
                contentContainerStyle={styles.listContent}
                showsVerticalScrollIndicator={false}
                ListEmptyComponent={
                    <View style={styles.emptyState}>
                        <Text style={styles.emptyEmoji}>🤷‍♀️</Text>
                        <Text style={styles.emptyText}>Aucun article trouvé pour "{searchQuery}"</Text>
                    </View>
                }
            />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    searchContainer: {
        padding: 16,
        backgroundColor: '#FFF',
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    searchBar: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#F5F5F5',
        borderRadius: 12,
        paddingHorizontal: 12,
        height: 44,
    },
    searchIcon: {
        fontSize: 16,
        marginRight: 8,
    },
    searchInput: {
        flex: 1,
        fontSize: 16,
        color: '#333',
        height: '100%',
    },
    clearIcon: {
        fontSize: 16,
        color: '#999',
        padding: 4,
    },
    listContent: {
        padding: theme.spacing.m,
    },
    card: {
        marginBottom: theme.spacing.m,
        flexDirection: 'row',
        overflow: 'hidden',
    },
    iconContainer: {
        width: 70,
        backgroundColor: theme.colors.secondary,
        alignItems: 'center',
        justifyContent: 'center',
    },
    categoryIcon: {
        fontSize: 32,
    },
    content: {
        flex: 1,
        padding: theme.spacing.m,
    },
    headerRow: {
        marginBottom: theme.spacing.xs,
    },
    title: {
        marginBottom: theme.spacing.xs,
    },
    summary: {
        marginTop: theme.spacing.s,
        color: theme.colors.textLight,
        lineHeight: 20,
    },
    footer: {
        marginTop: theme.spacing.s,
        flexDirection: 'row',
        alignItems: 'center',
    },
    readMore: {
        color: theme.colors.primary,
        fontSize: 14,
        fontWeight: 'bold',
    },
    emptyState: {
        alignItems: 'center',
        marginTop: 40,
        padding: 20,
    },
    emptyEmoji: {
        fontSize: 48,
        marginBottom: 16,
    },
    emptyText: {
        fontSize: 16,
        color: '#666',
        textAlign: 'center',
    },
});

