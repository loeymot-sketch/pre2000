import React, { useState } from 'react';
import {
    View,
    Text,
    StyleSheet,
    TextInput,
    TouchableOpacity,
    Platform,
    ScrollView,
    Alert,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import { usePregnancy } from '../context/PregnancyContext';
import { saveUserEvent, calculateWeekFromDate } from '../services/calendarService';
import { theme } from '../theme';





export const AddAppointmentScreen = () => {
    const navigation = useNavigation();
    const route = useRoute<any>();
    const { user } = useAuth();
    const { profile } = usePregnancy();
    const { showToast } = useToast();

    const [title, setTitle] = useState('');
    const [type, setType] = useState<'medical' | 'other'>('medical');
    const [date, setDate] = useState(
        route.params?.selectedDate
            ? new Date(route.params.selectedDate)
            : new Date()
    );
    const [location, setLocation] = useState('');
    const [notes, setNotes] = useState('');
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [showTimePicker, setShowTimePicker] = useState(false);
    const [saving, setSaving] = useState(false);

    const handleDateChange = (event: any, selectedDate?: Date) => {
        setShowDatePicker(Platform.OS === 'ios');
        if (selectedDate) {
            const newDate = new Date(date);
            newDate.setFullYear(selectedDate.getFullYear(), selectedDate.getMonth(), selectedDate.getDate());
            setDate(newDate);
        }
    };

    const handleTimeChange = (event: any, selectedDate?: Date) => {
        setShowTimePicker(Platform.OS === 'ios');
        if (selectedDate) {
            const newDate = new Date(date);
            newDate.setHours(selectedDate.getHours(), selectedDate.getMinutes());
            setDate(newDate);
        }
    };

    const handleSave = async () => {
        if (!title.trim()) {
            Alert.alert('Erreur', 'Veuillez entrer un titre pour le rendez-vous');
            return;
        }

        if (!user?.uid || !profile?.lmp) {
            Alert.alert('Erreur', 'Informations utilisateur manquantes');
            return;
        }

        // Optimistic Update: Navigate back immediately
        showToast('Rendez-vous ajouté !', 'success');
        navigation.goBack();

        // Perform save in background
        try {
            const lmpDate = new Date(profile.lmp);
            const week = calculateWeekFromDate(lmpDate, date);

            await saveUserEvent({
                user_id: user.uid,
                title: title.trim(),
                date: date.toISOString(),
                week,
                type: 'appointment',
                location: location.trim() || undefined,
                notes: notes.trim() || undefined,
            });
            console.log('Appointment saved successfully in background');
        } catch (error) {
            console.error('Error saving appointment in background:', error);
        }
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
            <View style={styles.header}>
                <Text style={styles.headerTitle}>Nouveau Rendez-vous</Text>
                <Text style={styles.headerSubtitle}>Ajoutez un rendez-vous personnel à votre calendrier</Text>
            </View>

            <View style={styles.form}>
                {/* Title Input */}
                <View style={styles.inputGroup}>
                    <Text style={styles.label}>Titre *</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Ex: Échographie, Consultation..."
                        placeholderTextColor={theme.colors.textLight}
                        value={title}
                        onChangeText={setTitle}
                        maxLength={100}
                    />
                </View>

                {/* Type Selector */}
                <View style={styles.inputGroup}>
                    <Text style={styles.label}>Type</Text>
                    <View style={styles.typeContainer}>
                        <TouchableOpacity
                            style={[styles.typeButton, type === 'medical' && styles.typeButtonActive]}
                            onPress={() => setType('medical')}
                        >
                            <Text style={[styles.typeText, type === 'medical' && styles.typeTextActive]}>Médical 🩺</Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[styles.typeButton, type === 'other' && styles.typeButtonActive]}
                            onPress={() => setType('other')}
                        >
                            <Text style={[styles.typeText, type === 'other' && styles.typeTextActive]}>Autre 📅</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                {/* Date & Time Pickers Row */}
                <View style={styles.row}>
                    <View style={[styles.inputGroup, { flex: 1 }]}>
                        <Text style={styles.label}>Date *</Text>
                        <TouchableOpacity
                            style={styles.dateButton}
                            onPress={() => setShowDatePicker(true)}
                        >
                            <Text style={styles.dateText}>
                                {date.toLocaleDateString('fr-FR')}
                            </Text>
                        </TouchableOpacity>
                        {showDatePicker && (
                            <DateTimePicker
                                value={date}
                                mode="date"
                                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                onChange={handleDateChange}
                                minimumDate={new Date()}
                            />
                        )}
                    </View>

                    <View style={[styles.inputGroup, { flex: 1 }]}>
                        <Text style={styles.label}>Heure *</Text>
                        <TouchableOpacity
                            style={styles.dateButton}
                            onPress={() => setShowTimePicker(true)}
                        >
                            <Text style={styles.dateText}>
                                {date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                            </Text>
                        </TouchableOpacity>
                        {showTimePicker && (
                            <DateTimePicker
                                value={date}
                                mode="time"
                                display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                                onChange={handleTimeChange}
                            />
                        )}
                    </View>
                </View>

                {/* Location Input */}
                <View style={styles.inputGroup}>
                    <Text style={styles.label}>Lieu / Adresse</Text>
                    <TextInput
                        style={styles.input}
                        placeholder="Ex: Clinique des Orangers, Alger..."
                        placeholderTextColor={theme.colors.textLight}
                        value={location}
                        onChangeText={setLocation}
                        maxLength={200}
                    />
                </View>

                {/* Notes Input */}
                <View style={styles.inputGroup}>
                    <Text style={styles.label}>Notes (optionnel)</Text>
                    <TextInput
                        style={[styles.input, styles.notesInput]}
                        placeholder="Ajoutez des notes ou détails..."
                        placeholderTextColor={theme.colors.textLight}
                        value={notes}
                        onChangeText={setNotes}
                        multiline
                        numberOfLines={4}
                        maxLength={500}
                    />
                </View>

                {/* Action Buttons */}
                <View style={styles.actions}>
                    <TouchableOpacity
                        style={[styles.button, styles.cancelButton]}
                        onPress={() => navigation.goBack()}
                        disabled={saving}
                    >
                        <Text style={styles.cancelButtonText}>Annuler</Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                        style={[styles.button, styles.saveButton, saving && styles.saveButtonDisabled]}
                        onPress={handleSave}
                        disabled={saving}
                    >
                        <Text style={styles.saveButtonText}>
                            {saving ? 'Enregistrement...' : 'Enregistrer'}
                        </Text>
                    </TouchableOpacity>
                </View>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    contentContainer: {
        padding: theme.spacing.l,
    },
    header: {
        marginBottom: theme.spacing.xl,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: '700' as const,
        marginBottom: theme.spacing.xs,
        color: theme.colors.text,
    },
    headerSubtitle: {
        ...theme.typography.body,
        color: theme.colors.textLight,
    },
    form: {
        gap: theme.spacing.l,
    },
    row: {
        flexDirection: 'row',
        gap: theme.spacing.m,
    },
    inputGroup: {
        marginBottom: theme.spacing.m,
    },
    label: {
        fontSize: 14,
        fontWeight: '600' as const,
        marginBottom: theme.spacing.xs,
        color: theme.colors.text,
    },
    input: {
        ...theme.typography.body,
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: 12,
        padding: theme.spacing.m,
        backgroundColor: theme.colors.white,
    },
    notesInput: {
        height: 120,
        textAlignVertical: 'top',
    },
    dateButton: {
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: 12,
        padding: theme.spacing.m,
        backgroundColor: theme.colors.white,
    },
    dateText: {
        ...theme.typography.body,
        color: theme.colors.text,
    },
    actions: {
        flexDirection: 'row',
        gap: theme.spacing.m,
        marginTop: theme.spacing.l,
    },
    button: {
        flex: 1,
        padding: theme.spacing.m,
        borderRadius: 12,
        alignItems: 'center',
    },
    cancelButton: {
        backgroundColor: theme.colors.white,
        borderWidth: 1,
        borderColor: theme.colors.border,
    },
    cancelButtonText: {
        fontSize: 16,
        fontWeight: '600' as const,
        color: theme.colors.text,
    },
    saveButton: {
        backgroundColor: theme.colors.primary,
    },
    saveButtonDisabled: {
        opacity: 0.5,
    },
    saveButtonText: {
        fontSize: 16,
        fontWeight: '600' as const,
        color: theme.colors.white,
    },
    typeContainer: {
        flexDirection: 'row',
        gap: theme.spacing.m,
    },
    typeButton: {
        flex: 1,
        padding: theme.spacing.m,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: theme.colors.white,
        alignItems: 'center',
    },
    typeButtonActive: {
        backgroundColor: theme.colors.primary,
        borderColor: theme.colors.primary,
    },
    typeText: {
        fontSize: 14,
        fontWeight: '600' as const,
        color: theme.colors.text,
    },
    typeTextActive: {
        color: theme.colors.white,
    },
});
