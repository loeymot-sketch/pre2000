import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, Alert } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import i18n from '../i18n';
import { theme } from '../theme';

const LANGUAGES = [
    { code: 'fr', name: 'Français', flag: '🇫🇷', nativeName: 'Français' },
    { code: 'ar', name: 'Arabic', flag: '🇸🇦', nativeName: 'العربية' },
    { code: 'en', name: 'English', flag: '🇬🇧', nativeName: 'English' },
];

export const LanguageSelectScreen = () => {
    const navigation = useNavigation<any>();
    const [selectedLanguage, setSelectedLanguage] = useState(i18n.language || 'fr');
    const [loading, setLoading] = useState(false);

    useEffect(() => {
        // Load saved language
        const loadLanguage = async () => {
            try {
                const savedLang = await AsyncStorage.getItem('app_locale');
                if (savedLang) {
                    setSelectedLanguage(savedLang);
                }
            } catch (error) {
                console.error('Error loading language:', error);
            }
        };
        loadLanguage();
    }, []);

    const handleLanguageSelect = async (languageCode: string) => {
        setLoading(true);
        try {
            // Change language in i18n
            await i18n.changeLanguage(languageCode);

            // Save language preference
            await AsyncStorage.setItem('app_locale', languageCode);
            setSelectedLanguage(languageCode);

            // Show success message
            Alert.alert(
                'Langue mise à jour ✓',
                'La nouvelle langue a été appliquée avec succès.',
                [
                    {
                        text: 'OK',
                        onPress: () => navigation.navigate('AuthChoice'),
                    },
                ]
            );
        } catch (error) {
            console.error('Error saving language:', error);
            Alert.alert('Erreur', 'Impossible de changer la langue');
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView style={styles.container}>
            {/* Header with Gradient */}
            <LinearGradient
                colors={['#FF6B9D', '#C2185B']}
                style={styles.header}
            >
                <Text style={styles.headerEmoji}>🌐</Text>
                <Text style={styles.headerTitle}>Choisir la langue</Text>
                <Text style={styles.headerSubtitle}>
                    Choose your language • اختر لغتك
                </Text>
            </LinearGradient>

            <View style={styles.content}>
                <Text style={styles.infoText}>
                    Sélectionnez votre langue préférée pour l'application
                </Text>

                {LANGUAGES.map((language) => (
                    <TouchableOpacity
                        key={language.code}
                        style={[
                            styles.languageCard,
                            selectedLanguage === language.code && styles.languageCardSelected,
                        ]}
                        onPress={() => handleLanguageSelect(language.code)}
                        disabled={loading}
                        activeOpacity={0.7}
                    >
                        <View style={styles.languageContent}>
                            <Text style={styles.languageFlag}>{language.flag}</Text>
                            <View style={styles.languageInfo}>
                                <Text style={[
                                    styles.languageName,
                                    selectedLanguage === language.code && styles.languageNameSelected,
                                ]}>
                                    {language.name}
                                </Text>
                                <Text style={[
                                    styles.languageNative,
                                    selectedLanguage === language.code && styles.languageNativeSelected,
                                ]}>
                                    {language.nativeName}
                                </Text>
                            </View>
                        </View>
                        {selectedLanguage === language.code && (
                            <View style={styles.checkmark}>
                                <Text style={styles.checkmarkText}>✓</Text>
                            </View>
                        )}
                    </TouchableOpacity>
                ))}

                {/* Info Box */}
                <View style={styles.infoBox}>
                    <Text style={styles.infoBoxTitle}>ℹ️ Information</Text>
                    <Text style={styles.infoBoxText}>
                        • La langue sera appliquée à tout le contenu de l'application
                    </Text>
                    <Text style={styles.infoBoxText}>
                        • Certaines traductions sont en cours de développement
                    </Text>
                    <Text style={styles.infoBoxText}>
                        • Le français est actuellement la langue la plus complète
                    </Text>
                </View>

                {/* Continue Button */}
                <TouchableOpacity
                    style={styles.backButton}
                    onPress={() => navigation.navigate('AuthChoice')}
                >
                    <Text style={styles.backButtonText}>Continuer →</Text>
                </TouchableOpacity>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8F9FA',
    },
    header: {
        paddingTop: 60,
        paddingBottom: 32,
        alignItems: 'center',
    },
    headerEmoji: {
        fontSize: 64,
        marginBottom: 16,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFFFFF',
        marginBottom: 8,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
        textAlign: 'center',
    },
    content: {
        padding: 16,
        paddingBottom: 32,
    },
    infoText: {
        fontSize: 15,
        color: '#666',
        textAlign: 'center',
        marginBottom: 24,
        lineHeight: 22,
    },
    languageCard: {
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        padding: 20,
        marginBottom: 12,
        borderWidth: 2,
        borderColor: '#E0E0E0',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 2,
    },
    languageCardSelected: {
        borderColor: '#FF6B9D',
        backgroundColor: '#FFF0F7',
    },
    languageContent: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    languageFlag: {
        fontSize: 40,
        marginRight: 16,
    },
    languageInfo: {
        flex: 1,
    },
    languageName: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 4,
    },
    languageNameSelected: {
        color: '#C2185B',
    },
    languageNative: {
        fontSize: 14,
        color: '#666',
    },
    languageNativeSelected: {
        color: '#FF6B9D',
    },
    checkmark: {
        position: 'absolute',
        top: 20,
        right: 20,
        width: 32,
        height: 32,
        borderRadius: 16,
        backgroundColor: '#FF6B9D',
        justifyContent: 'center',
        alignItems: 'center',
    },
    checkmarkText: {
        color: '#FFFFFF',
        fontSize: 18,
        fontWeight: 'bold',
    },
    infoBox: {
        backgroundColor: '#E3F2FD',
        borderRadius: 12,
        padding: 16,
        marginTop: 24,
        marginBottom: 24,
        borderWidth: 1,
        borderColor: '#BBDEFB',
    },
    infoBoxTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1976D2',
        marginBottom: 12,
    },
    infoBoxText: {
        fontSize: 14,
        color: '#1565C0',
        marginBottom: 8,
        lineHeight: 20,
    },
    backButton: {
        backgroundColor: '#FFFFFF',
        paddingVertical: 14,
        borderRadius: 12,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#E0E0E0',
    },
    backButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#666',
    },
});
