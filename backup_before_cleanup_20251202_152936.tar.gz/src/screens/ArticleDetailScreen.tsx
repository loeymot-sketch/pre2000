import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { doc, getDoc } from 'firebase/firestore';
import Markdown from 'react-native-markdown-display';
import { db } from '../config/firebase';
import { Article, Supplement, ArticleAntigravity } from '../types';
import { getAntigravityArticle } from '../services/contentService'; // ANTIGRAVITY
import { theme } from '../theme';
import { Tag } from '../components/common/Tag';
import { SectionHeader } from '../components/common/SectionHeader';
import { Card } from '../components/common/Card';
import { useNavigation, useRoute } from '@react-navigation/native';

export const ArticleDetailScreen = () => {
    const route = useRoute<any>();
    const navigation = useNavigation<any>();
    const { articleId } = route.params;
    const [article, setArticle] = useState<Article | ArticleAntigravity | null>(null);
    const [isAntigravity, setIsAntigravity] = useState(false); // Track type
    const [loading, setLoading] = useState(true);
    const [relatedSupplements, setRelatedSupplements] = useState<Supplement[]>([]);

    useEffect(() => {
        const fetchArticle = async () => {
            console.log(`[ArticleDetail] 📰 Fetching article: ${articleId}`);
            try {
                // ANTIGRAVITY: Try Antigravity collection first
                console.log('[ArticleDetail] 🔍 Trying Antigravity collection...');
                const agArticle = await getAntigravityArticle(articleId);

                if (agArticle) {
                    console.log('[ArticleDetail] ✅ Found in Antigravity:', agArticle.title_fr);
                    setArticle(agArticle);
                    setIsAntigravity(true);
                    setLoading(false);
                    return;
                }

                // Fallback to old articles collection
                console.log('[ArticleDetail] 🔍 Not in Antigravity, trying old articles...');
                const docRef = doc(db, 'articles', articleId);
                const docSnap = await getDoc(docRef);

                if (docSnap.exists()) {
                    const articleData = docSnap.data() as Article;
                    console.log('[ArticleDetail] ✅ Found in old articles:', articleData.title_fr);
                    setArticle(articleData);
                    setIsAntigravity(false);

                    // Fetch related supplements (only for old articles)
                    if (articleData.related_supplements_ids && articleData.related_supplements_ids.length > 0) {
                        console.log('[ArticleDetail] 📦 Fetching', articleData.related_supplements_ids.length, 'supplements');
                        const supplementsPromises = articleData.related_supplements_ids.map(id =>
                            getDoc(doc(db, 'supplements', id))
                        );
                        const supplementsSnaps = await Promise.all(supplementsPromises);
                        const supplements = supplementsSnaps
                            .filter(s => s.exists())
                            .map(s => s.data() as Supplement);
                        console.log('[ArticleDetail] ✅ Loaded', supplements.length, 'supplements');
                        setRelatedSupplements(supplements);
                    }
                } else {
                    console.warn('[ArticleDetail] ⚠️ Article not found in any collection:', articleId);
                }
            } catch (error) {
                console.error('[ArticleDetail] ❌ Error fetching article:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchArticle();
    }, [articleId]);

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    if (!article) {
        return (
            <View style={styles.centerContainer}>
                <Text style={theme.typography.body}>Article non trouvé.</Text>
            </View>
        );
    }

    // ANTIGRAVITY: Handle both Article and ArticleAntigravity types
    const hasContent = isAntigravity
        ? (article as ArticleAntigravity).content_fr && (article as ArticleAntigravity).content_fr.trim().length > 0
        : (article as Article).content_markdown_fr && (article as Article).content_markdown_fr.trim().length > 0;

    const content = isAntigravity
        ? ((article as ArticleAntigravity).content_fr || (article as ArticleAntigravity).summary_fr || "Contenu en cours...")
        : hasContent
            ? (article as Article).content_markdown_fr
            : ((article as Article).summary_fr || "Contenu en cours de préparation. Revenez bientôt 🧡\n\nCet article sera prochainement enrichi avec plus de détails.");

    const title = isAntigravity ? (article as ArticleAntigravity).title_fr : (article as Article).title_fr;
    const category = article.category;

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
            <View style={styles.header}>
                <Tag label={category} />
                <Text style={[theme.typography.h1, styles.title] as any}>{title}</Text>
                {!hasContent && (
                    <View style={styles.previewBadge}>
                        <Text style={styles.previewText}>📝 Aperçu</Text>
                    </View>
                )}
            </View>

            <View style={styles.markdownContainer}>
                {hasContent ? (
                    <Markdown style={markdownStyles}>
                        {content}
                    </Markdown>
                ) : (
                    <View style={styles.fallbackContainer}>
                        <Text style={styles.fallbackText}>
                            Contenu en cours d'ajout 🚧
                        </Text>
                        <Text style={theme.typography.body}>
                            {article.summary_fr || "Cet article est en cours de rédaction par nos experts."}
                        </Text>
                        <View style={styles.fallbackActions}>
                            <Text style={[theme.typography.caption, { textAlign: 'center', marginTop: theme.spacing.m }]}>
                                En attendant, consultez les compléments liés ci-dessous ou revenez plus tard !
                            </Text>
                        </View>
                    </View>
                )}
            </View>

            {relatedSupplements.length > 0 && (
                <View style={styles.section}>
                    <SectionHeader title="Compléments liés" />
                    {relatedSupplements.map(supplement => (
                        <Card key={supplement.supplement_id} style={styles.supplementCard}>
                            <Text style={theme.typography.h3}>{supplement.name_fr}</Text>
                            <Text style={theme.typography.body}>{supplement.short_description_fr}</Text>
                        </Card>
                    ))}
                </View>
            )}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    contentContainer: {
        padding: theme.spacing.m,
        paddingBottom: theme.spacing.xl,
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        marginBottom: theme.spacing.l,
    },
    title: {
        marginTop: theme.spacing.s,
    },
    previewBadge: {
        backgroundColor: theme.colors.secondary,
        paddingHorizontal: theme.spacing.m,
        paddingVertical: theme.spacing.xs,
        borderRadius: theme.borderRadius.round,
        alignSelf: 'flex-start',
        marginTop: theme.spacing.s,
    },
    previewText: {
        fontSize: 12,
        color: theme.colors.text,
        fontWeight: 'bold',
    },
    markdownContainer: {
        marginBottom: theme.spacing.l,
    },
    section: {
        marginTop: theme.spacing.l,
    },
    supplementCard: {
        marginBottom: theme.spacing.s,
    },
    fallbackContainer: {
        padding: theme.spacing.l,
        backgroundColor: theme.colors.white,
        borderRadius: theme.borderRadius.m,
        alignItems: 'center',
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderStyle: 'dashed',
    },
    fallbackText: {
        ...theme.typography.h3,
        color: theme.colors.textLight,
        marginBottom: theme.spacing.s,
    },
    fallbackActions: {
        width: '100%',
        alignItems: 'center',
    },
});

const markdownStyles = {
    body: {
        ...theme.typography.body,
        color: theme.colors.text,
        lineHeight: 24,
    },
    heading1: {
        fontSize: 24,
        fontWeight: 'bold',
        color: theme.colors.primary,
        marginTop: theme.spacing.l,
        marginBottom: theme.spacing.m,
        borderBottomWidth: 2,
        borderBottomColor: theme.colors.secondary,
        paddingBottom: theme.spacing.s,
    },
    heading2: {
        fontSize: 20,
        fontWeight: 'bold',
        color: theme.colors.text,
        marginTop: theme.spacing.m,
        marginBottom: theme.spacing.s,
    },
    heading3: {
        fontSize: 18,
        fontWeight: 'bold',
        color: theme.colors.text,
        marginTop: theme.spacing.m,
        marginBottom: theme.spacing.xs,
    },
    paragraph: {
        marginBottom: theme.spacing.m,
        lineHeight: 24,
    },
    list_item: {
        marginBottom: theme.spacing.xs,
        paddingLeft: theme.spacing.s,
    },
    bullet_list: {
        marginBottom: theme.spacing.s,
    },
    code_inline: {
        backgroundColor: theme.colors.secondary,
        color: theme.colors.text,
        paddingHorizontal: 4,
        paddingVertical: 2,
        borderRadius: 4,
        fontFamily: 'Courier',
    },
    code_block: {
        backgroundColor: theme.colors.secondary,
        padding: theme.spacing.s,
        borderRadius: theme.borderRadius.s,
        marginVertical: theme.spacing.s,
    },
    blockquote: {
        backgroundColor: theme.colors.background,
        borderLeftWidth: 4,
        borderLeftColor: theme.colors.primary,
        paddingLeft: theme.spacing.m,
        paddingVertical: theme.spacing.s,
        marginVertical: theme.spacing.s,
        fontStyle: 'italic',
    },
    link: {
        color: theme.colors.primary,
        textDecorationLine: 'underline' as const,
    },
};
