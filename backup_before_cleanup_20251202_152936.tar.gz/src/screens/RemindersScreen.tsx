import React from 'react';
import { StyleSheet } from 'react-native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { RemindersTab } from './reminders/RemindersTab';
import { TasksTab } from './reminders/TasksTab';

const Tab = createMaterialTopTabNavigator();

/**
 * RemindersScreen - V1.2 Feature
 * Full reminders and tasks management with local notifications
 * Refactored to use split components
 */
export const RemindersScreen = () => {
    return (
        <Tab.Navigator
            screenOptions={{
                tabBarActiveTintColor: '#C2185B',
                tabBarInactiveTintColor: '#999',
                tabBarLabelStyle: { fontSize: 14, fontWeight: '600' },
                tabBarStyle: { backgroundColor: '#FFF' },
                tabBarIndicatorStyle: { backgroundColor: '#C2185B' },
            }}
        >
            <Tab.Screen
                name="RemindersTab"
                component={RemindersTab}
                options={{ tabBarLabel: '🔔 Rappels' }}
            />
            <Tab.Screen
                name="TasksTab"
                component={TasksTab}
                options={{ tabBarLabel: '✓ Tâches' }}
            />
        </Tab.Navigator>
    );
};
