import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import { getUserTasks, updateTaskStatus, deleteTask } from '../services/taskService';
import { UserTask } from '../types';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { useToast } from '../context/ToastContext';

/**
 * CompletedTasksScreen - Dedicated screen for completed tasks
 * Shows all tasks marked as completed with options to restore or delete permanently
 */
export const CompletedTasksScreen = () => {
    const { user } = useAuth();
    const navigation = useNavigation();
    const [completedTasks, setCompletedTasks] = useState<UserTask[]>([]);
    const [loading, setLoading] = useState(true);
    const { showToast } = useToast();

    console.log('[CompletedTasksScreen] Rendering...');

    useEffect(() => {
        loadCompletedTasks();
    }, [user]);

    const loadCompletedTasks = async () => {
        if (!user?.uid) return;

        console.log('[CompletedTasksScreen] Loading completed tasks...');
        setLoading(true);

        try {
            const allTasks = await getUserTasks(user.uid);
            const completed = allTasks.filter(t => t.completed);
            setCompletedTasks(completed);
            console.log('[CompletedTasksScreen] ✅ Loaded', completed.length, 'completed tasks');
        } catch (error) {
            console.error('[CompletedTasksScreen] ❌ Error loading tasks:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleRestore = async (taskId: string, title: string) => {
        console.log('[CompletedTasksScreen] Restoring task:', taskId);

        try {
            // Optimistic update
            setCompletedTasks(prev => prev.filter(t => t.task_id !== taskId));

            await updateTaskStatus(taskId, false);
            showToast('Tâche restaurée !', 'success');
            console.log('[CompletedTasksScreen] ✅ Task restored');
        } catch (error) {
            console.error('[CompletedTasksScreen] ❌ Error restoring task:', error);
            showToast('Impossible de restaurer la tâche', 'error');
            // Revert optimistic update if needed (omitted for simplicity as fetch will fix it)
        }
    };

    const handleDelete = async (taskId: string, title: string) => {
        console.log('[CompletedTasksScreen] Deleting task permanently:', taskId);

        Alert.alert(
            'Supprimer définitivement',
            `Voulez-vous supprimer définitivement "${title}" ?`,
            [
                { text: 'Annuler', style: 'cancel' },
                {
                    text: 'Supprimer',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            // Optimistic update
                            setCompletedTasks(prev => prev.filter(t => t.task_id !== taskId));

                            await deleteTask(taskId);
                            showToast('Tâche supprimée', 'info');
                            console.log('[CompletedTasksScreen] ✅ Task deleted permanently');
                        } catch (error) {
                            console.error('[CompletedTasksScreen] ❌ Error deleting task:', error);
                            showToast('Impossible de supprimer la tâche', 'error');
                        }
                    }
                }
            ]
        );
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color="#C2185B" />
                <Text style={styles.loadingText}>Chargement...</Text>
            </View>
        );
    }

    if (completedTasks.length === 0) {
        return (
            <View style={styles.container}>
                <LinearGradient
                    colors={['#FF6B9D', '#C2185B']}
                    style={styles.headerGradient}
                >
                    <Text style={styles.headerTitle}>✓ Tâches Complétées</Text>
                    <Text style={styles.headerSubtitle}>0 tâche</Text>
                </LinearGradient>

                <View style={styles.centerContainer}>
                    <Text style={styles.emptyEmoji}>📋</Text>
                    <Text style={styles.emptyTitle}>Aucune tâche complétée</Text>
                    <Text style={styles.emptyText}>
                        Les tâches que vous marquez comme complétées{'\n'}
                        apparaîtront ici.
                    </Text>
                </View>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <LinearGradient
                colors={['#FF6B9D', '#C2185B']}
                style={styles.headerGradient}
            >
                <Text style={styles.headerTitle}>✓ Tâches Complétées</Text>
                <Text style={styles.headerSubtitle}>{completedTasks.length} tâche{completedTasks.length > 1 ? 's' : ''}</Text>
            </LinearGradient>

            <ScrollView style={styles.scrollView}>
                {completedTasks.map(task => (
                    <View key={task.task_id} style={styles.taskCard}>
                        <View style={styles.taskHeader}>
                            <View style={styles.taskInfo}>
                                <Text style={styles.taskTitle}>✓ {task.title}</Text>
                                <Text style={styles.taskMeta}>
                                    {task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢'}
                                    {' '}Priorité: {task.priority === 'high' ? 'Haute' : task.priority === 'medium' ? 'Moyenne' : 'Basse'}
                                </Text>
                                {task.completed_at && (
                                    <Text style={styles.completedDate}>
                                        Complétée le {format(task.completed_at, 'dd MMMM yyyy', { locale: fr })}
                                    </Text>
                                )}
                            </View>
                        </View>

                        <View style={styles.taskActions}>
                            <TouchableOpacity
                                style={styles.restoreButton}
                                onPress={() => handleRestore(task.task_id, task.title)}
                            >
                                <Text style={styles.restoreButtonText}>↩️ Restaurer</Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={styles.deleteButton}
                                onPress={() => handleDelete(task.task_id, task.title)}
                            >
                                <Text style={styles.deleteButtonText}>🗑️ Supprimer</Text>
                            </TouchableOpacity>
                        </View>
                    </View>
                ))}
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F5F5',
    },
    headerGradient: {
        paddingTop: 60,
        paddingBottom: 20,
        paddingHorizontal: 20,
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFF',
        marginBottom: 4,
    },
    headerSubtitle: {
        fontSize: 16,
        color: '#FFF',
        opacity: 0.9,
    },
    scrollView: {
        flex: 1,
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 32,
    },
    loadingText: {
        marginTop: 12,
        fontSize: 16,
        color: '#666',
    },
    emptyEmoji: {
        fontSize: 64,
        marginBottom: 16,
    },
    emptyTitle: {
        fontSize: 20,
        fontWeight: '600',
        color: '#333',
        marginBottom: 8,
        textAlign: 'center',
    },
    emptyText: {
        fontSize: 15,
        color: '#666',
        textAlign: 'center',
        lineHeight: 22,
    },
    taskCard: {
        backgroundColor: '#FFF',
        marginHorizontal: 16,
        marginTop: 12,
        borderRadius: 12,
        padding: 16,
        shadowColor: '#000',
        shadowOpacity: 0.1,
        shadowRadius: 4,
        shadowOffset: { width: 0, height: 2 },
        elevation: 2,
    },
    taskHeader: {
        marginBottom: 12,
    },
    taskInfo: {
        flex: 1,
    },
    taskTitle: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
        marginBottom: 6,
        textDecorationLine: 'line-through',
        opacity: 0.7,
    },
    taskMeta: {
        fontSize: 13,
        color: '#666',
        marginBottom: 4,
    },
    completedDate: {
        fontSize: 12,
        color: '#999',
        fontStyle: 'italic',
    },
    taskActions: {
        flexDirection: 'row',
        gap: 12,
    },
    restoreButton: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 16,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#4CAF50',
        alignItems: 'center',
    },
    restoreButtonText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#4CAF50',
    },
    deleteButton: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 16,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#E53935',
        alignItems: 'center',
    },
    deleteButtonText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#E53935',
    },
});
