import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Switch, TouchableOpacity } from 'react-native';
import { usePregnancy } from '../context/PregnancyContext';
import {
    loadBabyMessageEnabled,
    saveBabyMessageEnabled,
    loadBabyMessageHour,
    saveBabyMessageHour,
} from '../services/reminderPersistence';
import { updateBabyMessageSchedule } from '../services/babyMessageService';

/**
 * SettingsScreen - V1.2 Feature
 * Manage notification settings
 */
export const SettingsScreen = () => {
    const { pregnancyInfo } = usePregnancy();
    const [babyMessageEnabled, setBabyMessageEnabled] = useState(true);
    const [babyMessageHour, setBabyMessageHour] = useState(10);
    const [loading, setLoading] = useState(true);

    console.log('[SettingsScreen] Rendering...');

    useEffect(() => {
        loadSettings();
    }, []);

    const loadSettings = async () => {
        console.log('[SettingsScreen] Loading settings...');
        setLoading(true);

        try {
            const enabled = await loadBabyMessageEnabled();
            const hour = await loadBabyMessageHour();

            setBabyMessageEnabled(enabled);
            setBabyMessageHour(hour);

            console.log('[SettingsScreen] Loaded settings:', { enabled, hour });
        } catch (error) {
            console.error('[SettingsScreen] Error loading settings:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleBabyMessageToggle = async (value: boolean) => {
        console.log('[SettingsScreen] Baby message toggle:', value);
        setBabyMessageEnabled(value);

        try {
            await saveBabyMessageEnabled(value);

            if (pregnancyInfo) {
                await updateBabyMessageSchedule(
                    pregnancyInfo.week,
                    value,
                    babyMessageHour
                );
            }

            console.log('[SettingsScreen] ✅ Baby message setting saved');
        } catch (error) {
            console.error('[SettingsScreen] Error toggling baby message:', error);
        }
    };

    const handleHourChange = async (newHour: number) => {
        console.log('[SettingsScreen] Hour change:', newHour);
        setBabyMessageHour(newHour);

        try {
            await saveBabyMessageHour(newHour);

            if (pregnancyInfo && babyMessageEnabled) {
                await updateBabyMessageSchedule(
                    pregnancyInfo.week,
                    babyMessageEnabled,
                    newHour
                );
            }

            console.log('[SettingsScreen] ✅ Hour setting saved');
        } catch (error) {
            console.error('[SettingsScreen] Error changing hour:', error);
        }
    };

    if (loading) {
        return (
            <View style={styles.container}>
                <Text>Chargement...</Text>
            </View>
        );
    }

    return (
        <ScrollView style={styles.container}>
            <View style={styles.header}>
                <Text style={styles.headerTitle}>⚙️ Paramètres</Text>
                <Text style={styles.headerSubtitle}>Notifications</Text>
            </View>

            {/* Baby Message Section */}
            <View style={styles.section}>
                <View style={styles.sectionHeader}>
                    <Text style={styles.sectionTitle}>💕 Message du Bébé</Text>
                </View>

                <View style={styles.settingRow}>
                    <View style={styles.settingInfo}>
                        <Text style={styles.settingLabel}>Message quotidien</Text>
                        <Text style={styles.settingDescription}>
                            Reçois un message mignon de ton bébé chaque jour
                        </Text>
                    </View>
                    <Switch
                        value={babyMessageEnabled}
                        onValueChange={handleBabyMessageToggle}
                        trackColor={{ false: '#ccc', true: '#C2185B' }}
                        thumbColor={babyMessageEnabled ? '#fff' : '#f4f3f4'}
                    />
                </View>

                {babyMessageEnabled && (
                    <View style={styles.hourSelector}>
                        <Text style={styles.hourLabel}>Heure de notification:</Text>
                        <View style={styles.hourButtons}>
                            {[8, 9, 10, 11, 12].map(hour => (
                                <TouchableOpacity
                                    key={hour}
                                    style={[
                                        styles.hourButton,
                                        babyMessageHour === hour && styles.hourButtonActive
                                    ]}
                                    onPress={() => handleHourChange(hour)}
                                >
                                    <Text style={[
                                        styles.hourButtonText,
                                        babyMessageHour === hour && styles.hourButtonTextActive
                                    ]}>
                                        {hour}:00
                                    </Text>
                                </TouchableOpacity>
                            ))}
                        </View>
                    </View>
                )}
            </View>

            {/* Info Section */}
            <View style={styles.infoSection}>
                <Text style={styles.infoText}>
                    💡 Les rappels santé se configurent dans l'onglet "Rappels"
                </Text>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F5F5',
    },
    header: {
        padding: 20,
        backgroundColor: '#FFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 4,
    },
    headerSubtitle: {
        fontSize: 14,
        color: '#666',
    },
    section: {
        marginTop: 16,
        backgroundColor: '#FFF',
        borderRadius: 12,
        marginHorizontal: 16,
        overflow: 'hidden',
    },
    sectionHeader: {
        padding: 16,
        backgroundColor: '#F9F9F9',
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
    },
    sectionTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#333',
    },
    settingRow: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: 16,
        borderBottomWidth: 1,
        borderBottomColor: '#F0F0F0',
    },
    settingInfo: {
        flex: 1,
        marginRight: 16,
    },
    settingLabel: {
        fontSize: 16,
        fontWeight: '600',
        color: '#333',
        marginBottom: 4,
    },
    settingDescription: {
        fontSize: 14,
        color: '#666',
        lineHeight: 20,
    },
    hourSelector: {
        padding: 16,
    },
    hourLabel: {
        fontSize: 14,
        color: '#666',
        marginBottom: 12,
    },
    hourButtons: {
        flexDirection: 'row',
        gap: 8,
    },
    hourButton: {
        flex: 1,
        paddingVertical: 10,
        borderRadius: 8,
        borderWidth: 1,
        borderColor: '#C2185B',
        backgroundColor: '#FFF',
        alignItems: 'center',
    },
    hourButtonActive: {
        backgroundColor: '#C2185B',
    },
    hourButtonText: {
        fontSize: 14,
        color: '#C2185B',
        fontWeight: '600',
    },
    hourButtonTextActive: {
        color: '#FFF',
    },
    infoSection: {
        margin: 16,
        padding: 16,
        backgroundColor: '#FFF9E6',
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#FFE69C',
    },
    infoText: {
        fontSize: 14,
        color: '#856404',
        lineHeight: 20,
    },
});
