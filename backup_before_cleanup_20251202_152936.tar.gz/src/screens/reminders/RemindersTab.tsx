import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, StyleSheet, ScrollView } from 'react-native';
import { usePregnancy } from '../../context/PregnancyContext';
import { fetchRemindersForWeek } from '../../services/reminderService';
import { requestNotificationPermissions } from '../../services/notificationService';
import { ReminderTemplate } from '../../types';
import { ReminderCard } from '../../components/reminders/ReminderCard';

const PermissionBanner = () => {
    const [permissionsGranted, setPermissionsGranted] = useState(true);

    useEffect(() => {
        checkPermissions();
    }, []);

    const checkPermissions = async () => {
        const granted = await requestNotificationPermissions();
        setPermissionsGranted(granted);
    };

    if (permissionsGranted) return null;

    return (
        <View style={styles.permissionBanner}>
            <Text style={styles.permissionText}>
                ⚠️ Activez les notifications pour recevoir vos rappels
            </Text>
        </View>
    );
};

export const RemindersTab = () => {
    const { pregnancyInfo } = usePregnancy();
    const [reminders, setReminders] = useState<ReminderTemplate[]>([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        loadReminders();
    }, [pregnancyInfo?.week]);

    const loadReminders = async () => {
        if (!pregnancyInfo?.week) return;

        setLoading(true);

        try {
            const data = await fetchRemindersForWeek(pregnancyInfo.week);
            setReminders(data);
        } catch (error) {
            console.error('[RemindersTab] Error loading reminders:', error);
        } finally {
            setLoading(false);
        }
    };

    // Group reminders by category
    const groupByCategory = (reminders: ReminderTemplate[]) => {
        const grouped: Record<string, ReminderTemplate[]> = {
            hydration: [],
            nutrition: [],
            activity: [],
            sleep: [],
            medication: [],
            checkup: [],
            consultation: [],
            default: [],
        };

        reminders.forEach(reminder => {
            const category = reminder.category || 'default';
            if (grouped[category]) {
                grouped[category].push(reminder);
            } else {
                grouped['default'].push(reminder);
            }
        });

        return grouped;
    };

    const getCategoryConfig = (category: string) => {
        const configs: Record<string, { emoji: string; title: string }> = {
            hydration: { emoji: '💧', title: 'Hydratation' },
            nutrition: { emoji: '🥗', title: 'Nutrition' },
            activity: { emoji: '🏃', title: 'Activité' },
            sleep: { emoji: '😴', title: 'Sommeil' },
            medication: { emoji: '💊', title: 'Médication' },
            checkup: { emoji: '🏥', title: 'Consultations' },
        };
        return configs[category] || { emoji: '📋', title: category };
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <Text>Chargement...</Text>
            </View>
        );
    }

    if (reminders.length === 0) {
        return (
            <View style={styles.container}>
                <PermissionBanner />
                <View style={styles.centerContainer}>
                    <Text style={styles.emptyEmoji}>🔔</Text>
                    <Text style={styles.emptyTitle}>Tout est calme</Text>
                    <Text style={styles.emptyText}>Aucun rappel programmé pour cette semaine.</Text>
                    <Text style={styles.emptySubtext}>Profitez de votre temps libre ! 💖</Text>
                </View>
            </View>
        );
    }

    const categories = groupByCategory(reminders);

    return (
        <View style={styles.container}>
            <PermissionBanner />
            <ScrollView style={styles.tabContainer}>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>Rappels Santé</Text>
                    <Text style={styles.headerSubtitle}>
                        Personnalisez vos rappels quotidiens
                    </Text>
                </View>

                {Object.entries(categories).map(([category, items]) => {
                    if (items.length === 0) return null;

                    const categoryConfig = getCategoryConfig(category);

                    return (
                        <View key={category} style={styles.categorySection}>
                            <View style={styles.categoryHeader}>
                                <Text style={styles.categoryEmoji}>{categoryConfig.emoji}</Text>
                                <Text style={styles.categoryTitle}>{categoryConfig.title}</Text>
                            </View>

                            {items.map(reminder => (
                                <ReminderCard
                                    key={reminder.reminder_id}
                                    reminder={reminder}
                                />
                            ))}
                        </View>
                    );
                })}
            </ScrollView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F5F5F5',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    permissionBanner: {
        backgroundColor: '#FFF3CD',
        padding: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#FFE69C',
    },
    permissionText: {
        fontSize: 13,
        color: '#856404',
        textAlign: 'center',
    },
    emptyEmoji: {
        fontSize: 64,
        marginBottom: 16,
        textAlign: 'center',
    },
    emptyTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#666',
        marginBottom: 8,
        textAlign: 'center',
    },
    emptyText: {
        fontSize: 16,
        color: '#999',
    },
    emptySubtext: {
        fontSize: 14,
        color: '#999',
        marginTop: 8,
    },
    tabContainer: {
        flex: 1,
    },
    header: {
        padding: 20,
        backgroundColor: '#FFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333',
        marginBottom: 4,
    },
    headerSubtitle: {
        fontSize: 14,
        color: '#666',
    },
    categorySection: {
        marginTop: 16,
        backgroundColor: '#FFF',
        borderRadius: 12,
        marginHorizontal: 16,
        overflow: 'hidden',
    },
    categoryHeader: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 16,
        backgroundColor: '#F9F9F9',
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
    },
    categoryEmoji: {
        fontSize: 24,
        marginRight: 10,
    },
    categoryTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#333',
    },
});
