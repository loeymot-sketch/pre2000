import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Alert } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../../context/AuthContext';
import { usePregnancy } from '../../context/PregnancyContext';
import { useToast } from '../../context/ToastContext';
import { WeeklyTask, UserTask } from '../../types';
import { fetchTasksForWeek } from '../../services/reminderService';
import { getUserTasks, createTask, updateTaskStatus, deleteTask } from '../../services/taskService';
import { AddTaskModal } from '../../components/tasks/AddTaskModal';
import { TaskCard } from '../../components/tasks/TaskCard';

export const TasksTab = () => {
    const { user } = useAuth();
    const { pregnancyInfo } = usePregnancy();
    const navigation = useNavigation<any>();
    const [weeklyTasks, setWeeklyTasks] = useState<WeeklyTask[]>([]);
    const [userTasks, setUserTasks] = useState<UserTask[]>([]);
    const [loading, setLoading] = useState(true);
    const [showAddModal, setShowAddModal] = useState(false);
    const { showToast } = useToast();

    const completedCount = userTasks.filter(t => t.completed).length;

    useEffect(() => {
        loadTasks();
    }, [pregnancyInfo?.week, user]);

    const loadTasks = async () => {
        if (!pregnancyInfo?.week) return;

        setLoading(true);

        try {
            // Load weekly tasks from Firestore
            const weekly = await fetchTasksForWeek(pregnancyInfo.week);
            setWeeklyTasks(weekly);

            // Load user's custom tasks
            if (user?.uid) {
                const userTasksData = await getUserTasks(user.uid);
                setUserTasks(userTasksData);
            }
        } catch (error) {
            console.error('[TasksTab] Error loading tasks:', error);
        } finally {
            setLoading(false);
        }
    };

    const handleTaskCreated = (newTask: UserTask) => {
        // Optimistic update: Add to list immediately
        setUserTasks(prev => [newTask, ...prev]);
        showToast('Tâche ajoutée !', 'success');
    };

    const handleToggleTask = async (taskId: string, completed: boolean) => {
        try {
            await updateTaskStatus(taskId, completed);
            // Update local state
            setUserTasks(prev => prev.map(t =>
                t.task_id === taskId ? { ...t, completed } : t
            ));
        } catch (error) {
            console.error('[TasksTab] Error toggling task:', error);
        }
    };

    const handleDeleteTask = async (taskId: string) => {
        Alert.alert(
            'Supprimer la tâche',
            'Êtes-vous sûr de vouloir supprimer cette tâche ?',
            [
                { text: 'Annuler', style: 'cancel' },
                {
                    text: 'Supprimer',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await deleteTask(taskId);
                            setUserTasks(prev => prev.filter(t => t.task_id !== taskId));
                        } catch (error) {
                            console.error('[TasksTab] Error deleting task:', error);
                        }
                    }
                }
            ]
        );
    };

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <Text>Chargement...</Text>
            </View>
        );
    }

    if (userTasks.length === 0 && weeklyTasks.length === 0) {
        return (
            <ScrollView style={styles.tabContainer}>
                <View style={styles.header}>
                    <Text style={styles.headerTitle}>Mes Tâches</Text>
                    <TouchableOpacity
                        style={styles.addTaskButton}
                        onPress={() => setShowAddModal(true)}
                    >
                        <Text style={styles.addTaskButtonText}>➕ Nouvelle tâche</Text>
                    </TouchableOpacity>
                </View>

                <View style={styles.centerContainer}>
                    <Text style={styles.emptyEmoji}>📝</Text>
                    <Text style={styles.emptyTitle}>Liste vide</Text>
                    <Text style={styles.emptyText}>
                        Libérez votre charge mentale en notant vos tâches ici.
                    </Text>
                    <TouchableOpacity
                        style={[styles.addTaskButton, { marginTop: 20, width: 'auto', paddingHorizontal: 32 }]}
                        onPress={() => setShowAddModal(true)}
                    >
                        <Text style={styles.addTaskButtonText}>+ Créer ma première tâche</Text>
                    </TouchableOpacity>
                </View>

                <AddTaskModal
                    visible={showAddModal}
                    onClose={() => setShowAddModal(false)}
                    onCreate={async (title, priority) => {
                        if (user?.uid) {
                            const newTask = await createTask(user.uid, title, priority);
                            handleTaskCreated(newTask);
                        }
                    }}
                />
            </ScrollView>
        );
    }

    return (
        <ScrollView style={styles.tabContainer}>
            {/* Header with Add Button */}
            <View style={styles.header}>
                <Text style={styles.headerTitle}>Mes Tâches</Text>
                <TouchableOpacity
                    style={styles.addTaskButton}
                    onPress={() => setShowAddModal(true)}
                >
                    <Text style={styles.addTaskButtonText}>➕ Nouvelle tâche</Text>
                </TouchableOpacity>
            </View>

            {/* Completed Tasks Link */}
            {completedCount > 0 && (
                <TouchableOpacity
                    style={styles.completedTasksLink}
                    onPress={() => navigation.navigate('CompletedTasks')}
                >
                    <Text style={styles.completedTasksText}>
                        ✓ Voir les tâches complétées ({completedCount})
                    </Text>
                    <Text style={styles.completedTasksArrow}>›</Text>
                </TouchableOpacity>
            )}

            {/* User Tasks */}
            {userTasks.filter(t => !t.completed).length > 0 && (
                <View style={styles.taskSection}>
                    <Text style={styles.sectionLabel}>MES TÂCHES ({userTasks.filter(t => !t.completed).length})</Text>
                    {userTasks.filter(t => !t.completed).map(task => (
                        <View key={task.task_id} style={[
                            styles.taskCard,
                            task.completed && styles.taskCardCompleted
                        ]}>
                            <TouchableOpacity
                                onPress={() => handleToggleTask(task.task_id, !task.completed)}
                                style={styles.taskCheckbox}
                            >
                                {task.completed ? (
                                    <Text style={styles.taskCheckboxChecked}>✓</Text>
                                ) : (
                                    <View style={styles.taskCheckboxEmpty} />
                                )}
                            </TouchableOpacity>

                            <View style={styles.taskContent}>
                                <Text style={[
                                    styles.taskTitle,
                                    task.completed && styles.taskTitleCompleted
                                ]}>
                                    {task.title}
                                </Text>
                                <Text style={styles.taskMeta}>
                                    {task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢'}
                                    {' '}Priorité: {task.priority === 'high' ? 'Haute' : task.priority === 'medium' ? 'Moyenne' : 'Basse'}
                                </Text>
                            </View>

                            <TouchableOpacity
                                onPress={() => handleDeleteTask(task.task_id)}
                                style={styles.taskDeleteButton}
                            >
                                <Text style={styles.taskDeleteText}>🗑️</Text>
                            </TouchableOpacity>
                        </View>
                    ))}
                </View>
            )}

            {/* Weekly Tasks */}
            {weeklyTasks.length > 0 && (
                <View style={styles.taskSection}>
                    <Text style={styles.sectionLabel}>TÂCHES DE LA SEMAINE ({weeklyTasks.length})</Text>
                    {weeklyTasks.map((task: WeeklyTask) => (
                        <TaskCard key={task.task_id} task={task} />
                    ))}
                </View>
            )}

            {/* Modal */}
            <AddTaskModal
                visible={showAddModal}
                onClose={() => setShowAddModal(false)}
                onCreate={async (title, priority) => {
                    if (user?.uid) {
                        try {
                            const newTask = await createTask(user.uid, title, priority);
                            handleTaskCreated(newTask);
                        } catch (error) {
                            console.error('Error creating task:', error);
                            showToast('Erreur lors de la création', 'error');
                        }
                    }
                }}
            />
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        padding: 20,
    },
    tabContainer: {
        flex: 1,
        backgroundColor: '#F5F5F5',
    },
    header: {
        padding: 20,
        backgroundColor: '#FFF',
        borderBottomWidth: 1,
        borderBottomColor: '#E0E0E0',
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    headerTitle: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#333',
    },
    addTaskButton: {
        backgroundColor: '#C2185B',
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 12,
    },
    addTaskButtonText: {
        color: '#FFF',
        fontSize: 14,
        fontWeight: '600',
    },
    emptyEmoji: {
        fontSize: 64,
        marginBottom: 16,
        textAlign: 'center',
    },
    emptyTitle: {
        fontSize: 18,
        fontWeight: '600',
        color: '#666',
        marginBottom: 8,
        textAlign: 'center',
    },
    emptyText: {
        fontSize: 16,
        color: '#999',
        textAlign: 'center',
    },
    completedTasksLink: {
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
        backgroundColor: '#FFF',
        marginHorizontal: 16,
        marginTop: 16,
        padding: 14,
        borderRadius: 10,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
        elevation: 2,
    },
    completedTasksText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#666',
    },
    completedTasksArrow: {
        fontSize: 20,
        color: '#666',
    },
    taskSection: {
        marginTop: 24,
        marginHorizontal: 16,
    },
    sectionLabel: {
        fontSize: 12,
        fontWeight: '700',
        color: '#999',
        letterSpacing: 0.5,
        marginBottom: 12,
    },
    taskCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        backgroundColor: '#FFF',
        borderRadius: 8,
        marginBottom: 8,
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.05,
        shadowRadius: 2,
        elevation: 1,
    },
    taskCardCompleted: {
        opacity: 0.6,
    },
    taskCheckbox: {
        width: 24,
        height: 24,
        marginRight: 12,
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
    },
    taskCheckboxEmpty: {
        width: 24,
        height: 24,
        borderWidth: 2,
        borderColor: '#C2185B',
        borderRadius: 4,
    },
    taskCheckboxChecked: {
        fontSize: 18,
        color: '#C2185B',
    },
    taskContent: {
        flex: 1,
    },
    taskTitle: {
        fontSize: 15,
        color: '#333',
        fontWeight: '500',
    },
    taskTitleCompleted: {
        textDecorationLine: 'line-through',
        color: '#999',
    },
    taskMeta: {
        fontSize: 12,
        color: '#999',
        marginTop: 4,
    },
    taskDeleteButton: {
        padding: 8,
        marginLeft: 8,
    },
    taskDeleteText: {
        fontSize: 20,
    },
});
