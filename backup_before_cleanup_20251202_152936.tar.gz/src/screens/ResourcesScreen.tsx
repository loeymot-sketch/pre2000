import React from 'react';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { ArticlesListScreen } from './ArticlesListScreen';
import { SupplementsListScreen } from './SupplementsListScreen';
import { theme } from '../theme';

const Tab = createMaterialTopTabNavigator();

export const ResourcesScreen = () => {
    return (
        <Tab.Navigator
            screenOptions={{
                tabBarActiveTintColor: theme.colors.primary,
                tabBarInactiveTintColor: theme.colors.textLight,
                tabBarIndicatorStyle: { backgroundColor: theme.colors.primary },
                tabBarStyle: { backgroundColor: theme.colors.white },
                tabBarLabelStyle: { fontWeight: '600' },
            }}
        >
            <Tab.Screen name="Articles" component={ArticlesListScreen} />
            <Tab.Screen name="Compléments" component={SupplementsListScreen} />
        </Tab.Navigator>
    );
};
