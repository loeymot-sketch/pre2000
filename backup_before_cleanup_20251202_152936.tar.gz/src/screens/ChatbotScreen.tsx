import React, { useState, useEffect, useRef } from 'react';
import { View, Text, StyleSheet, TextInput, FlatList, TouchableOpacity, KeyboardAvoidingView, Platform, ActivityIndicator } from 'react-native';
import { analyzeMessage, fetchSuggestions, ChatResponse } from '../services/chatbotService';
import { ChatbotSuggestion, Article } from '../types';
import { theme } from '../theme';
import { Card } from '../components/common/Card';
import { Button } from '../components/common/Button';
import { useNavigation } from '@react-navigation/native';

interface Message {
    id: string;
    text: string;
    sender: 'user' | 'bot';
    data?: ChatResponse;
}

export const ChatbotScreen = () => {
    const [messages, setMessages] = useState<Message[]>([
        { id: '1', text: 'Bonjour ! Je suis votre assistant virtuel. Comment puis-je vous aider ?', sender: 'bot' }
    ]);
    const [inputText, setInputText] = useState('');
    const [suggestions, setSuggestions] = useState<ChatbotSuggestion[]>([]);
    const [loading, setLoading] = useState(false);
    const flatListRef = useRef<FlatList>(null);
    const navigation = useNavigation<any>();

    useEffect(() => {
        const loadSuggestions = async () => {
            const data = await fetchSuggestions();
            setSuggestions(data);
        };
        loadSuggestions();
    }, []);

    const handleSend = async (text: string = inputText) => {
        if (!text.trim()) return;

        const userMsg: Message = { id: Date.now().toString(), text, sender: 'user' };
        setMessages(prev => [...prev, userMsg]);
        setInputText('');
        setLoading(true);

        try {
            const response = await analyzeMessage(text);
            const botMsg: Message = {
                id: (Date.now() + 1).toString(),
                text: response.message,
                sender: 'bot',
                data: response
            };
            setMessages(prev => [...prev, botMsg]);
        } catch (error) {
            const errorMsg: Message = { id: (Date.now() + 1).toString(), text: "Désolé, une erreur est survenue.", sender: 'bot' };
            setMessages(prev => [...prev, errorMsg]);
        } finally {
            setLoading(false);
        }
    };

    const renderMessage = ({ item }: { item: Message }) => {
        const isUser = item.sender === 'user';
        return (
            <View style={[styles.messageContainer, isUser ? styles.userMessage : styles.botMessage]}>
                <Text style={[styles.messageText, isUser ? styles.userMessageText : styles.botMessageText]}>
                    {item.text}
                </Text>

                {item.data?.type === 'red_flag' && (
                    <View style={styles.alertContainer}>
                        <Text style={styles.alertTitle}>⚠️ ALERTE</Text>
                        <Text style={styles.alertText}>Consultez un professionnel de santé immédiatement.</Text>
                    </View>
                )}

                {item.data?.articles && item.data.articles.length > 0 && (
                    <View style={styles.articlesContainer}>
                        {item.data.articles.map((article: Article) => (
                            <TouchableOpacity
                                key={article.article_id}
                                style={styles.articleLink}
                                onPress={() => navigation.navigate('Resources', {
                                    screen: 'Articles',
                                    params: { screen: 'ArticleDetail', params: { articleId: article.article_id } }
                                })}
                            >
                                <Text style={styles.articleLinkText}>📄 {article.title_fr}</Text>
                            </TouchableOpacity>
                        ))}
                    </View>
                )}
            </View>
        );
    };

    return (
        <View style={styles.container}>
            <View style={styles.disclaimer}>
                <Text style={styles.disclaimerText}>
                    ⚠️ Cet assistant ne remplace pas un avis médical. En cas d'urgence, contactez le 15 ou rendez-vous aux urgences.
                </Text>
            </View>

            <FlatList
                ref={flatListRef}
                data={messages}
                renderItem={renderMessage}
                keyExtractor={item => item.id}
                contentContainerStyle={styles.listContent}
                onContentSizeChange={() => flatListRef.current?.scrollToEnd({ animated: true })}
            />

            {loading && (
                <View style={styles.loadingContainer}>
                    <ActivityIndicator size="small" color={theme.colors.primary} />
                </View>
            )}

            <View style={styles.suggestionsContainer}>
                <FlatList
                    horizontal
                    data={suggestions}
                    keyExtractor={item => item.suggestion_id}
                    renderItem={({ item }) => (
                        <TouchableOpacity
                            style={styles.suggestionButton}
                            onPress={() => handleSend(item.label_fr)}
                        >
                            <Text style={styles.suggestionText}>{item.label_fr}</Text>
                        </TouchableOpacity>
                    )}
                    showsHorizontalScrollIndicator={false}
                />
            </View>

            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                keyboardVerticalOffset={Platform.OS === 'ios' ? 100 : 0}
                style={styles.inputContainer}
            >
                <TextInput
                    style={styles.input}
                    value={inputText}
                    onChangeText={setInputText}
                    placeholder="Posez votre question..."
                    placeholderTextColor={theme.colors.textLight}
                />
                <Button title="Envoyer" onPress={() => handleSend()} style={styles.sendButton} />
            </KeyboardAvoidingView>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    disclaimer: {
        backgroundColor: '#FFF3E0',
        padding: theme.spacing.s,
        alignItems: 'center',
    },
    disclaimerText: {
        ...theme.typography.caption,
        color: '#E65100',
        textAlign: 'center',
    },
    listContent: {
        padding: theme.spacing.m,
    },
    messageContainer: {
        maxWidth: '80%',
        padding: theme.spacing.m,
        borderRadius: theme.borderRadius.m,
        marginBottom: theme.spacing.m,
    },
    userMessage: {
        alignSelf: 'flex-end',
        backgroundColor: theme.colors.primary,
    },
    botMessage: {
        alignSelf: 'flex-start',
        backgroundColor: theme.colors.white,
        borderWidth: 1,
        borderColor: theme.colors.border,
    },
    messageText: {
        ...theme.typography.body,
    },
    userMessageText: {
        color: theme.colors.white,
    },
    botMessageText: {
        color: theme.colors.text,
    },
    inputContainer: {
        flexDirection: 'row',
        padding: theme.spacing.m,
        backgroundColor: theme.colors.white,
        borderTopWidth: 1,
        borderTopColor: theme.colors.border,
    },
    input: {
        flex: 1,
        backgroundColor: theme.colors.background,
        borderRadius: theme.borderRadius.round,
        paddingHorizontal: theme.spacing.m,
        marginRight: theme.spacing.s,
        height: 48,
    },
    sendButton: {
        paddingVertical: 0,
        height: 48,
        justifyContent: 'center',
    },
    suggestionsContainer: {
        paddingVertical: theme.spacing.s,
        backgroundColor: theme.colors.background,
    },
    suggestionButton: {
        backgroundColor: theme.colors.white,
        paddingHorizontal: theme.spacing.m,
        paddingVertical: theme.spacing.s,
        borderRadius: theme.borderRadius.round,
        marginHorizontal: theme.spacing.xs,
        borderWidth: 1,
        borderColor: theme.colors.secondary,
    },
    suggestionText: {
        ...theme.typography.caption,
        color: theme.colors.text,
    },
    alertContainer: {
        marginTop: theme.spacing.s,
        padding: theme.spacing.s,
        backgroundColor: '#FFEBEE',
        borderRadius: theme.borderRadius.s,
    },
    alertTitle: {
        fontWeight: 'bold',
        color: theme.colors.error,
    },
    alertText: {
        color: theme.colors.error,
        fontSize: 12,
    },
    articlesContainer: {
        marginTop: theme.spacing.s,
    },
    articleLink: {
        marginTop: 4,
    },
    articleLinkText: {
        color: theme.colors.primary,
        textDecorationLine: 'underline' as const,
    },
    loadingContainer: {
        padding: theme.spacing.s,
    },
});
