import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TextInput, TouchableOpacity, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { usePregnancy } from '../context/PregnancyContext';
import { useCurrentWeek } from '../services/useCurrentWeek';
import { theme } from '../theme';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';
import { addDays, format } from 'date-fns';
import { fr } from 'date-fns/locale';

const COUNTRIES = ['Tunisie', 'Maroc', 'Algérie', 'France', 'Autre'];

export const ProfileScreen = () => {
    const { user, logout, resetProfile } = useAuth();
    const { profile, setProfile } = usePregnancy();
    const { currentWeekNumber } = useCurrentWeek();
    const navigation = useNavigation<any>();
    const [loading, setLoading] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    const [firstName, setFirstName] = useState(profile?.firstName || '');
    const [lastName, setLastName] = useState(profile?.lastName || '');
    const [country, setCountry] = useState(profile?.country || 'Tunisie');
    const [lmp, setLmp] = useState(
        profile?.lmp ? new Date(profile.lmp) : new Date()
    );
    const [showDatePicker, setShowDatePicker] = useState(false);

    // Update local state when profile changes
    useEffect(() => {
        if (profile) {
            setFirstName(profile.firstName || '');
            setLastName(profile.lastName || '');
            setCountry(profile.country || 'Tunisie');
            if (profile.lmp) {
                setLmp(new Date(profile.lmp));
            }
        }
    }, [profile]);

    // Calculate DPA (Due Date) = LMP + 280 days
    const calculateDPA = (lmpDate: Date): Date => {
        return addDays(lmpDate, 280);
    };

    const dpa = calculateDPA(lmp);

    const handleSave = async () => {
        if (!firstName.trim()) {
            Alert.alert('Erreur', 'Le prénom est obligatoire');
            return;
        }

        setLoading(true);
        try {
            await setProfile({
                firstName: firstName.trim(),
                lastName: lastName.trim() || undefined,
                country,
                lmp: lmp.toISOString(),
                dpa: dpa.toISOString(),
            });
            Alert.alert('Succès', 'Profil mis à jour avec succès! ✓');
            setIsEditing(false);
        } catch (error) {
            Alert.alert('Erreur', 'Impossible de mettre à jour le profil');
            console.error(error);
        } finally {
            setLoading(false);
        }
    };

    const handleCancel = () => {
        // Reset to profile values
        setFirstName(profile?.firstName || '');
        setLastName(profile?.lastName || '');
        setCountry(profile?.country || 'Tunisie');
        if (profile?.lmp) {
            setLmp(new Date(profile.lmp));
        }
        setIsEditing(false);
    };

    const handleLogout = async () => {
        Alert.alert(
            'Déconnexion',
            'Êtes-vous sûre de vouloir vous déconnecter ?',
            [
                { text: 'Annuler', style: 'cancel' },
                {
                    text: 'Déconnexion',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            await logout();
                        } catch (error) {
                            console.error('Logout error:', error);
                        }
                    },
                },
            ]
        );
    };

    const handleResetProfile = async () => {
        Alert.alert(
            '⚠️ Réinitialiser le profil',
            'Cette action est irréversible. Toutes vos données seront supprimées et vous serez redirigé vers l\'écran de connexion.',
            [
                { text: 'Annuler', style: 'cancel' },
                {
                    text: 'Réinitialiser',
                    style: 'destructive',
                    onPress: async () => {
                        try {
                            setLoading(true);
                            await resetProfile();
                            Alert.alert(
                                'Profil réinitialisé',
                                'Vos données ont été supprimées avec succès.',
                                [
                                    {
                                        text: 'OK',
                                        onPress: () => {
                                            // Navigate to AuthChoice
                                            navigation.reset({
                                                index: 0,
                                                routes: [{ name: 'AuthChoice' }],
                                            });
                                        },
                                    },
                                ]
                            );
                        } catch (error) {
                            console.error('Reset profile error:', error);
                            Alert.alert('Erreur', 'Impossible de réinitialiser le profil');
                        } finally {
                            setLoading(false);
                        }
                    },
                },
            ]
        );
    };

    const renderCountrySelector = () => {
        return (
            <View style={styles.countrySelector}>
                {COUNTRIES.map((c) => (
                    <TouchableOpacity
                        key={c}
                        style={[
                            styles.countryButton,
                            country === c && styles.countryButtonSelected,
                        ]}
                        onPress={() => setCountry(c)}
                        disabled={!isEditing}
                    >
                        <Text
                            style={[
                                styles.countryButtonText,
                                country === c && styles.countryButtonTextSelected,
                            ]}
                        >
                            {c}
                        </Text>
                    </TouchableOpacity>
                ))}
            </View>
        );
    };

    return (
        <ScrollView style={styles.container}>
            {/* Header with Gradient */}
            <LinearGradient
                colors={['#FF6B9D', '#C2185B']}
                style={styles.header}
            >
                <View style={styles.profileCircle}>
                    <Text style={styles.profileLetter}>
                        {firstName?.charAt(0)?.toUpperCase() || 'U'}
                    </Text>
                </View>
                <Text style={styles.headerTitle}>Mon Profil</Text>
                <Text style={styles.headerSubtitle}>
                    {user?.email || 'Utilisateur invité'}
                </Text>
            </LinearGradient>

            <View style={styles.content}>
                {/* Pregnancy Info Card */}
                <View style={[styles.card, styles.pregnancyCard]}>
                    <Text style={styles.cardTitle}>🤰 Votre Grossesse</Text>
                    <View style={styles.infoRow}>
                        <View style={styles.infoItem}>
                            <Text style={styles.infoLabel}>Semaine actuelle</Text>
                            <Text style={styles.infoValue}>{currentWeekNumber || '—'}</Text>
                        </View>
                        <View style={styles.infoItem}>
                            <Text style={styles.infoLabel}>Trimestre</Text>
                            <Text style={styles.infoValue}>
                                {currentWeekNumber ? (currentWeekNumber <= 13 ? '1er' : currentWeekNumber <= 27 ? '2ème' : '3ème') : '—'}
                            </Text>
                        </View>
                    </View>
                </View>

                {/* Personal Info Card */}
                <View style={styles.card}>
                    <View style={styles.cardHeader}>
                        <Text style={styles.cardTitle}>👤 Informations Personnelles</Text>
                        {!isEditing && (
                            <TouchableOpacity
                                style={styles.editButton}
                                onPress={() => setIsEditing(true)}
                            >
                                <Text style={styles.editButtonText}>✏️ Modifier</Text>
                            </TouchableOpacity>
                        )}
                    </View>

                    <View style={styles.form}>
                        <Text style={styles.label}>Prénom *</Text>
                        <TextInput
                            style={[styles.input, !isEditing && styles.inputDisabled]}
                            value={firstName}
                            onChangeText={setFirstName}
                            placeholder="Votre prénom"
                            editable={isEditing}
                        />

                        <Text style={styles.label}>Nom</Text>
                        <TextInput
                            style={[styles.input, !isEditing && styles.inputDisabled]}
                            value={lastName}
                            onChangeText={setLastName}
                            placeholder="Votre nom (optionnel)"
                            editable={isEditing}
                        />

                        <Text style={styles.label}>Pays</Text>
                        {renderCountrySelector()}
                    </View>
                </View>

                {/* Dates Card */}
                <View style={styles.card}>
                    <Text style={styles.cardTitle}>📅 Dates Importantes</Text>

                    <View style={styles.form}>
                        <View style={styles.dateRow}>
                            <View style={{ flex: 1 }}>
                                <Text style={styles.label}>Début de grossesse (LMP)</Text>
                                <Text style={styles.dateHint}>Date de vos dernières règles</Text>
                            </View>
                            <TouchableOpacity
                                style={styles.dateButton}
                                onPress={() => isEditing && setShowDatePicker(true)}
                                disabled={!isEditing}
                            >
                                <Text style={[styles.dateButtonText, !isEditing && styles.dateButtonTextDisabled]}>
                                    {format(lmp, 'dd MMM yyyy', { locale: fr })}
                                </Text>
                            </TouchableOpacity>
                        </View>

                        {showDatePicker && (
                            <DateTimePicker
                                value={lmp}
                                mode="date"
                                display="default"
                                onChange={(event, selectedDate) => {
                                    setShowDatePicker(false);
                                    if (selectedDate) {
                                        setLmp(selectedDate);
                                    }
                                }}
                                maximumDate={new Date()}
                            />
                        )}

                        <View style={styles.separator} />

                        <View style={styles.dpaContainer}>
                            <Text style={styles.label}>Date Prévue d'Accouchement (DPA)</Text>
                            <Text style={styles.dpaText}>
                                {format(dpa, 'dd MMMM yyyy', { locale: fr })}
                            </Text>
                            <Text style={styles.dpaSubtext}>Calculée automatiquement (LMP + 280 jours)</Text>
                        </View>
                    </View>
                </View>

                {/* Action Buttons */}
                {isEditing && (
                    <View style={styles.actions}>
                        <TouchableOpacity
                            style={[styles.actionButton, styles.cancelButton]}
                            onPress={handleCancel}
                        >
                            <Text style={styles.cancelButtonText}>Annuler</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={[styles.actionButton, styles.saveButton]}
                            onPress={handleSave}
                            disabled={loading}
                        >
                            {loading ? (
                                <ActivityIndicator color="#FFFFFF" />
                            ) : (
                                <Text style={styles.saveButtonText}>💾 Enregistrer</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                )}

                {/* Logout Button */}
                {!isEditing && (
                    <>
                        <TouchableOpacity
                            style={styles.logoutButton}
                            onPress={handleLogout}
                        >
                            <Text style={styles.logoutButtonText}>🚪 Se déconnecter</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={styles.diagnosticButton}
                            onPress={() => navigation.navigate('Diagnostic')}
                        >
                            <Text style={styles.diagnosticButtonText}>🔍 Diagnostic Données</Text>
                        </TouchableOpacity>

                        {/* V1.2 NEW: Settings Button */}
                        <TouchableOpacity
                            style={[styles.diagnosticButton, { backgroundColor: '#FF6B9D' }]}
                            onPress={() => navigation.navigate('Settings')}
                        >
                            <Text style={styles.diagnosticButtonText}>⚙️ Paramètres Notifications</Text>
                        </TouchableOpacity>

                        {/* V1.3 NEW: Health Dashboard Button */}
                        <TouchableOpacity
                            style={[styles.diagnosticButton, { backgroundColor: '#9C27B0' }]}
                            onPress={() => navigation.navigate('HealthDashboard')}
                        >
                            <Text style={styles.diagnosticButtonText}>📊 Ma Santé</Text>
                        </TouchableOpacity>

                        {/* Reset Profile Button */}
                        <TouchableOpacity
                            style={styles.resetButton}
                            onPress={handleResetProfile}
                        >
                            <Text style={styles.resetButtonText}>⚠️ Réinitialiser mon profil</Text>
                        </TouchableOpacity>
                    </>
                )}

                {/* User Type Badge */}
                <View style={styles.userTypeBadge}>
                    <Text style={styles.userTypeText}>
                        {user?.isGuest ? '👤 Mode Invité' : '✓ Compte Sécurisé'}
                    </Text>
                    <Text style={styles.userTypeSubtext}>
                        {user?.isGuest
                            ? 'Vos données sont sauvegardées localement'
                            : 'Vos données sont synchronisées dans le cloud'}
                    </Text>
                </View>
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8F9FA',
    },
    header: {
        paddingTop: 60,
        paddingBottom: 32,
        alignItems: 'center',
    },
    profileCircle: {
        width: 100,
        height: 100,
        borderRadius: 50,
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 4,
        borderColor: 'rgba(255, 255, 255, 0.5)',
        marginBottom: 16,
    },
    profileLetter: {
        fontSize: 48,
        fontWeight: 'bold',
        color: '#FFFFFF',
    },
    headerTitle: {
        fontSize: 28,
        fontWeight: 'bold',
        color: '#FFFFFF',
        marginBottom: 4,
    },
    headerSubtitle: {
        fontSize: 14,
        color: 'rgba(255, 255, 255, 0.9)',
    },
    content: {
        padding: 16,
        paddingBottom: 32,
    },
    card: {
        backgroundColor: '#FFFFFF',
        borderRadius: 16,
        padding: 20,
        marginBottom: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 6,
        elevation: 3,
    },
    pregnancyCard: {
        backgroundColor: '#FFF0F7',
        borderWidth: 1,
        borderColor: '#FFD6E8',
    },
    cardHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    cardTitle: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 16,
    },
    editButton: {
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 12,
        backgroundColor: '#FF6B9D',
    },
    editButtonText: {
        color: '#FFFFFF',
        fontSize: 14,
        fontWeight: '600',
    },
    infoRow: {
        flexDirection: 'row',
        gap: 16,
    },
    infoItem: {
        flex: 1,
        backgroundColor: 'rgba(255, 107, 157, 0.1)',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
    },
    infoLabel: {
        fontSize: 12,
        color: '#888',
        marginBottom: 8,
        fontWeight: '600',
        textTransform: 'uppercase',
    },
    infoValue: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#C2185B',
    },
    form: {
        gap: 12,
    },
    label: {
        fontSize: 14,
        fontWeight: '600',
        color: '#1A1A1A',
        marginBottom: 4,
    },
    input: {
        borderWidth: 1,
        borderColor: '#E0E0E0',
        borderRadius: 12,
        padding: 14,
        fontSize: 16,
        backgroundColor: '#FFFFFF',
    },
    inputDisabled: {
        backgroundColor: '#F5F5F5',
        color: '#666',
    },
    countrySelector: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        gap: 8,
    },
    countryButton: {
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: '#E0E0E0',
        backgroundColor: '#FFFFFF',
    },
    countryButtonSelected: {
        backgroundColor: '#FF6B9D',
        borderColor: '#FF6B9D',
    },
    countryButtonText: {
        fontSize: 14,
        color: '#666',
        fontWeight: '500',
    },
    countryButtonTextSelected: {
        color: '#FFFFFF',
        fontWeight: '600',
    },
    dateRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
    dateHint: {
        fontSize: 12,
        color: '#888',
        marginTop: 2,
    },
    dateButton: {
        backgroundColor: '#E3F2FD',
        paddingHorizontal: 16,
        paddingVertical: 10,
        borderRadius: 12,
    },
    dateButtonText: {
        fontSize: 14,
        color: '#1976D2',
        fontWeight: '600',
    },
    dateButtonTextDisabled: {
        color: '#666',
    },
    separator: {
        height: 1,
        backgroundColor: '#F0F0F0',
        marginVertical: 8,
    },
    dpaContainer: {
        backgroundColor: '#FFF8E1',
        padding: 16,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#FFE082',
    },
    dpaText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#F57C00',
        marginTop: 8,
    },
    dpaSubtext: {
        fontSize: 12,
        color: '#888',
        marginTop: 4,
        fontStyle: 'italic',
    },
    actions: {
        flexDirection: 'row',
        gap: 12,
        marginBottom: 16,
    },
    actionButton: {
        flex: 1,
        paddingVertical: 14,
        borderRadius: 12,
        alignItems: 'center',
    },
    cancelButton: {
        backgroundColor: '#F5F5F5',
    },
    cancelButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#666',
    },
    saveButton: {
        backgroundColor: '#FF6B9D',
    },
    saveButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#FFFFFF',
    },
    logoutButton: {
        backgroundColor: '#FFEBEE',
        paddingVertical: 14,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 16,
    },
    logoutButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#D32F2F',
    },
    resetButton: {
        backgroundColor: '#FFF3E0',
        paddingVertical: 14,
        borderRadius: 12,
        alignItems: 'center',
        marginBottom: 16,
        borderWidth: 2,
        borderColor: '#FFB74D',
    },
    resetButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#E65100',
    },
    userTypeBadge: {
        backgroundColor: '#E3F2FD',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
    },
    userTypeText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#1976D2',
        marginBottom: 4,
    },
    userTypeSubtext: {
        fontSize: 12,
        color: '#666',
        textAlign: 'center',
    },
    diagnosticButton: {
        backgroundColor: '#4CAF50',
        padding: 16,
        borderRadius: 12,
        alignItems: 'center',
        marginTop: 12,
    },
    diagnosticButtonText: {
        color: '#FFF',
        fontSize: 16,
        fontWeight: '600',
    },
});
