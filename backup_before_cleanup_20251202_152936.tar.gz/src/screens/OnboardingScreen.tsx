import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Platform, TouchableOpacity, ScrollView, Alert } from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../context/AuthContext';
import { usePregnancy } from '../context/PregnancyContext';
import { theme } from '../theme';
import { Button } from '../components/common/Button';
import { Card } from '../components/common/Card';

const COUNTRIES = ['Tunisie', 'Maroc', 'Algérie', 'Autre'];

export const OnboardingScreen = () => {
    const { user, loginAsGuest } = useAuth();
    const { setProfile } = usePregnancy();
    const navigation = useNavigation<any>();

    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [date, setDate] = useState(new Date());
    const [showDatePicker, setShowDatePicker] = useState(false);
    const [selectedCountry, setSelectedCountry] = useState('Tunisie');
    const [loading, setLoading] = useState(false);

    const handleDateChange = (event: any, selectedDate?: Date) => {
        setShowDatePicker(Platform.OS === 'ios');
        if (selectedDate) {
            setDate(selectedDate);
        }
    };

    const handleSubmit = async () => {
        if (!firstName.trim()) {
            Alert.alert('Erreur', 'Veuillez entrer votre prénom.');
            return;
        }

        if (date > new Date()) {
            Alert.alert('Erreur', 'La date de début de grossesse ne peut pas être dans le futur.');
            return;
        }

        setLoading(true);
        try {
            // First, login as guest if not already authenticated
            // This ensures AuthContext has a user state
            if (!user) {
                await loginAsGuest(
                    firstName.trim(),
                    date, // Date object
                    selectedCountry,
                    lastName.trim() || undefined
                );
            }

            // Then set the profile in PregnancyContext
            await setProfile({
                firstName: firstName.trim(),
                lastName: lastName.trim() || undefined,
                country: selectedCountry,
                lmp: date.toISOString(),
            });

            // Navigate to Home (reset navigation stack)
            navigation.reset({
                index: 0,
                routes: [{ name: 'Home' as never }],
            });
        } catch (error) {
            console.error(error);
            Alert.alert('Erreur', 'Impossible de créer le profil.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <View style={styles.header}>
                <Text style={[theme.typography.h1, styles.title] as any}>Bienvenue</Text>
                <Text style={[theme.typography.body, styles.subtitle] as any}>
                    Accompagnement bienveillant pour votre grossesse.
                </Text>
            </View>

            <Card style={styles.formCard}>
                <Text style={[theme.typography.h3, styles.label] as any}>Votre prénom</Text>
                <TextInput
                    style={styles.textInput}
                    placeholder="Entrez votre prénom"
                    value={firstName}
                    onChangeText={setFirstName}
                    autoCapitalize="words"
                    autoCorrect={false}
                />

                <Text style={[theme.typography.h3, styles.label, { marginTop: theme.spacing.m }] as any}>Votre nom (optionnel)</Text>
                <TextInput
                    style={styles.textInput}
                    placeholder="Entrez votre nom"
                    value={lastName}
                    onChangeText={setLastName}
                    autoCapitalize="words"
                    autoCorrect={false}
                />

                <Text style={[theme.typography.h3, styles.label, { marginTop: theme.spacing.l }] as any}>Début de grossesse</Text>
                <Text style={theme.typography.caption}>Date des dernières règles ou conception</Text>

                {Platform.OS === 'android' && (
                    <TouchableOpacity onPress={() => setShowDatePicker(true)} style={styles.dateInput}>
                        <Text style={styles.dateText}>{date.toLocaleDateString('fr-FR')}</Text>
                    </TouchableOpacity>
                )}

                {(showDatePicker || Platform.OS === 'ios') && (
                    <DateTimePicker
                        value={date}
                        mode="date"
                        display="default"
                        onChange={handleDateChange}
                        maximumDate={new Date()}
                        style={styles.datePicker}
                    />
                )}

                <Text style={[theme.typography.h3, styles.label, { marginTop: theme.spacing.l }] as any}>Pays</Text>
                <View style={styles.countryContainer}>
                    {COUNTRIES.map((country) => (
                        <TouchableOpacity
                            key={country}
                            style={[
                                styles.countryButton,
                                selectedCountry === country && styles.countryButtonSelected
                            ]}
                            onPress={() => setSelectedCountry(country)}
                        >
                            <Text
                                style={[
                                    styles.countryText,
                                    selectedCountry === country && styles.countryTextSelected
                                ]}
                            >
                                {country}
                            </Text>
                        </TouchableOpacity>
                    ))}
                </View>

                <Button
                    title="Commencer"
                    onPress={handleSubmit}
                    style={styles.submitButton}
                    loading={loading}
                />
            </Card>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: theme.colors.background,
        padding: theme.spacing.l,
        justifyContent: 'center',
    },
    header: {
        marginBottom: theme.spacing.xl,
        alignItems: 'center',
    },
    title: {
        color: theme.colors.primary,
        marginBottom: theme.spacing.s,
    },
    subtitle: {
        textAlign: 'center',
        color: theme.colors.textLight,
    },
    formCard: {
        padding: theme.spacing.l,
    },
    label: {
        marginBottom: theme.spacing.xs,
    },
    textInput: {
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: theme.borderRadius.s,
        padding: theme.spacing.m,
        marginTop: theme.spacing.s,
        fontSize: 16,
        color: theme.colors.text,
        backgroundColor: theme.colors.white,
    },
    dateInput: {
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: theme.borderRadius.s,
        padding: theme.spacing.m,
        marginTop: theme.spacing.s,
        alignItems: 'center',
    },
    dateText: {
        fontSize: 16,
        color: theme.colors.text,
    },
    datePicker: {
        marginTop: theme.spacing.s,
        alignSelf: 'center',
    },
    countryContainer: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        marginTop: theme.spacing.s,
        marginHorizontal: -theme.spacing.xs / 2,
    },
    countryButton: {
        paddingVertical: theme.spacing.s,
        paddingHorizontal: theme.spacing.m,
        borderRadius: theme.borderRadius.round,
        borderWidth: 1,
        borderColor: theme.colors.border,
        backgroundColor: theme.colors.white,
        margin: theme.spacing.xs / 2,
    },
    countryButtonSelected: {
        backgroundColor: theme.colors.primary,
        borderColor: theme.colors.primary,
    },
    countryText: {
        color: theme.colors.text,
    },
    countryTextSelected: {
        color: theme.colors.white,
        fontWeight: 'bold',
    },
    submitButton: {
        marginTop: theme.spacing.xl,
    },
});
