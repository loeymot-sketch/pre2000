import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Alert, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { theme } from '../theme';
import { Button } from '../components/common/Button';

export const LoginScreen = () => {
    const { login } = useAuth();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [loading, setLoading] = useState(false);

    const handleLogin = async () => {
        if (!email.trim() || !password.trim()) {
            Alert.alert('Erreur', 'Veuillez remplir tous les champs');
            return;
        }

        setLoading(true);
        try {
            await login(email, password);
            // AuthContext will handle navigation based on profile existence
        } catch (error: any) {
            Alert.alert('Erreur', 'Email ou mot de passe incorrect');
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={theme.typography.h1}>Se connecter</Text>
            <Text style={[theme.typography.body, styles.subtitle]}>
                Retrouvez vos données sauvegardées
            </Text>

            <View style={styles.form}>
                <Text style={theme.typography.h3}>Email</Text>
                <TextInput
                    style={styles.input}
                    placeholder="votre@email.com"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                />

                <Text style={[theme.typography.h3, { marginTop: theme.spacing.m }]}>Mot de passe</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Votre mot de passe"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                    autoCapitalize="none"
                />

                <Button
                    title="Se connecter"
                    onPress={handleLogin}
                    style={styles.button}
                    loading={loading}
                />
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: theme.colors.background,
        padding: theme.spacing.l,
        justifyContent: 'center',
    },
    subtitle: {
        marginTop: theme.spacing.s,
        color: theme.colors.textLight,
        marginBottom: theme.spacing.xl,
    },
    form: {
        gap: theme.spacing.xs,
    },
    input: {
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: theme.borderRadius.s,
        padding: theme.spacing.m,
        fontSize: 16,
        backgroundColor: theme.colors.white,
        marginTop: theme.spacing.xs,
    },
    button: {
        marginTop: theme.spacing.l,
    },
});
