import React, { useEffect, useState, useMemo } from 'react';
import { View, Text, StyleSheet, FlatList, ActivityIndicator, TouchableOpacity, Alert, ScrollView, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import { useNavigation } from '@react-navigation/native';
import {
    loadCalendarTemplates,
    generateAllEvents,
    loadUserEvents,
    getCombinedEventsForWeek,
    deleteUserEvent,
    GeneratedEvent,
    groupEventsByDate,
    getWeekDates,
} from '../services/calendarService';
import { UserEvent, CombinedEvent } from '../types';
import { theme } from '../theme';
import { EventCard } from '../components/calendar/EventCard';
import { WeeklyStrip } from '../components/calendar/WeeklyStrip';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameDay, isSameMonth, addMonths, subMonths } from 'date-fns';
import { fr } from 'date-fns/locale';

type ViewMode = 'suggestions' | 'myEvents' | 'all';
type CalendarView = 'week' | 'month';

export const CalendarScreen = () => {
    const { user } = useAuth();
    const navigation = useNavigation<any>();

    // State
    const [currentWeek, setCurrentWeek] = useState(user?.currentWeek || 1);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [viewMode, setViewMode] = useState<ViewMode>('all');
    const [calendarView, setCalendarView] = useState<CalendarView>('week');

    // Data
    const [allTemplateEvents, setAllTemplateEvents] = useState<GeneratedEvent[]>([]);
    const [userEvents, setUserEvents] = useState<UserEvent[]>([]);
    const [loading, setLoading] = useState(true);

    // Animation
    const [fadeAnim] = useState(new Animated.Value(0));

    useEffect(() => {
        Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 500,
            useNativeDriver: true,
        }).start();
    }, []);

    // Sync currentWeek with user profile when it changes
    useEffect(() => {
        if (user?.currentWeek) {
            setCurrentWeek(user.currentWeek);
            const { start, end } = getWeekDates(new Date(user.pregnancyStartDate), user.currentWeek);
            const today = new Date();
            if (today >= start && today <= end) {
                setSelectedDate(today);
            } else {
                setSelectedDate(start);
            }
        }
    }, [user?.currentWeek]);

    // Load initial data
    useEffect(() => {
        const loadData = async () => {
            if (!user?.pregnancyStartDate) return;

            setLoading(true);
            try {
                const [templates, uEvents] = await Promise.all([
                    loadCalendarTemplates(),
                    loadUserEvents(user.uid)
                ]);

                const generatedEvents = generateAllEvents(templates, new Date(user.pregnancyStartDate));
                setAllTemplateEvents(generatedEvents);
                setUserEvents(uEvents);
            } catch (error) {
                console.error('Error loading calendar data:', error);
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, [user?.pregnancyStartDate, user?.uid]);

    // Refresh user events when screen focuses
    useEffect(() => {
        const unsubscribe = navigation.addListener('focus', () => {
            if (user?.uid) {
                loadUserEvents(user.uid).then(setUserEvents);
            }
        });
        return unsubscribe;
    }, [navigation, user?.uid]);

    // Derived Data
    const weekDates = useMemo(() => {
        if (!user?.pregnancyStartDate) return { start: new Date(), end: new Date() };
        return getWeekDates(new Date(user.pregnancyStartDate), currentWeek);
    }, [user?.pregnancyStartDate, currentWeek]);

    const currentWeekEvents = useMemo(() => {
        return getCombinedEventsForWeek(allTemplateEvents, userEvents, currentWeek);
    }, [allTemplateEvents, userEvents, currentWeek]);

    const eventsByDate = useMemo(() => {
        return groupEventsByDate(currentWeekEvents);
    }, [currentWeekEvents]);

    const allEventsByDate = useMemo(() => {
        const grouped: Record<string, CombinedEvent[]> = {};

        // Add template events
        allTemplateEvents.forEach((event) => {
            const dateKey = new Date(event.date).toISOString().split('T')[0];
            if (!grouped[dateKey]) grouped[dateKey] = [];
            grouped[dateKey].push({
                id: event.id || event.templateId || `template-${event.week}-${event.title}`,
                title: event.title,
                date: new Date(event.date),
                description: event.description || '',
                type: event.type,
                week: event.week,
                source: 'template' as const,
            });
        });

        // Add user events
        userEvents.forEach((event) => {
            const dateKey = new Date(event.date).toISOString().split('T')[0];
            if (!grouped[dateKey]) grouped[dateKey] = [];
            grouped[dateKey].push({
                id: event.event_id,
                title: event.title,
                date: new Date(event.date),
                description: event.notes || '',
                type: event.type,
                week: event.week,
                source: 'user' as const,
            });
        });

        return grouped;
    }, [allTemplateEvents, userEvents]);

    // Count events this week
    const eventsThisWeekCount = useMemo(() => {
        const weekStart = weekDates.start;
        const weekEnd = weekDates.end;
        return currentWeekEvents.length;
    }, [currentWeekEvents, weekDates]);

    const filteredEvents = useMemo(() => {
        const dateKey = selectedDate.toISOString().split('T')[0];
        const dayEvents = (calendarView === 'week' ? eventsByDate : allEventsByDate)[dateKey] || [];

        if (viewMode === 'all') return dayEvents;
        if (viewMode === 'suggestions') return dayEvents.filter(e => e.source === 'template');
        if (viewMode === 'myEvents') return dayEvents.filter(e => e.source === 'user');
        return dayEvents;
    }, [eventsByDate, allEventsByDate, selectedDate, viewMode, calendarView]);

    const eventCounts = useMemo(() => {
        const counts: Record<string, number> = {};
        Object.keys(calendarView === 'week' ? eventsByDate : allEventsByDate).forEach(date => {
            counts[date] = (calendarView === 'week' ? eventsByDate : allEventsByDate)[date].length;
        });
        return counts;
    }, [eventsByDate, allEventsByDate, calendarView]);

    // Month view data
    const monthDays = useMemo(() => {
        const start = startOfMonth(selectedDate);
        const end = endOfMonth(selectedDate);
        return eachDayOfInterval({ start, end });
    }, [selectedDate]);

    const monthStats = useMemo(() => {
        const monthKey = format(selectedDate, 'yyyy-MM');
        let totalEvents = 0;
        let userEventCount = 0;
        let suggestionCount = 0;

        Object.keys(allEventsByDate).forEach(dateKey => {
            if (dateKey.startsWith(monthKey)) {
                const events = allEventsByDate[dateKey];
                totalEvents += events.length;
                userEventCount += events.filter(e => e.source === 'user').length;
                suggestionCount += events.filter(e => e.source === 'template').length;
            }
        });

        return { totalEvents, userEventCount, suggestionCount };
    }, [allEventsByDate, selectedDate]);

    // Handlers
    const handlePrevWeek = () => {
        if (currentWeek > 1) {
            const newWeek = currentWeek - 1;
            setCurrentWeek(newWeek);
            const { start } = getWeekDates(new Date(user!.pregnancyStartDate), newWeek);
            setSelectedDate(start);
        }
    };

    const handleNextWeek = () => {
        if (currentWeek < 40) {
            const newWeek = currentWeek + 1;
            setCurrentWeek(newWeek);
            const { start } = getWeekDates(new Date(user!.pregnancyStartDate), newWeek);
            setSelectedDate(start);
        }
    };

    const handlePrevMonth = () => {
        setSelectedDate(subMonths(selectedDate, 1));
    };

    const handleNextMonth = () => {
        setSelectedDate(addMonths(selectedDate, 1));
    };

    const handleToday = () => {
        if (user?.currentWeek) {
            setCurrentWeek(user.currentWeek);
            setSelectedDate(new Date());
        }
    };

    const handleDeleteEvent = async (eventId: string) => {
        Alert.alert(
            "Supprimer l'événement",
            "Êtes-vous sûre de vouloir supprimer cet événement ?",
            [
                { text: "Annuler", style: "cancel" },
                {
                    text: "Supprimer",
                    style: "destructive",
                    onPress: async () => {
                        try {
                            await deleteUserEvent(eventId);
                            const updatedEvents = await loadUserEvents(user!.uid);
                            setUserEvents(updatedEvents);
                        } catch (error) {
                            Alert.alert("Erreur", "Impossible de supprimer l'événement");
                        }
                    }
                }
            ]
        );
    };

    const renderMonthDay = (day: Date) => {
        const dateKey = day.toISOString().split('T')[0];
        const hasEvents = eventCounts[dateKey] > 0;
        const isSelected = isSameDay(day, selectedDate);
        const isToday = isSameDay(day, new Date());
        const isCurrentMonth = isSameMonth(day, selectedDate);

        return (
            <TouchableOpacity
                key={day.toISOString()}
                style={[
                    styles.monthDay,
                    isSelected && styles.monthDaySelected,
                    isToday && !isSelected && styles.monthDayToday,
                ]}
                onPress={() => setSelectedDate(day)}
                activeOpacity={0.7}
            >
                <Text
                    style={[
                        styles.monthDayText,
                        !isCurrentMonth && styles.monthDayTextDisabled,
                        isSelected && styles.monthDayTextSelected,
                        isToday && !isSelected && styles.monthDayTextToday,
                    ]}
                >
                    {format(day, 'd')}
                </Text>
                {hasEvents && (
                    <View style={[styles.eventDot, isSelected && styles.eventDotSelected]} />
                )}
            </TouchableOpacity>
        );
    };

    const renderHeader = () => (
        <LinearGradient
            colors={['#FF6B9D', '#C2185B']}
            style={styles.headerGradient}
        >
            <View style={styles.headerContent}>
                <View style={styles.monthRow}>
                    <TouchableOpacity
                        onPress={calendarView === 'week' ? handlePrevWeek : handlePrevMonth}
                        disabled={calendarView === 'week' && currentWeek <= 1}
                        style={styles.navButton}
                    >
                        <Text style={[styles.navArrow, calendarView === 'week' && currentWeek <= 1 && styles.disabledArrow]}>‹</Text>
                    </TouchableOpacity>

                    <View style={styles.monthContainer}>
                        <Text style={styles.monthText}>
                            {format(selectedDate, 'MMMM yyyy', { locale: fr })}
                        </Text>
                        {calendarView === 'week' && (
                            <Text style={styles.weekText}>Semaine {currentWeek} de grossesse</Text>
                        )}
                    </View>

                    <TouchableOpacity
                        onPress={calendarView === 'week' ? handleNextWeek : handleNextMonth}
                        disabled={calendarView === 'week' && currentWeek >= 40}
                        style={styles.navButton}
                    >
                        <Text style={[styles.navArrow, calendarView === 'week' && currentWeek >= 40 && styles.disabledArrow]}>›</Text>
                    </TouchableOpacity>
                </View>

                {/* Header Actions */}
                <View style={styles.headerActions}>
                    {/* Badge Count */}
                    {eventsThisWeekCount > 0 && calendarView === 'week' && (
                        <View style={styles.weekBadge}>
                            <Text style={styles.weekBadgeText}>
                                {eventsThisWeekCount} RDV cette semaine
                            </Text>
                        </View>
                    )}

                    {/* Today Button (conditional) */}
                    {!isSameDay(selectedDate, new Date()) && (
                        <TouchableOpacity
                            style={styles.todayButton}
                            onPress={() => setSelectedDate(new Date())}
                        >
                            <Text style={styles.todayButtonText}>🏠 Aujourd'hui</Text>
                        </TouchableOpacity>
                    )}

                    {/* View Toggle */}
                    <View style={styles.viewToggleContainer}>
                        <TouchableOpacity
                            style={[
                                styles.viewToggle,
                                calendarView === 'week' && styles.viewToggleActive
                            ]}
                            onPress={() => setCalendarView('week')}
                        >
                            <Text style={[
                                styles.viewToggleText,
                                calendarView === 'week' && styles.viewToggleTextActive
                            ]}>
                                Semaine
                            </Text>
                        </TouchableOpacity>
                        <TouchableOpacity
                            style={[
                                styles.viewToggle,
                                calendarView === 'month' && styles.viewToggleActive
                            ]}
                            onPress={() => setCalendarView('month')}
                        >
                            <Text style={[
                                styles.viewToggleText,
                                calendarView === 'month' && styles.viewToggleTextActive
                            ]}>
                                Mois
                            </Text>
                        </TouchableOpacity>
                    </View>
                </View>
            </View>
        </LinearGradient>
    );

    const renderMonthStats = () => (
        <View style={styles.statsCard}>
            <Text style={styles.statsTitle}>📊 Ce mois</Text>
            <View style={styles.statsRow}>
                <View style={styles.statItem}>
                    <Text style={styles.statValue}>{monthStats.totalEvents}</Text>
                    <Text style={styles.statLabel}>Total</Text>
                </View>
                <View style={styles.statItem}>
                    <Text style={[styles.statValue, { color: '#FF6B9D' }]}>{monthStats.userEventCount}</Text>
                    <Text style={styles.statLabel}>Mes RDV</Text>
                </View>
                <View style={styles.statItem}>
                    <Text style={[styles.statValue, { color: '#1976D2' }]}>{monthStats.suggestionCount}</Text>
                    <Text style={styles.statLabel}>Suggestions</Text>
                </View>
            </View>
        </View>
    );

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color="#FF6B9D" />
                <Text style={styles.loadingText}>Chargement de votre agenda...</Text>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {renderHeader()}

            <Animated.View style={{ flex: 1, opacity: fadeAnim }}>
                {calendarView === 'month' ? (
                    <>
                        {renderMonthStats()}
                        <View style={styles.monthGrid}>
                            <View style={styles.weekDaysHeader}>
                                {['L', 'M', 'M', 'J', 'V', 'S', 'D'].map((day, index) => (
                                    <Text key={index} style={styles.weekDayLabel}>{day}</Text>
                                ))}
                            </View>
                            <View style={styles.monthDaysGrid}>
                                {monthDays.map(renderMonthDay)}
                            </View>
                        </View>
                    </>
                ) : (
                    <WeeklyStrip
                        weekStartDate={weekDates.start}
                        selectedDate={selectedDate}
                        onDateSelect={setSelectedDate}
                        eventCounts={eventCounts}
                    />
                )}

                {/* Filter chips removed as requested */}

                <FlatList
                    data={filteredEvents}
                    keyExtractor={(item) => item.id}
                    renderItem={({ item }) => (
                        <EventCard
                            event={item}
                            onDelete={item.source === 'user' ? () => handleDeleteEvent(item.id) : undefined}
                        />
                    )}
                    contentContainerStyle={styles.listContent}
                    ListEmptyComponent={
                        <View style={styles.emptyState}>
                            <Text style={styles.emptyEmoji}>📅</Text>
                            <Text style={styles.emptyStateText}>Aucun événement pour ce jour</Text>
                            <Text style={styles.emptyStateSubtext}>Profitez-en pour vous reposer ! 💆‍♀️</Text>
                            <TouchableOpacity
                                style={[styles.todayButton, { marginTop: 16, backgroundColor: '#FF6B9D', paddingHorizontal: 24 }]}
                                onPress={() => navigation.navigate('AddAppointment', { selectedDate: selectedDate.toISOString() })}
                            >
                                <Text style={[styles.todayButtonText, { fontSize: 14 }]}>+ Ajouter un RDV</Text>
                            </TouchableOpacity>
                        </View>
                    }
                />
            </Animated.View>

            <TouchableOpacity
                style={styles.fab}
                onPress={() => navigation.navigate('AddAppointment', { selectedDate: selectedDate.toISOString() })}
            >
                <LinearGradient
                    colors={['#FF6B9D', '#C2185B']}
                    style={styles.fabGradient}
                >
                    <Text style={styles.fabIcon}>+</Text>
                </LinearGradient>
            </TouchableOpacity>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#F8F9FA',
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
        backgroundColor: '#F8F9FA',
    },
    loadingText: {
        marginTop: 16,
        color: '#666',
        fontSize: 15,
    },
    headerGradient: {
        paddingTop: 60,
        paddingBottom: 20,
        paddingHorizontal: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.2,
        shadowRadius: 8,
        elevation: 8,
    },
    headerContent: {},
    monthRow: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 16,
    },
    navButton: {
        width: 40,
        height: 40,
        justifyContent: 'center',
        alignItems: 'center',
    },
    monthContainer: {
        alignItems: 'center',
        flex: 1,
    },
    monthText: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#FFFFFF',
        textTransform: 'capitalize',
    },
    weekText: {
        fontSize: 13,
        color: 'rgba(255, 255, 255, 0.9)',
        fontWeight: '600',
        marginTop: 4,
    },
    navArrow: {
        fontSize: 32,
        color: '#FFFFFF',
        fontWeight: 'bold',
    },
    disabledArrow: {
        opacity: 0.3,
    },
    headerActions: {
        flexDirection: 'row',
        flexWrap: 'wrap',
        alignItems: 'center',
        justifyContent: 'flex-start',
        gap: 8,
        paddingHorizontal: 16,
        paddingBottom: 12,
    },
    weekBadge: {
        backgroundColor: 'rgba(255, 255, 255, 0.25)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.4)',
    },
    weekBadgeText: {
        color: '#FFF',
        fontSize: 12,
        fontWeight: '600',
    },
    todayButton: {
        backgroundColor: 'rgba(255, 255, 255, 0.3)',
        paddingHorizontal: 12,
        paddingVertical: 6,
        borderRadius: 20,
        borderWidth: 1,
        borderColor: 'rgba(255, 255, 255, 0.5)',
    },
    todayButtonText: {
        color: '#FFF',
        fontSize: 12,
        fontWeight: '600',
    },
    viewToggleContainer: {
        flexDirection: 'row',
        backgroundColor: 'rgba(255, 255, 255, 0.2)',
        borderRadius: 20,
        padding: 2,
    },
    viewToggle: {
        paddingHorizontal: 16,
        paddingVertical: 6,
        borderRadius: 18,
    },
    viewToggleActive: {
        backgroundColor: '#FFF',
    },
    viewToggleText: {
        fontSize: 12,
        fontWeight: '600',
        color: 'rgba(255, 255, 255, 0.9)',
    },
    viewToggleTextActive: {
        color: '#C2185B',
    },
    statsCard: {
        backgroundColor: '#FFFFFF',
        marginHorizontal: 16,
        marginTop: 16,
        marginBottom: 12,
        padding: 16,
        borderRadius: 16,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 6,
        elevation: 3,
    },
    statsTitle: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 12,
    },
    statsRow: {
        flexDirection: 'row',
        justifyContent: 'space-around',
    },
    statItem: {
        alignItems: 'center',
    },
    statValue: {
        fontSize: 24,
        fontWeight: 'bold',
        color: '#1A1A1A',
    },
    statLabel: {
        fontSize: 12,
        color: '#888',
        marginTop: 4,
    },
    monthGrid: {
        backgroundColor: '#FFFFFF',
        marginHorizontal: 16,
        marginVertical: 12,
        borderRadius: 16,
        padding: 12,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 6,
        elevation: 3,
    },
    weekDaysHeader: {
        flexDirection: 'row',
        marginBottom: 8,
    },
    weekDayLabel: {
        flex: 1,
        textAlign: 'center',
        fontSize: 12,
        fontWeight: '600',
        color: '#888',
    },
    monthDaysGrid: {
        flexDirection: 'row',
        flexWrap: 'wrap',
    },
    monthDay: {
        width: '14.28%',
        aspectRatio: 1,
        justifyContent: 'center',
        alignItems: 'center',
        borderRadius: 8,
        marginVertical: 2,
    },
    monthDaySelected: {
        backgroundColor: '#FF6B9D',
    },
    monthDayToday: {
        backgroundColor: '#E3F2FD',
    },
    monthDayText: {
        fontSize: 14,
        color: '#1A1A1A',
        fontWeight: '500',
    },
    monthDayTextSelected: {
        color: '#FFFFFF',
        fontWeight: 'bold',
    },
    monthDayTextToday: {
        color: '#1976D2',
        fontWeight: 'bold',
    },
    monthDayTextDisabled: {
        color: '#CCCCCC',
    },
    eventDot: {
        width: 4,
        height: 4,
        borderRadius: 2,
        backgroundColor: '#FF6B9D',
        position: 'absolute',
        bottom: 4,
    },
    eventDotSelected: {
        backgroundColor: '#FFFFFF',
    },
    filterContainer: {
        flexDirection: 'row',
        paddingHorizontal: 16,
        paddingBottom: 12,
        gap: 8,
    },
    filterChip: {
        paddingVertical: 8,
        paddingHorizontal: 16,
        borderRadius: 20,
        backgroundColor: '#FFFFFF',
        borderWidth: 1,
        borderColor: '#E0E0E0',
    },
    activeFilterChip: {
        backgroundColor: '#FF6B9D',
        borderColor: '#FF6B9D',
    },
    filterText: {
        fontSize: 14,
        color: '#666',
        fontWeight: '500',
    },
    activeFilterText: {
        color: '#FFFFFF',
        fontWeight: '600',
    },
    listContent: {
        paddingHorizontal: 16,
        paddingBottom: 80,
    },
    emptyState: {
        alignItems: 'center',
        marginTop: 40,
        padding: 24,
    },
    emptyEmoji: {
        fontSize: 48,
        marginBottom: 16,
    },
    emptyStateText: {
        fontSize: 16,
        fontWeight: 'bold',
        color: '#1A1A1A',
        marginBottom: 8,
    },
    emptyStateSubtext: {
        fontSize: 14,
        color: '#888',
    },
    fab: {
        position: 'absolute',
        right: 20,
        bottom: 20,
        width: 56,
        height: 56,
        borderRadius: 28,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
    },
    fabGradient: {
        width: 56,
        height: 56,
        borderRadius: 28,
        justifyContent: 'center',
        alignItems: 'center',
    },
    fabIcon: {
        fontSize: 32,
        color: '#FFFFFF',
        fontWeight: '300',
    },
});
