import React, { useState } from 'react';
import { View, Text, StyleSheet, TextInput, Alert, ScrollView } from 'react-native';
import { useAuth } from '../context/AuthContext';
import { theme } from '../theme';
import { Button } from '../components/common/Button';
import { useNavigation } from '@react-navigation/native';

export const RegisterScreen = () => {
    const { register } = useAuth();
    const navigation = useNavigation<any>();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [loading, setLoading] = useState(false);

    const handleRegister = async () => {
        if (!email.trim() || !password.trim()) {
            Alert.alert('Erreur', 'Veuillez remplir tous les champs');
            return;
        }

        if (password.length < 6) {
            Alert.alert('Erreur', 'Le mot de passe doit contenir au moins 6 caractères');
            return;
        }

        if (password !== confirmPassword) {
            Alert.alert('Erreur', 'Les mots de passe ne correspondent pas');
            return;
        }

        setLoading(true);
        try {
            await register(email, password);
            // Navigate to onboarding to complete profile
            navigation.navigate('Onboarding');
        } catch (error: any) {
            Alert.alert('Erreur', error.message || 'Impossible de créer le compte');
        } finally {
            setLoading(false);
        }
    };

    return (
        <ScrollView contentContainerStyle={styles.container}>
            <Text style={theme.typography.h1}>Créer un compte</Text>
            <Text style={[theme.typography.body, styles.subtitle]}>
                Vos données seront sauvegardées de manière sécurisée
            </Text>

            <View style={styles.form}>
                <Text style={theme.typography.h3}>Email</Text>
                <TextInput
                    style={styles.input}
                    placeholder="votre@email.com"
                    value={email}
                    onChangeText={setEmail}
                    keyboardType="email-address"
                    autoCapitalize="none"
                    autoCorrect={false}
                />

                <Text style={[theme.typography.h3, { marginTop: theme.spacing.m }]}>Mot de passe</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Minimum 6 caractères"
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                    autoCapitalize="none"
                />

                <Text style={[theme.typography.h3, { marginTop: theme.spacing.m }]}>Confirmer le mot de passe</Text>
                <TextInput
                    style={styles.input}
                    placeholder="Retapez votre mot de passe"
                    value={confirmPassword}
                    onChangeText={setConfirmPassword}
                    secureTextEntry
                    autoCapitalize="none"
                />

                <Button
                    title="Créer mon compte"
                    onPress={handleRegister}
                    style={styles.button}
                    loading={loading}
                />
            </View>
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flexGrow: 1,
        backgroundColor: theme.colors.background,
        padding: theme.spacing.l,
        justifyContent: 'center',
    },
    subtitle: {
        marginTop: theme.spacing.s,
        color: theme.colors.textLight,
        marginBottom: theme.spacing.xl,
    },
    form: {
        gap: theme.spacing.xs,
    },
    input: {
        borderWidth: 1,
        borderColor: theme.colors.border,
        borderRadius: theme.borderRadius.s,
        padding: theme.spacing.m,
        fontSize: 16,
        backgroundColor: theme.colors.white,
        marginTop: theme.spacing.xs,
    },
    button: {
        marginTop: theme.spacing.l,
    },
});
