import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Supplement } from '../types';
import { theme } from '../theme';
import { Tag } from '../components/common/Tag';
import { Card } from '../components/common/Card';
import { useRoute } from '@react-navigation/native';

export const SupplementDetailScreen = () => {
    const route = useRoute<any>();
    const { supplementId } = route.params;
    const [supplement, setSupplement] = useState<Supplement | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchSupplement = async () => {
            try {
                const docRef = doc(db, 'supplements', supplementId);
                const docSnap = await getDoc(docRef);

                if (docSnap.exists()) {
                    setSupplement(docSnap.data() as Supplement);
                }
            } catch (error) {
                console.error('Error fetching supplement details:', error);
            } finally {
                setLoading(false);
            }
        };

        fetchSupplement();
    }, [supplementId]);

    if (loading) {
        return (
            <View style={styles.centerContainer}>
                <ActivityIndicator size="large" color={theme.colors.primary} />
            </View>
        );
    }

    if (!supplement) {
        return (
            <View style={styles.centerContainer}>
                <Text style={theme.typography.body}>Complément non trouvé.</Text>
            </View>
        );
    }

    const getSafetyColor = (safety: string) => {
        switch (safety) {
            case 'ok': return theme.colors.success;
            case 'a_surveiller': return theme.colors.warning;
            case 'deconseille': return theme.colors.error;
            default: return theme.colors.secondary;
        }
    };

    return (
        <ScrollView style={styles.container} contentContainerStyle={styles.contentContainer}>
            <View style={styles.header}>
                <Tag label={supplement.pregnancy_safety} color={getSafetyColor(supplement.pregnancy_safety)} />
                <Text style={[theme.typography.h1, styles.title] as any}>{supplement.name_fr}</Text>
                <Text style={theme.typography.caption}>{supplement.category}</Text>
            </View>

            {supplement.short_description_fr && (
                <Card style={styles.card}>
                    <Text style={theme.typography.body}>{supplement.short_description_fr}</Text>
                </Card>
            )}

            {supplement.pregnancy_notes_fr && (
                <Card style={styles.card}>
                    <Text style={[theme.typography.h3, styles.sectionTitle] as any}>À propos</Text>
                    <Text style={theme.typography.body}>{supplement.pregnancy_notes_fr}</Text>
                </Card>
            )}

            {supplement.typical_dose_text_fr && (
                <Card style={styles.card}>
                    <Text style={[theme.typography.h3, styles.sectionTitle] as any}>Dose typique</Text>
                    <Text style={theme.typography.body}>{supplement.typical_dose_text_fr}</Text>
                </Card>
            )}

            {supplement.precautions_fr && (
                <Card style={[styles.card, { borderColor: theme.colors.warning, borderWidth: 1 }]}>
                    <Text style={[theme.typography.h3, styles.sectionTitle, { color: theme.colors.warning }] as any}>Précautions</Text>
                    <Text style={theme.typography.body}>{supplement.precautions_fr}</Text>
                </Card>
            )}

            {supplement.sources && (
                <Text style={[theme.typography.caption, styles.source]}>{`Source : ${supplement.sources}`}</Text>
            )}
        </ScrollView>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: theme.colors.background,
    },
    contentContainer: {
        padding: theme.spacing.m,
        paddingBottom: theme.spacing.xl,
    },
    centerContainer: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    header: {
        marginBottom: theme.spacing.l,
    },
    title: {
        marginTop: theme.spacing.s,
        marginBottom: theme.spacing.xs,
    },
    card: {
        marginBottom: theme.spacing.m,
    },
    sectionTitle: {
        marginBottom: theme.spacing.s,
    },
    source: {
        textAlign: 'center',
        marginTop: theme.spacing.m,
        fontStyle: 'italic',
    },
});
