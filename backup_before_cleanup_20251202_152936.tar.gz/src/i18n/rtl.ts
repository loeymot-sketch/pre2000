import { I18nManager } from 'react-native';
import i18n from './index';
import * as Updates from 'expo-updates';

export const isRTL = (): boolean => {
    return i18n.language === 'ar';
};

export const setupRTL = async () => {
    const shouldBeRTL = isRTL();

    if (I18nManager.isRTL !== shouldBeRTL) {
        I18nManager.forceRTL(shouldBeRTL);
        I18nManager.allowRTL(shouldBeRTL);

        // Reload app to apply RTL changes
        try {
            await Updates.reloadAsync();
        } catch (error) {
            console.warn('Could not reload app for RTL change:', error);
        }
    }
};

export const changeLanguage = async (lang: string) => {
    await i18n.changeLanguage(lang);
    await setupRTL();
};
