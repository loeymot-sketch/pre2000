import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Import translations
import fr from './locales/fr';
import ar from './locales/ar';
import en from './locales/en';

const LANGUAGE_DETECTOR = {
    type: 'languageDetector' as const,
    async: true,
    detect: async (callback: (lang: string) => void) => {
        try {
            const savedLang = await AsyncStorage.getItem('app_locale');
            callback(savedLang || 'fr');
        } catch (error) {
            console.log('[i18n] Error detecting language:', error);
            callback('fr');
        }
    },
    init: () => { },
    cacheUserLanguage: async (lang: string) => {
        try {
            await AsyncStorage.setItem('app_locale', lang);
        } catch (error) {
            console.log('[i18n] Error caching language:', error);
        }
    },
};

i18n
    .use(LANGUAGE_DETECTOR as any)
    .use(initReactI18next)
    .init({
        resources: {
            fr: { translation: fr },
            ar: { translation: ar },
            en: { translation: en },
        },
        fallbackLng: 'fr',
        lng: 'fr', // Default language
        interpolation: {
            escapeValue: false,
        },
        react: {
            useSuspense: false,
        },
    });

console.log('[i18n] ✅ i18n initialized');

export default i18n;
