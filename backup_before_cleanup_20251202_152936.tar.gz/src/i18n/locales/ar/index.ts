import authAr from './auth.json';
import commonAr from './common.json';

export default {
    ...authAr,
    ...commonAr,
};
