import authFr from './auth.json';
import commonFr from './common.json';

export default {
    ...authFr,
    ...commonFr,
};
