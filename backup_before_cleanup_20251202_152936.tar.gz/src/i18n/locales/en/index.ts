import authEn from './auth.json';
import commonEn from './common.json';

export default {
    ...authEn,
    ...commonEn,
};
