export const theme = {
    colors: {
        primary: '#FF9E80', // Soft Peach
        secondary: '#FFCCBC', // Lighter Peach
        background: '#FFF5F2', // Very light peach/white
        text: '#4E342E', // Dark Brown for text (softer than black)
        textLight: '#8D6E63', // Light Brown
        white: '#FFFFFF',
        error: '#E57373', // Soft Red
        success: '#81C784', // Soft Green
        warning: '#FFB74D', // Soft Orange
        cardBackground: '#FFFFFF',
        border: '#FFAB91',
    },
    spacing: {
        xs: 4,
        s: 8,
        m: 16,
        l: 24,
        xl: 32,
    },
    borderRadius: {
        s: 8,
        m: 12,
        l: 20,
        round: 999,
    },
    typography: {
        h1: {
            fontSize: 28,
            fontWeight: 'bold' as const,
            color: '#4E342E',
        },
        h2: {
            fontSize: 22,
            fontWeight: 'bold' as const,
            color: '#4E342E',
        },
        h3: {
            fontSize: 18,
            fontWeight: 'bold' as const,
            color: '#4E342E',
        },
        body: {
            fontSize: 16,
            color: '#4E342E',
            lineHeight: 24,
        },
        caption: {
            fontSize: 14,
            color: '#8D6E63',
        },
    },
};
