
import React, { createContext, useState, useContext, useEffect } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut,
    onAuthStateChanged,
    User as FirebaseUser
} from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db, auth } from '../config/firebase';
import { UserProfile } from '../types';

interface AuthContextType {
    user: UserProfile | null;
    firebaseUser: FirebaseUser | null;
    loading: boolean;
    register: (email: string, password: string) => Promise<void>;
    login: (email: string, password: string) => Promise<void>;
    loginAsGuest: (firstName: string, pregnancyStartDate: Date, country: string, lastName?: string) => Promise<void>;
    logout: () => Promise<void>;
    updateProfile: (data: Partial<UserProfile>) => Promise<void>;
    setLocale: (locale: string) => Promise<void>;
    resetProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);


// Calculate current week from LMP (Last Menstrual Period)
const calculateCurrentWeek = (lmpDate: Date): number => {
    const now = new Date();
    const diffMs = now.getTime() - lmpDate.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7) + 1; // Add 1 because pregnancy is counted from week 1
    return Math.max(1, Math.min(40, weeks)); // Clamp between 1-40
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const [user, setUser] = useState<UserProfile | null>(null);
    const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
    const [loading, setLoading] = useState<boolean>(true);

    useEffect(() => {
        // Listen to Firebase auth state
        const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
            setFirebaseUser(fbUser);
            if (fbUser) {
                // Load profile from Firestore for authenticated users
                try {
                    const docSnap = await getDoc(doc(db, 'userProfiles', fbUser.uid));
                    if (docSnap.exists()) {
                        const profile = docSnap.data() as UserProfile;

                        // Recalculate current week to ensure it's up to date
                        if (profile.pregnancyStartDate) {
                            const lmpDate = new Date(profile.pregnancyStartDate);
                            const calculatedWeek = calculateCurrentWeek(lmpDate);

                            if (calculatedWeek !== profile.currentWeek) {
                                console.log(`[AuthContext] 🔄 Updating current week from ${profile.currentWeek} to ${calculatedWeek}`);
                                profile.currentWeek = calculatedWeek;
                                // Update in Firestore silently
                                setDoc(doc(db, 'userProfiles', fbUser.uid), { currentWeek: calculatedWeek }, { merge: true });
                            }
                        }

                        setUser(profile);
                        await AsyncStorage.setItem('user_profile', JSON.stringify(profile));
                    }
                } catch (error) {
                    console.error('Failed to load user profile:', error);
                }
            }
            // Don't load guest profile automatically - let user go through auth flow
            setLoading(false);
        });

        return unsubscribe;
    }, []);

    const register = async (email: string, password: string) => {
        console.log('[AuthContext] 📝 Registering new user:', email);
        try {
            const userCredential = await createUserWithEmailAndPassword(auth, email, password);
            setFirebaseUser(userCredential.user);
            console.log('[AuthContext] ✅ User registered successfully:', userCredential.user.uid);
            // Profile will be created in onboarding
        } catch (error) {
            console.error('[AuthContext] ❌ Registration error:', error);
            throw error;
        }
    };

    const login = async (email: string, password: string) => {
        console.log('[AuthContext] 🔐 Logging in user:', email);
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            setFirebaseUser(userCredential.user);
            console.log('[AuthContext] ✅ User logged in:', userCredential.user.uid);

            // Load profile
            const docSnap = await getDoc(doc(db, 'userProfiles', userCredential.user.uid));
            if (docSnap.exists()) {
                const profile = docSnap.data() as UserProfile;
                setUser(profile);
                await AsyncStorage.setItem('user_profile', JSON.stringify(profile));
                console.log('[AuthContext] ✅ User profile loaded from Firestore');
            } else {
                console.warn('[AuthContext] ⚠️ User profile not found in Firestore');
            }
        } catch (error) {
            console.error('[AuthContext] ❌ Login error:', error);
            throw error;
        }
    };

    const loginAsGuest = async (firstName: string, pregnancyStartDate: Date, country: string, lastName?: string) => {
        console.log('[AuthContext] 👤 Creating guest profile:', { firstName, lastName, country });
        const currentWeek = calculateCurrentWeek(pregnancyStartDate);
        console.log('[AuthContext] 📅 Calculated current week:', currentWeek);

        const newUser: UserProfile = {
            uid: firebaseUser?.uid || 'guest_' + Date.now(),
            email: firebaseUser?.email || undefined,
            firstName,
            lastName,
            pregnancyStartDate: pregnancyStartDate.toISOString(),
            currentWeek,
            country,
            isGuest: !firebaseUser,
        };

        try {
            // Save to AsyncStorage for offline access only (no Firestore write for guest)
            await AsyncStorage.setItem('user_profile', JSON.stringify(newUser));
            console.log('[AuthContext] ✅ Guest profile saved to AsyncStorage');

            setUser(newUser);
        } catch (error) {
            console.error('[AuthContext] ❌ Failed to save guest profile:', error);
            throw error;
        }
    };

    const logout = async () => {
        try {
            if (firebaseUser) {
                await signOut(auth);
            }
            await AsyncStorage.removeItem('user_profile');
            setUser(null);
            setFirebaseUser(null);
        } catch (error) {
            console.error('Failed to logout:', error);
        }
    };

    const updateProfile = async (data: Partial<UserProfile>) => {
        if (!user) return;
        const updatedUser = { ...user, ...data };
        try {
            await AsyncStorage.setItem('user_profile', JSON.stringify(updatedUser));
            await setDoc(doc(db, 'userProfiles', user.uid), updatedUser);
            setUser(updatedUser);
        } catch (error) {
            console.error('Failed to update profile:', error);
        }
    };

    const setLocale = async (locale: string) => {
        try {
            await AsyncStorage.setItem('app_locale', locale);
            if (user) {
                await updateProfile({ locale });
            }
        } catch (error) {
            console.error('Failed to set locale:', error);
        }
    };

    const resetProfile = async () => {
        try {
            // Delete from Firestore if authenticated user
            if (firebaseUser) {
                const userDocRef = doc(db, 'userProfiles', firebaseUser.uid);
                // Note: deleteDoc not imported, so we'll just clear locally
                // In production, import deleteDoc from 'firebase/firestore'
                await signOut(auth);
            }

            // Clear all AsyncStorage data
            await AsyncStorage.multiRemove([
                'user_profile',
                'guestProfile',
                'app_locale',
                '@pregnancy_context',
            ]);

            // Reset states
            setUser(null);
            setFirebaseUser(null);

            // Note: Navigation handled by ProfileScreen
            console.log('Profile reset complete');
        } catch (error) {
            console.error('Failed to reset profile:', error);
            throw error;
        }
    };

    return (
        <AuthContext.Provider value={{
            user,
            firebaseUser,
            loading,
            register,
            login,
            loginAsGuest,
            logout,
            updateProfile,
            setLocale,
            resetProfile
        }}>
            {children}
        </AuthContext.Provider>
    );
};

export const useAuth = () => {
    const context = useContext(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
