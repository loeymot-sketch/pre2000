// src/context/PregnancyContext.tsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { getDoc, doc, setDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { differenceInDays } from 'date-fns';
import { useAuth } from './AuthContext';

type Profile = {
    firstName: string;
    lastName?: string;
    country: string;
    lmp?: string; // ISO date string
    dpa?: string; // ISO date string
};

type PregnancyInfo = {
    week: number;
    dayInWeek: number;
};

type PregnancyContextType = {
    profile: Profile | null;
    setProfile: (p: Profile) => Promise<void>;
    pregnancyInfo: PregnancyInfo | null;
    loading: boolean;
};

const PregnancyContext = createContext<PregnancyContextType | undefined>(undefined);

export const PregnancyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
    const { user } = useAuth();
    const [profile, setProfileState] = useState<Profile | null>(null);
    const [pregnancyInfo, setPregnancyInfo] = useState<PregnancyInfo | null>(null);
    const [loading, setLoading] = useState(true);

    // Load existing profile on mount or when user changes
    useEffect(() => {
        const load = async () => {
            setLoading(true);
            try {
                if (user && !user.isGuest) {
                    const snap = await getDoc(doc(db, 'userProfiles', user.uid));
                    if (snap.exists()) {
                        const data = snap.data() as Profile;
                        setProfileState(data);
                        computeInfo(data);
                    }
                } else {
                    const stored = await AsyncStorage.getItem('guestProfile');
                    if (stored) {
                        const data = JSON.parse(stored) as Profile;
                        setProfileState(data);
                        computeInfo(data);
                    }
                }
            } catch (e) {
                console.error('Error loading profile', e);
            } finally {
                setLoading(false);
            }
        };
        load();
    }, [user]);

    const computeInfo = (p: Profile) => {
        const startDateStr = p.lmp || p.dpa;
        if (!startDateStr) return;
        const startDate = new Date(startDateStr);
        const today = new Date();
        const diff = differenceInDays(today, startDate);
        const week = Math.min(40, Math.max(1, Math.floor(diff / 7) + 1));
        const dayInWeek = (diff % 7) + 1;
        setPregnancyInfo({ week, dayInWeek });
    };

    const setProfile = async (p: Profile) => {
        setLoading(true);
        try {
            if (user && !user.isGuest) {
                await setDoc(doc(db, 'userProfiles', user.uid), p, { merge: true });
            } else {
                await AsyncStorage.setItem('guestProfile', JSON.stringify(p));
            }
            setProfileState(p);
            computeInfo(p);
        } catch (e) {
            console.error('Error saving profile', e);
        } finally {
            setLoading(false);
        }
    };

    return (
        <PregnancyContext.Provider value={{ profile, setProfile, pregnancyInfo, loading }}>
            {children}
        </PregnancyContext.Provider>
    );
};

export const usePregnancy = () => {
    const ctx = useContext(PregnancyContext);
    if (!ctx) throw new Error('usePregnancy must be used within PregnancyProvider');
    return ctx;
};
