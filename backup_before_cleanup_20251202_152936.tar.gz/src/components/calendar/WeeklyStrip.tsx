import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { theme } from '../../theme';

interface WeeklyStripProps {
    weekStartDate: Date;
    selectedDate: Date;
    onDateSelect: (date: Date) => void;
    eventCounts: Record<string, number>; // date string -> count
}

export const WeeklyStrip: React.FC<WeeklyStripProps> = ({
    weekStartDate,
    selectedDate,
    onDateSelect,
    eventCounts,
}) => {
    const days = ['Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam', 'Dim'];

    const renderDay = (dayIndex: number) => {
        const date = new Date(weekStartDate);
        date.setDate(weekStartDate.getDate() + dayIndex);

        const dateString = date.toISOString().split('T')[0];
        const isSelected = date.toDateString() === selectedDate.toDateString();
        const isToday = new Date().toDateString() === date.toDateString();
        const hasEvents = (eventCounts[dateString] || 0) > 0;

        return (
            <TouchableOpacity
                key={dayIndex}
                style={[
                    styles.dayContainer,
                    isSelected && styles.selectedDayContainer,
                    isToday && !isSelected && styles.todayContainer,
                ]}
                onPress={() => onDateSelect(date)}
            >
                <Text style={[styles.dayName, isSelected && styles.selectedText]}>
                    {days[dayIndex]}
                </Text>
                <Text style={[styles.dayNumber, isSelected && styles.selectedText]}>
                    {date.getDate()}
                </Text>
                {hasEvents && (
                    <View style={[styles.dot, isSelected && styles.selectedDot]} />
                )}
            </TouchableOpacity>
        );
    };

    return (
        <View style={styles.container}>
            {[0, 1, 2, 3, 4, 5, 6].map(renderDay)}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingVertical: theme.spacing.m,
        paddingHorizontal: theme.spacing.s,
        backgroundColor: theme.colors.white,
        borderBottomWidth: 1,
        borderBottomColor: theme.colors.border,
    },
    dayContainer: {
        alignItems: 'center',
        justifyContent: 'center',
        width: 45,
        height: 60,
        borderRadius: 12,
    },
    selectedDayContainer: {
        backgroundColor: theme.colors.primary,
        shadowColor: theme.colors.primary,
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.3,
        shadowRadius: 4,
        elevation: 4,
    },
    todayContainer: {
        backgroundColor: '#F0F9FF', // Light blue for today
        borderWidth: 1,
        borderColor: theme.colors.primary,
    },
    dayName: {
        fontSize: 12,
        color: theme.colors.textLight,
        marginBottom: 4,
    },
    dayNumber: {
        fontSize: 16,
        fontWeight: 'bold',
        color: theme.colors.text,
    },
    selectedText: {
        color: theme.colors.white,
    },
    dot: {
        width: 4,
        height: 4,
        borderRadius: 2,
        backgroundColor: theme.colors.primary,
        marginTop: 4,
    },
    selectedDot: {
        backgroundColor: theme.colors.white,
    },
});
