import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { format } from 'date-fns';
import { fr } from 'date-fns/locale';
import { CombinedEvent } from '../../types';
import { theme } from '../../theme';

interface EventCardProps {
    event: CombinedEvent;
    onPress?: () => void;
    onDelete?: () => void;
}

export const EventCard: React.FC<EventCardProps> = ({ event, onPress, onDelete }) => {
    const isUserEvent = event.source === 'user';

    return (
        <TouchableOpacity
            style={styles.card}
            onPress={onPress}
            activeOpacity={0.7}
            disabled={!onPress}
        >
            <View style={[styles.priorityIndicator, { backgroundColor: event.priorityColor }]} />

            <View style={styles.content}>
                <View style={styles.header}>
                    <View style={styles.iconBadge}>
                        <Text style={styles.iconText}>{isUserEvent ? '📝' : '📅'}</Text>
                    </View>
                    <Text style={styles.title}>{event.title}</Text>
                </View>

                <Text style={styles.date}>
                    {format(event.date, 'EEEE dd MMMM yyyy', { locale: fr })}
                </Text>

                <View style={styles.tagsContainer}>
                    <View style={[styles.tag, isUserEvent && styles.userTag]}>
                        <Text style={[styles.tagText, isUserEvent && styles.userTagText]}>
                            {isUserEvent ? 'Mon RDV' : event.type}
                        </Text>
                    </View>
                    {event.importance && !isUserEvent && (
                        <View style={[styles.tag, { backgroundColor: event.priorityColor + '20' }]}>
                            <Text style={[styles.tagText, { color: event.priorityColor }]}>
                                {event.importance}
                            </Text>
                        </View>
                    )}
                </View>

                {event.description && !isUserEvent && (
                    <Text style={styles.description} numberOfLines={2}>
                        {event.description}
                    </Text>
                )}

                {event.notes && isUserEvent && (
                    <Text style={styles.notes} numberOfLines={2}>
                        {event.notes}
                    </Text>
                )}
            </View>

            {onDelete && isUserEvent && (
                <TouchableOpacity style={styles.deleteButton} onPress={onDelete}>
                    <Text style={styles.deleteIcon}>🗑️</Text>
                </TouchableOpacity>
            )}
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    card: {
        flexDirection: 'row',
        backgroundColor: theme.colors.white,
        borderRadius: theme.borderRadius.m,
        marginBottom: theme.spacing.m,
        overflow: 'hidden',
        elevation: 2,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.1,
        shadowRadius: 2,
    },
    priorityIndicator: {
        width: 4,
    },
    content: {
        flex: 1,
        padding: theme.spacing.m,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: theme.spacing.xs,
    },
    iconBadge: {
        marginRight: theme.spacing.xs,
    },
    iconText: {
        fontSize: 18,
    },
    title: {
        flex: 1,
        fontSize: 16,
        fontWeight: '600' as const,
        color: theme.colors.text,
    },
    date: {
        fontSize: 14,
        color: theme.colors.textLight,
        marginBottom: theme.spacing.s,
    },
    tagsContainer: {
        flexDirection: 'row',
        gap: theme.spacing.xs,
        marginBottom: theme.spacing.s,
    },
    tag: {
        paddingHorizontal: theme.spacing.s,
        paddingVertical: 4,
        borderRadius: theme.borderRadius.s,
        backgroundColor: theme.colors.secondary,
    },
    userTag: {
        backgroundColor: '#6B46C1' + '20',
    },
    tagText: {
        fontSize: 12,
        color: theme.colors.primary,
        fontWeight: '500' as const,
    },
    userTagText: {
        color: '#6B46C1',
    },
    description: {
        fontSize: 14,
        color: theme.colors.text,
        lineHeight: 20,
    },
    notes: {
        fontSize: 14,
        color: theme.colors.textLight,
        lineHeight: 20,
        fontStyle: 'italic',
    },
    deleteButton: {
        padding: theme.spacing.m,
        justifyContent: 'center',
        alignItems: 'center',
    },
    deleteIcon: {
        fontSize: 20,
    },
});
