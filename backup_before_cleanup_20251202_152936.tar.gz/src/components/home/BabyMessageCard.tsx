import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

interface BabyMessageCardProps {
    message: string;
    week: number;
    day: number;
}

/**
 * BabyMessageCard - Displays daily message from baby to mom
 * Feature: Quick Win #1 - High emotional impact
 */
export const BabyMessageCard: React.FC<BabyMessageCardProps> = ({
    message,
    week,
    day
}) => {
    console.log('[BabyMessageCard] Rendering for week', week, 'day', day);

    return (
        <View style={styles.container}>
            <LinearGradient
                colors={['#FFE5F1', '#FFF0F5']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.gradient}
            >
                <View style={styles.header}>
                    <Text style={styles.emoji}>👶</Text>
                    <Text style={styles.title}>Message de Bébé</Text>
                </View>

                <Text style={styles.message}>{message}</Text>

                <Text style={styles.footer}>
                    Semaine {week}, Jour {day}
                </Text>
            </LinearGradient>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginHorizontal: 16,
        marginVertical: 12,
    },
    gradient: {
        borderRadius: 16,
        padding: 20,
        borderWidth: 1,
        borderColor: '#FFD6E8',
        shadowColor: '#C2185B',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    emoji: {
        fontSize: 24,
        marginRight: 8,
    },
    title: {
        fontSize: 18,
        fontWeight: 'bold',
        color: '#C2185B',
    },
    message: {
        fontSize: 16,
        lineHeight: 24,
        color: '#424242',
        marginBottom: 12,
        fontStyle: 'italic',
    },
    footer: {
        fontSize: 12,
        fontStyle: 'italic',
        color: '#757575',
        textAlign: 'right',
    },
});
