import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { fetchWeekRemindersAndTasks } from '../../services/reminderService';
import { ReminderTemplate, WeeklyTask } from '../../types';

interface WeekRemindersCardProps {
    weekNumber: number;
    onViewAll?: () => void;
}

/**
 * WeekRemindersCard - Displays top reminders and tasks for the current week
 * Shows 2-3 items max with "Voir tout" button to navigate to full RemindersScreen
 */
export const WeekRemindersCard: React.FC<WeekRemindersCardProps> = ({
    weekNumber,
    onViewAll
}) => {
    const [reminders, setReminders] = useState<ReminderTemplate[]>([]);
    const [tasks, setTasks] = useState<WeeklyTask[]>([]);
    const [loading, setLoading] = useState(true);

    console.log('[WeekRemindersCard] Rendering for week:', weekNumber);

    useEffect(() => {
        const loadData = async () => {
            console.log('[WeekRemindersCard] Loading data for week:', weekNumber);
            setLoading(true);

            try {
                const data = await fetchWeekRemindersAndTasks(weekNumber);

                // Take top 2 reminders and top 2 tasks (prioritized)
                setReminders(data.reminders.slice(0, 2));
                setTasks(data.tasks.slice(0, 2));

                console.log('[WeekRemindersCard] Loaded:', {
                    reminders: data.reminders.length,
                    tasks: data.tasks.length,
                    showing_reminders: Math.min(2, data.reminders.length),
                    showing_tasks: Math.min(2, data.tasks.length),
                });
            } catch (error) {
                console.error('[WeekRemindersCard] Error loading data:', error);
            } finally {
                setLoading(false);
            }
        };

        loadData();
    }, [weekNumber]);

    // Don't render if no data
    if (!loading && reminders.length === 0 && tasks.length === 0) {
        console.log('[WeekRemindersCard] No data, skipping render');
        return null;
    }

    if (loading) {
        return (
            <View style={styles.container}>
                <LinearGradient
                    colors={['#FFF3E0', '#FFF9F5', '#FFFFFF']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={styles.gradient}
                >
                    <ActivityIndicator size="small" color="#FF6F00" />
                </LinearGradient>
            </View>
        );
    }

    return (
        <View style={styles.container}>
            <LinearGradient
                colors={['#FFF3E0', '#FFF9F5', '#FFFFFF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.gradient}
            >
                {/* Header with View All button */}
                <View style={styles.header}>
                    <View style={styles.titleRow}>
                        <Text style={styles.emoji}>⏰</Text>
                        <Text style={styles.title}>Rappels de la semaine</Text>
                    </View>
                    {onViewAll && (
                        <TouchableOpacity onPress={onViewAll} style={styles.viewAllButton}>
                            <Text style={styles.viewAllText}>Voir tout →</Text>
                        </TouchableOpacity>
                    )}
                </View>

                {/* Reminders */}
                {reminders.length > 0 && (
                    <View style={styles.section}>
                        {reminders.map((reminder, index) => (
                            <View key={reminder.reminder_id} style={styles.item}>
                                <View style={styles.iconContainer}>
                                    <Text style={styles.itemIcon}>🔔</Text>
                                </View>
                                <View style={styles.itemContent}>
                                    <Text style={styles.itemTitle}>{reminder.title_fr}</Text>
                                    <Text style={styles.itemDesc} numberOfLines={2}>
                                        {reminder.description_fr}
                                    </Text>
                                    <Text style={styles.itemMeta}>
                                        {reminder.default_times_per_day}× par jour
                                    </Text>
                                </View>
                            </View>
                        ))}
                    </View>
                )}

                {/* Tasks */}
                {tasks.length > 0 && (
                    <View style={[styles.section, reminders.length > 0 && { marginTop: 12 }]}>
                        {tasks.map((task, index) => (
                            <View key={task.task_id} style={styles.item}>
                                <View style={styles.iconContainer}>
                                    <Text style={styles.itemIcon}>
                                        {task.priority === 'high' ? '🔴' : task.priority === 'medium' ? '🟡' : '🟢'}
                                    </Text>
                                </View>
                                <View style={styles.itemContent}>
                                    <Text style={styles.itemTitle}>{task.label_fr}</Text>
                                    <Text style={styles.itemMeta}>
                                        Priorité: {task.priority === 'high' ? 'Haute' : task.priority === 'medium' ? 'Moyenne' : 'Basse'}
                                    </Text>
                                </View>
                            </View>
                        ))}
                    </View>
                )}
            </LinearGradient>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginVertical: 12,
        marginHorizontal: 16,
        borderRadius: 16,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    gradient: {
        padding: 20,
    },
    header: {
        marginBottom: 16,
    },
    titleRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 8,
    },
    emoji: {
        fontSize: 28,
        marginRight: 10,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#E65100',
        flex: 1,
    },
    viewAllButton: {
        alignSelf: 'flex-start',
        paddingVertical: 6,
        paddingHorizontal: 12,
        backgroundColor: 'rgba(255, 111, 0, 0.1)',
        borderRadius: 12,
    },
    viewAllText: {
        fontSize: 14,
        color: '#FF6F00',
        fontWeight: '600',
    },
    section: {
        gap: 12,
    },
    item: {
        flexDirection: 'row',
        alignItems: 'flex-start',
        backgroundColor: 'rgba(255, 255, 255, 0.5)',
        borderRadius: 12,
        padding: 12,
        borderLeftWidth: 3,
        borderLeftColor: '#FF9800',
    },
    iconContainer: {
        marginRight: 12,
        marginTop: 2,
    },
    itemIcon: {
        fontSize: 20,
    },
    itemContent: {
        flex: 1,
    },
    itemTitle: {
        fontSize: 15,
        fontWeight: '600',
        color: '#BF360C',
        marginBottom: 4,
    },
    itemDesc: {
        fontSize: 13,
        color: '#5D4037',
        lineHeight: 18,
        marginBottom: 4,
    },
    itemMeta: {
        fontSize: 12,
        color: '#8D6E63',
        fontStyle: 'italic',
    },
});
