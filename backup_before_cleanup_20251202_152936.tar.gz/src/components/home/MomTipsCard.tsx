import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { parseBullets } from '../../utils/textParsers';

interface MomTipsCardProps {
    tips_short?: string;
    tips_bullets?: string;
}

/**
 * MomTipsCard - Displays practical tips for mom for the current week
 * Uses V3 data: mom_tips_short_fr and mom_tips_bullets_fr
 */
export const MomTipsCard: React.FC<MomTipsCardProps> = ({
    tips_short,
    tips_bullets
}) => {
    console.log('[MomTipsCard] Rendering with:', {
        has_short: !!tips_short,
        has_bullets: !!tips_bullets,
        bullets_length: tips_bullets?.length || 0,
    });

    // Parse bullet points
    const bulletPoints = parseBullets(tips_bullets);
    console.log('[MomTipsCard] Parsed bullets:', bulletPoints.length);

    // Don't render if no data
    if (!tips_short && bulletPoints.length === 0) {
        console.log('[MomTipsCard] No data, skipping render');
        return null;
    }

    return (
        <View style={styles.container}>
            <LinearGradient
                colors={['#E1F5FE', '#F0F9FF', '#FFFFFF']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.gradient}
            >
                {/* Header */}
                <View style={styles.header}>
                    <Text style={styles.emoji}>💖</Text>
                    <Text style={styles.title}>Conseils pour toi</Text>
                </View>

                {/* Short summary */}
                {tips_short && (
                    <Text style={styles.shortText}>{tips_short}</Text>
                )}

                {/* Bullet points */}
                {bulletPoints.length > 0 && (
                    <View style={styles.bulletsContainer}>
                        {bulletPoints.map((tip, index) => (
                            <View key={index} style={styles.bulletRow}>
                                <Text style={styles.bulletDot}>•</Text>
                                <Text style={styles.bulletText}>{tip}</Text>
                            </View>
                        ))}
                    </View>
                )}
            </LinearGradient>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        marginVertical: 12,
        marginHorizontal: 16,
        borderRadius: 16,
        overflow: 'hidden',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 4,
        elevation: 3,
    },
    gradient: {
        padding: 20,
    },
    header: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 12,
    },
    emoji: {
        fontSize: 28,
        marginRight: 10,
    },
    title: {
        fontSize: 20,
        fontWeight: 'bold',
        color: '#0277BD',
        flex: 1,
    },
    shortText: {
        fontSize: 15,
        color: '#263238',
        lineHeight: 22,
        marginBottom: 12,
    },
    bulletsContainer: {
        marginTop: 8,
    },
    bulletRow: {
        flexDirection: 'row',
        marginBottom: 8,
        alignItems: 'flex-start',
    },
    bulletDot: {
        fontSize: 16,
        color: '#4FC3F7',
        marginRight: 8,
        marginTop: 2,
    },
    bulletText: {
        fontSize: 14,
        color: '#37474F',
        lineHeight: 20,
        flex: 1,
    },
});
