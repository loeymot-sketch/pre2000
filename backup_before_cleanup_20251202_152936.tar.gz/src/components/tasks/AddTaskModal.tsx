import React, { useState } from 'react';
import {
    Modal,
    View,
    Text,
    TextInput,
    TouchableOpacity,
    StyleSheet,
    KeyboardAvoidingView,
    Platform,
    ActivityIndicator,
} from 'react-native';

interface AddTaskModalProps {
    visible: boolean;
    onClose: () => void;
    onCreate: (title: string, priority: 'high' | 'medium' | 'low') => Promise<void>;
}

export const AddTaskModal: React.FC<AddTaskModalProps> = ({
    visible,
    onClose,
    onCreate,
}) => {
    const [title, setTitle] = useState('');
    const [priority, setPriority] = useState<'high' | 'medium' | 'low'>('medium');
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');

    const handleCreate = async () => {
        // Validation
        if (title.trim().length < 3) {
            setError('Le titre doit contenir au moins 3 caractères');
            return;
        }

        setError('');
        setLoading(true);

        try {
            await onCreate(title.trim(), priority);

            // Reset form
            setTitle('');
            setPriority('medium');
            onClose();
        } catch (err) {
            setError('Erreur lors de la création de la tâche');
            console.error('[AddTaskModal] Error:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleClose = () => {
        setTitle('');
        setPriority('medium');
        setError('');
        onClose();
    };

    return (
        <Modal
            visible={visible}
            transparent
            animationType="fade"
            onRequestClose={handleClose}
        >
            <KeyboardAvoidingView
                behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
                style={styles.overlay}
            >
                <View style={styles.modalContent}>
                    {/* Header */}
                    <View style={styles.header}>
                        <Text style={styles.title}>➕ Nouvelle Tâche</Text>
                        <TouchableOpacity onPress={handleClose} style={styles.closeButton}>
                            <Text style={styles.closeText}>✕</Text>
                        </TouchableOpacity>
                    </View>

                    {/* Title Input */}
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Titre de la tâche</Text>
                        <TextInput
                            style={styles.input}
                            placeholder="Ex: Acheter des vitamines"
                            value={title}
                            onChangeText={setTitle}
                            maxLength={100}
                            autoFocus
                        />
                    </View>

                    {/* Priority Selection */}
                    <View style={styles.inputGroup}>
                        <Text style={styles.label}>Priorité</Text>
                        <View style={styles.priorityButtons}>
                            <TouchableOpacity
                                style={[
                                    styles.priorityButton,
                                    priority === 'high' && styles.priorityButtonActiveHigh,
                                ]}
                                onPress={() => setPriority('high')}
                            >
                                <Text
                                    style={[
                                        styles.priorityButtonText,
                                        priority === 'high' && styles.priorityButtonTextActive,
                                    ]}
                                >
                                    🔴 Haute
                                </Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={[
                                    styles.priorityButton,
                                    priority === 'medium' && styles.priorityButtonActiveMedium,
                                ]}
                                onPress={() => setPriority('medium')}
                            >
                                <Text
                                    style={[
                                        styles.priorityButtonText,
                                        priority === 'medium' && styles.priorityButtonTextActive,
                                    ]}
                                >
                                    🟡 Moyenne
                                </Text>
                            </TouchableOpacity>

                            <TouchableOpacity
                                style={[
                                    styles.priorityButton,
                                    priority === 'low' && styles.priorityButtonActiveLow,
                                ]}
                                onPress={() => setPriority('low')}
                            >
                                <Text
                                    style={[
                                        styles.priorityButtonText,
                                        priority === 'low' && styles.priorityButtonTextActive,
                                    ]}
                                >
                                    🟢 Basse
                                </Text>
                            </TouchableOpacity>
                        </View>
                    </View>

                    {/* Error Message */}
                    {error ? <Text style={styles.error}>{error}</Text> : null}

                    {/* Action Buttons */}
                    <View style={styles.actions}>
                        <TouchableOpacity
                            style={styles.cancelButton}
                            onPress={handleClose}
                            disabled={loading}
                        >
                            <Text style={styles.cancelButtonText}>Annuler</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                            style={[
                                styles.createButton,
                                (loading || title.trim().length < 3) && styles.createButtonDisabled,
                            ]}
                            onPress={handleCreate}
                            disabled={loading || title.trim().length < 3}
                        >
                            {loading ? (
                                <ActivityIndicator color="#FFF" size="small" />
                            ) : (
                                <Text style={styles.createButtonText}>Créer ✓</Text>
                            )}
                        </TouchableOpacity>
                    </View>
                </View>
            </KeyboardAvoidingView>
        </Modal>
    );
};

const styles = StyleSheet.create({
    overlay: {
        flex: 1,
        backgroundColor: 'rgba(0, 0, 0, 0.5)',
        justifyContent: 'center',
        alignItems: 'center',
    },
    modalContent: {
        width: '90%',
        maxWidth: 400,
        backgroundColor: '#FFF',
        borderRadius: 20,
        padding: 24,
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 4 },
        shadowOpacity: 0.3,
        shadowRadius: 8,
        elevation: 8,
    },
    header: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 24,
    },
    title: {
        fontSize: 22,
        fontWeight: 'bold',
        color: '#333',
    },
    closeButton: {
        padding: 4,
    },
    closeText: {
        fontSize: 24,
        color: '#999',
    },
    inputGroup: {
        marginBottom: 20,
    },
    label: {
        fontSize: 15,
        fontWeight: '600',
        color: '#555',
        marginBottom: 8,
    },
    input: {
        borderWidth: 1,
        borderColor: '#DDD',
        borderRadius: 12,
        padding: 12,
        fontSize: 16,
        backgroundColor: '#F9F9F9',
    },
    priorityButtons: {
        flexDirection: 'row',
        gap: 8,
    },
    priorityButton: {
        flex: 1,
        paddingVertical: 10,
        paddingHorizontal: 12,
        borderRadius: 10,
        borderWidth: 2,
        borderColor: '#DDD',
        backgroundColor: '#F9F9F9',
        alignItems: 'center',
    },
    priorityButtonActiveHigh: {
        borderColor: '#E53935',
        backgroundColor: '#E53935',
    },
    priorityButtonActiveMedium: {
        borderColor: '#FFA726',
        backgroundColor: '#FFA726',
    },
    priorityButtonActiveLow: {
        borderColor: '#66BB6A',
        backgroundColor: '#66BB6A',
    },
    priorityButtonText: {
        fontSize: 14,
        fontWeight: '600',
        color: '#666',
    },
    priorityButtonTextActive: {
        color: '#FFF',
    },
    error: {
        color: '#E53935',
        fontSize: 14,
        marginBottom: 12,
        textAlign: 'center',
    },
    actions: {
        flexDirection: 'row',
        gap: 12,
        marginTop: 8,
    },
    cancelButton: {
        flex: 1,
        paddingVertical: 14,
        borderRadius: 12,
        borderWidth: 1,
        borderColor: '#C2185B',
        alignItems: 'center',
    },
    cancelButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#C2185B',
    },
    createButton: {
        flex: 1,
        paddingVertical: 14,
        borderRadius: 12,
        backgroundColor: '#C2185B',
        alignItems: 'center',
    },
    createButtonDisabled: {
        opacity: 0.5,
    },
    createButtonText: {
        fontSize: 16,
        fontWeight: '600',
        color: '#FFF',
    },
});
