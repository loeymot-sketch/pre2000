import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useAuth } from '../../context/AuthContext';
import { usePregnancy } from '../../context/PregnancyContext';
import { WeeklyTask } from '../../types';
import {
    loadTaskStatusesGuest,
    loadTaskStatusesAuth,
    saveTaskStatusGuest,
    saveTaskStatusAuth,
} from '../../services/reminderPersistence';

interface TaskCardProps {
    task: WeeklyTask;
}

export const TaskCard: React.FC<TaskCardProps> = ({ task }) => {
    const { user } = useAuth();
    const { pregnancyInfo } = usePregnancy();
    const [completed, setCompleted] = useState(false);
    const [loading, setLoading] = useState(false);

    // Load saved status on mount
    useEffect(() => {
        loadStatus();
    }, [task.task_id, user]);

    const loadStatus = async () => {
        if (!pregnancyInfo) return;

        try {
            const statuses = user
                ? await loadTaskStatusesAuth(user.uid, pregnancyInfo.week)
                : await loadTaskStatusesGuest();

            const key = `${task.task_id}_w${pregnancyInfo.week}`;
            const saved = statuses[key];

            if (saved) {
                setCompleted(saved.completed);
            }
        } catch (error) {
            console.error('[TaskCard] Error loading status:', error);
        }
    };

    const handleToggle = async () => {
        if (!pregnancyInfo) return;

        const newStatus = !completed;
        setCompleted(newStatus); // Optimistic update
        setLoading(true);

        try {
            // Save to persistence
            if (user) {
                await saveTaskStatusAuth(user.uid, task.task_id, pregnancyInfo.week, newStatus);
            } else {
                await saveTaskStatusGuest(task.task_id, pregnancyInfo.week, newStatus);
            }
        } catch (error) {
            setCompleted(!newStatus); // Revert on error
            console.error('[TaskCard] Error toggling:', error);
        } finally {
            setLoading(false);
        }
    };

    return (
        <TouchableOpacity
            style={[styles.taskCard, completed && styles.taskCardCompleted]}
            onPress={handleToggle}
        >
            <View style={styles.taskCheckbox}>
                {completed ? (
                    <Text style={styles.taskCheckboxChecked}>✓</Text>
                ) : (
                    <View style={styles.taskCheckboxEmpty} />
                )}
            </View>
            <View style={styles.taskContent}>
                <Text style={[styles.taskTitle, completed && styles.taskTitleCompleted]}>
                    {task.label_fr}
                </Text>
            </View>
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    taskCard: {
        flexDirection: 'row',
        alignItems: 'center',
        padding: 12,
        backgroundColor: '#F9F9F9',
        borderRadius: 8,
        marginBottom: 8,
    },
    taskCardCompleted: {
        opacity: 0.6,
    },
    taskCheckbox: {
        width: 24,
        height: 24,
        marginRight: 12,
        borderRadius: 4,
        justifyContent: 'center',
        alignItems: 'center',
    },
    taskCheckboxEmpty: {
        width: 24,
        height: 24,
        borderWidth: 2,
        borderColor: '#C2185B',
        borderRadius: 4,
    },
    taskCheckboxChecked: {
        fontSize: 18,
        color: '#C2185B',
    },
    taskContent: {
        flex: 1,
    },
    taskTitle: {
        fontSize: 15,
        color: '#333',
        fontWeight: '500',
    },
    taskTitleCompleted: {
        textDecorationLine: 'line-through',
        color: '#999',
    },
});
