export const calculatePregnancyWeek = (startDate: Date): { week: number; day: number } => {
    const now = new Date();
    const start = new Date(startDate);

    // Reset hours to avoid timezone issues affecting day calculation
    now.setHours(0, 0, 0, 0);
    start.setHours(0, 0, 0, 0);

    const diffTime = now.getTime() - start.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) {
        // Future date
        return { week: 1, day: 1 };
    }

    const week = Math.floor(diffDays / 7) + 1;
    const day = (diffDays % 7) + 1;

    if (week > 40) {
        return { week: 40, day: 7 };
    }

    return { week, day };
};
