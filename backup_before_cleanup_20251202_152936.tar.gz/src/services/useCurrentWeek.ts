import { useState, useEffect } from 'react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { usePregnancy } from '../context/PregnancyContext';
import { Week } from '../types';

export const useCurrentWeek = (weekNumber?: number) => {
    const { pregnancyInfo, loading: contextLoading } = usePregnancy();
    const [weekData, setWeekData] = useState<Week | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const targetWeek = weekNumber || pregnancyInfo?.week || 1;
    const currentDay = pregnancyInfo?.dayInWeek || 1;

    useEffect(() => {
        const fetchWeekData = async () => {
            if (contextLoading && !weekNumber) return;

            // If fetching specific week, we don't need to wait for pregnancyInfo unless we need it for default
            if (!weekNumber && !pregnancyInfo) {
                setLoading(false);
                return;
            }

            setLoading(true);
            try {
                const weekDocRef = doc(db, 'weeks', String(targetWeek));
                const weekDoc = await getDoc(weekDocRef);

                if (weekDoc.exists()) {
                    setWeekData(weekDoc.data() as Week);
                } else {
                    setError('Données de la semaine introuvables');
                }
            } catch (err) {
                console.error('Error fetching week data:', err);
                setError('Erreur lors du chargement des données');
            } finally {
                setLoading(false);
            }
        };

        fetchWeekData();
    }, [pregnancyInfo, contextLoading, targetWeek]);

    return { weekData, loading: loading || (contextLoading && !weekNumber), error, currentWeekNumber: targetWeek, currentDay };
};
