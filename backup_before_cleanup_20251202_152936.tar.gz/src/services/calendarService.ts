import { collection, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';
import { CalendarTemplate } from '../types';

export interface GeneratedEvent {
    id: string;
    templateId: string;
    title: string;
    date: Date;
    week: number;
    type: string;
    importance: string;
    description: string;
    source?: string;
    priorityColor: string;
}

// Priority color mapping
const PRIORITY_COLORS: Record<string, string> = {
    'critique': '#EF4444',
    'élevé': '#F59E0B',
    'modéré': '#3B82F6',
    'faible': '#10B981',
    'information': '#6B7280',
};

const getPriorityColor = (importance: string): string => {
    return PRIORITY_COLORS[importance.toLowerCase()] || PRIORITY_COLORS['information'];
};

const calculateEventDate = (
    lmpDate: Date,
    targetWeek: number,
    recommendedDay: number
): Date => {
    const weeksOffset = (targetWeek - 1) * 7;
    const dayOffset = recommendedDay - 1;
    const totalDays = weeksOffset + dayOffset;

    const eventDate = new Date(lmpDate);
    eventDate.setDate(lmpDate.getDate() + totalDays);

    return eventDate;
};

export const generateEventsForWeek = (
    templates: CalendarTemplate[],
    lmpDate: Date,
    targetWeek: number
): GeneratedEvent[] => {
    const events: GeneratedEvent[] = [];

    const applicableTemplates = templates.filter(
        (template) =>
            template.week_min <= targetWeek &&
            template.week_max >= targetWeek
    );

    applicableTemplates.forEach((template) => {
        const eventDate = calculateEventDate(
            lmpDate,
            targetWeek,
            template.recommended_day || 4 // Default to middle of week (day 4) if not specified
        );

        events.push({
            id: `${template.template_id}_w${targetWeek}`,
            templateId: template.template_id,
            title: template.title_fr,
            date: eventDate,
            week: targetWeek,
            type: template.type,
            importance: String(template.importance),
            description: template.description_fr || '',
            source: template.sources,
            priorityColor: getPriorityColor(String(template.importance)),
        });
    });

    return events.sort((a, b) => a.date.getTime() - b.date.getTime());
};

export const generateAllEvents = (
    templates: CalendarTemplate[],
    lmpDate: Date
): GeneratedEvent[] => {
    const allEvents: GeneratedEvent[] = [];

    for (let week = 1; week <= 40; week++) {
        const weekEvents = generateEventsForWeek(templates, lmpDate, week);
        allEvents.push(...weekEvents);
    }

    return allEvents;
};

export const getEventsForWeek = (
    allEvents: GeneratedEvent[],
    weekNumber: number
): GeneratedEvent[] => {
    return allEvents.filter((event) => event.week === weekNumber);
};

export const loadCalendarTemplates = async (): Promise<CalendarTemplate[]> => {
    console.log('[CalendarService] 📥 Loading calendar templates from Firestore...');
    try {
        const snapshot = await getDocs(collection(db, 'calendarTemplates'));
        const templates = snapshot.docs.map((doc) => doc.data() as CalendarTemplate);
        console.log(`[CalendarService] ✅ Loaded ${templates.length} calendar templates`);
        if (templates.length === 0) {
            console.warn('[CalendarService] ⚠️ No calendar templates found! Check Firestore data import.');
        }
        return templates;
    } catch (error) {
        console.error('[CalendarService] ❌ Error loading calendar templates:', error);
        return [];
    }
};

export const getWeekDates = (lmpDate: Date, weekNumber: number): { start: Date; end: Date } => {
    const weekStart = new Date(lmpDate);
    weekStart.setDate(lmpDate.getDate() + (weekNumber - 1) * 7);

    const weekEnd = new Date(weekStart);
    weekEnd.setDate(weekStart.getDate() + 6);

    return { start: weekStart, end: weekEnd };
};

// ============ USER EVENTS SECTION ============

import { doc, setDoc, deleteDoc, query, where, orderBy, limit } from 'firebase/firestore';
import { UserEvent, CombinedEvent } from '../types';

/**
 * Get upcoming appointments for a user
 */
export const getUpcomingAppointments = async (userId: string, limitCount: number = 3): Promise<UserEvent[]> => {
    try {
        const now = new Date();
        const eventsRef = collection(db, 'userEvents');
        const q = query(
            eventsRef,
            where('user_id', '==', userId)
        );
        const snapshot = await getDocs(q);
        const allEvents = snapshot.docs.map(doc => doc.data() as UserEvent);

        // Filter and sort in memory to avoid index requirement
        return allEvents
            .filter(event => new Date(event.date) >= now)
            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
            .slice(0, limitCount);
    } catch (error) {
        console.error('[CalendarService] ❌ Error loading upcoming appointments:', error);
        return [];
    }
};

/**
 * Calculate which week a given date falls into based on LMP
 */
export const calculateWeekFromDate = (lmpDate: Date, eventDate: Date): number => {
    const diffMs = eventDate.getTime() - lmpDate.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const weeks = Math.floor(diffDays / 7) + 1;
    return Math.max(1, Math.min(40, weeks));
};

/**
 * Load all user events for a specific user
 */
export const loadUserEvents = async (userId: string): Promise<UserEvent[]> => {
    console.log(`[CalendarService] 📥 Loading user events for user: ${userId}`);
    try {
        const eventsRef = collection(db, 'userEvents');
        const q = query(eventsRef, where('user_id', '==', userId));
        const snapshot = await getDocs(q);
        const events = snapshot.docs.map(doc => doc.data() as UserEvent);
        console.log(`[CalendarService] ✅ Loaded ${events.length} user events`);
        return events;
    } catch (error) {
        console.error('[CalendarService] ❌ Error loading user events:', error);
        return [];
    }
};

/**
 * Save a new user event to Firestore
 */
export const saveUserEvent = async (
    event: Omit<UserEvent, 'event_id' | 'created_at'>
): Promise<UserEvent> => {
    console.log('[CalendarService] 💾 Saving new user event:', event.title);
    const eventId = `user_event_${Date.now()}`;
    const newEvent: UserEvent = {
        ...event,
        event_id: eventId,
        created_at: new Date().toISOString(),
    };

    try {
        await setDoc(doc(db, 'userEvents', eventId), newEvent);
        console.log(`[CalendarService] ✅ User event saved: ${eventId}`);
        return newEvent;
    } catch (error) {
        console.error('[CalendarService] ❌ Error saving user event:', error);
        throw error;
    }
};

/**
 * Delete a user event from Firestore
 */
export const deleteUserEvent = async (eventId: string): Promise<void> => {
    console.log(`[CalendarService] 🗑️ Deleting user event: ${eventId}`);
    try {
        await deleteDoc(doc(db, 'userEvents', eventId));
        console.log(`[CalendarService] ✅ User event deleted: ${eventId}`);
    } catch (error) {
        console.error('[CalendarService] ❌ Error deleting user event:', error);
        throw error;
    }
};

/**
 * Combine template events and user events for a specific week
 */
export const getCombinedEventsForWeek = (
    templateEvents: GeneratedEvent[],
    userEvents: UserEvent[],
    weekNumber: number
): CombinedEvent[] => {
    const combined: CombinedEvent[] = [];

    // Add template events
    templateEvents.forEach(te => {
        combined.push({
            id: te.id,
            title: te.title,
            date: te.date,
            week: te.week,
            type: te.type,
            importance: te.importance,
            description: te.description,
            source: 'template',
            priorityColor: te.priorityColor,
        });
    });

    // Add user events for this week
    userEvents
        .filter(ue => ue.week === weekNumber)
        .forEach(ue => {
            combined.push({
                id: ue.event_id,
                title: ue.title,
                date: new Date(ue.date),
                week: ue.week,
                type: ue.type,
                source: 'user',
                notes: ue.notes,
                priorityColor: '#6B46C1', // Purple for user events
            });
        });

    // Sort by date
    return combined.sort((a, b) => a.date.getTime() - b.date.getTime());
};

/**
 * Group events by date string (YYYY-MM-DD)
 */
export const groupEventsByDate = (events: CombinedEvent[]): Record<string, CombinedEvent[]> => {
    const grouped: Record<string, CombinedEvent[]> = {};
    events.forEach(event => {
        const dateKey = event.date.toISOString().split('T')[0];
        if (!grouped[dateKey]) {
            grouped[dateKey] = [];
        }
        grouped[dateKey].push(event);
    });
    return grouped;
};
