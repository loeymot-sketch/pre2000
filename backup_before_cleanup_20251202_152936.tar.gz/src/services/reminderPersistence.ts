import AsyncStorage from '@react-native-async-storage/async-storage';
import { collection, doc, setDoc, getDocs, query, where, deleteDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { UserReminderSettings, UserTaskStatus } from '../types';

/**
 * Persistence Layer for V1.2 Reminders & Tasks
 * Handles both Guest (AsyncStorage) and Auth (Firestore) users
 */

// AsyncStorage keys
const STORAGE_KEYS = {
    REMINDER_SETTINGS: '@reminder_settings_v1',
    TASK_STATUSES: '@task_statuses_v1',
    BABY_MESSAGE_ENABLED: '@baby_message_enabled_v1',
    BABY_MESSAGE_HOUR: '@baby_message_hour_v1',
};

// ============================================================================
// REMINDER SETTINGS
// ============================================================================

/**
 * Reminder settings structure (Guest)
 */
export interface ReminderSettingsData {
    [reminderId: string]: {
        enabled: boolean;
        timesPerDay: number;
        customHours?: string[];
        lastModified: string; // ISO date
    };
}

/**
 * Save reminder setting (Guest - AsyncStorage)
 */
export const saveReminderSettingGuest = async (
    reminderId: string,
    enabled: boolean,
    timesPerDay: number,
    customHours?: string[]
): Promise<void> => {
    console.log('[reminderPersistence] Saving reminder (Guest):', {
        reminderId,
        enabled,
        timesPerDay,
    });

    try {
        // Load existing settings
        const existing = await loadReminderSettingsGuest();

        // Update
        existing[reminderId] = {
            enabled,
            timesPerDay,
            customHours,
            lastModified: new Date().toISOString(),
        };

        // Save
        await AsyncStorage.setItem(
            STORAGE_KEYS.REMINDER_SETTINGS,
            JSON.stringify(existing)
        );

        console.log('[reminderPersistence] ✅ Saved reminder (Guest)');
    } catch (error) {
        console.error('[reminderPersistence] Error saving reminder (Guest):', error);
        throw error;
    }
};

/**
 * Load all reminder settings (Guest - AsyncStorage)
 */
export const loadReminderSettingsGuest = async (): Promise<ReminderSettingsData> => {
    console.log('[reminderPersistence] Loading reminders (Guest)...');

    try {
        const data = await AsyncStorage.getItem(STORAGE_KEYS.REMINDER_SETTINGS);

        if (!data) {
            console.log('[reminderPersistence] No Guest settings found');
            return {};
        }

        const parsed = JSON.parse(data);
        console.log('[reminderPersistence] Loaded', Object.keys(parsed).length, 'reminders (Guest)');

        return parsed;
    } catch (error) {
        console.error('[reminderPersistence] Error loading reminders (Guest):', error);
        return {};
    }
};

/**
 * Save reminder setting (Auth - Firestore)
 */
export const saveReminderSettingAuth = async (
    userId: string,
    reminderId: string,
    enabled: boolean,
    timesPerDay: number,
    customHours?: string[]
): Promise<void> => {
    console.log('[reminderPersistence] Saving reminder (Auth):', {
        userId,
        reminderId,
        enabled,
        timesPerDay,
    });

    try {
        const docId = `${userId}_${reminderId}`;
        const docRef = doc(db, 'userReminderSettings', docId);

        const data: UserReminderSettings = {
            user_id: userId,
            reminder_id: reminderId,
            enabled,
            times_per_day: timesPerDay,
            custom_hours: customHours,
            last_modified: new Date(),
        };

        await setDoc(docRef, data, { merge: true });

        console.log('[reminderPersistence] ✅ Saved reminder (Auth)');
    } catch (error) {
        console.error('[reminderPersistence] Error saving reminder (Auth):', error);
        throw error;
    }
};

/**
 * Load all reminder settings (Auth - Firestore)
 */
export const loadReminderSettingsAuth = async (userId: string): Promise<ReminderSettingsData> => {
    console.log('[reminderPersistence] Loading reminders (Auth) for:', userId);

    try {
        const q = query(
            collection(db, 'userReminderSettings'),
            where('user_id', '==', userId)
        );

        const snapshot = await getDocs(q);
        const settings: ReminderSettingsData = {};

        snapshot.docs.forEach(doc => {
            const data = doc.data() as UserReminderSettings;
            settings[data.reminder_id] = {
                enabled: data.enabled,
                timesPerDay: data.times_per_day,
                customHours: data.custom_hours,
                lastModified: data.last_modified.toString(),
            };
        });

        console.log('[reminderPersistence] Loaded', Object.keys(settings).length, 'reminders (Auth)');

        return settings;
    } catch (error) {
        console.error('[reminderPersistence] Error loading reminders (Auth):', error);
        return {};
    }
};

/**
 * Migrate Guest settings to Auth on login
 */
export const migrateReminderSettingsToAuth = async (userId: string): Promise<void> => {
    console.log('[reminderPersistence] Migrating reminders Guest → Auth for:', userId);

    try {
        // Load Guest settings
        const guestSettings = await loadReminderSettingsGuest();
        const count = Object.keys(guestSettings).length;

        if (count === 0) {
            console.log('[reminderPersistence] No Guest settings to migrate');
            return;
        }

        // Migrate each setting
        let migrated = 0;
        for (const [reminderId, setting] of Object.entries(guestSettings)) {
            await saveReminderSettingAuth(
                userId,
                reminderId,
                setting.enabled,
                setting.timesPerDay,
                setting.customHours
            );
            migrated++;
        }

        console.log('[reminderPersistence] ✅ Migrated', migrated, 'reminders to Auth');

        // Clear Guest storage after migration
        await AsyncStorage.removeItem(STORAGE_KEYS.REMINDER_SETTINGS);
    } catch (error) {
        console.error('[reminderPersistence] Error migrating reminders:', error);
    }
};

// ============================================================================
// TASK STATUSES
// ============================================================================

/**
 * Task status structure (Guest)
 */
export interface TaskStatusData {
    [key: string]: { // key = `${taskId}_w${weekNumber}`
        completed: boolean;
        completedAt?: string; // ISO date
    };
}

/**
 * Save task status (Guest - AsyncStorage)
 */
export const saveTaskStatusGuest = async (
    taskId: string,
    weekNumber: number,
    completed: boolean
): Promise<void> => {
    console.log('[reminderPersistence] Saving task (Guest):', {
        taskId,
        weekNumber,
        completed,
    });

    try {
        // Load existing
        const existing = await loadTaskStatusesGuest();

        // Update
        const key = `${taskId}_w${weekNumber}`;
        existing[key] = {
            completed,
            completedAt: completed ? new Date().toISOString() : undefined,
        };

        // Save
        await AsyncStorage.setItem(
            STORAGE_KEYS.TASK_STATUSES,
            JSON.stringify(existing)
        );

        console.log('[reminderPersistence] ✅ Saved task (Guest)');
    } catch (error) {
        console.error('[reminderPersistence] Error saving task (Guest):', error);
        throw error;
    }
};

/**
 * Load all task statuses (Guest - AsyncStorage)
 */
export const loadTaskStatusesGuest = async (): Promise<TaskStatusData> => {
    console.log('[reminderPersistence] Loading tasks (Guest)...');

    try {
        const data = await AsyncStorage.getItem(STORAGE_KEYS.TASK_STATUSES);

        if (!data) {
            console.log('[reminderPersistence] No Guest task statuses found');
            return {};
        }

        const parsed = JSON.parse(data);
        console.log('[reminderPersistence] Loaded', Object.keys(parsed).length, 'task statuses (Guest)');

        return parsed;
    } catch (error) {
        console.error('[reminderPersistence] Error loading tasks (Guest):', error);
        return {};
    }
};

/**
 * Save task status (Auth - Firestore)
 */
export const saveTaskStatusAuth = async (
    userId: string,
    taskId: string,
    weekNumber: number,
    completed: boolean
): Promise<void> => {
    console.log('[reminderPersistence] Saving task (Auth):', {
        userId,
        taskId,
        weekNumber,
        completed,
    });

    try {
        const docId = `${userId}_${taskId}_w${weekNumber}`;
        const docRef = doc(db, 'userTaskStatuses', docId);

        const data: UserTaskStatus = {
            user_id: userId,
            task_id: taskId,
            week_number: weekNumber,
            completed,
            completed_at: completed ? new Date() : undefined,
        };

        await setDoc(docRef, data, { merge: true });

        console.log('[reminderPersistence] ✅ Saved task (Auth)');
    } catch (error) {
        console.error('[reminderPersistence] Error saving task (Auth):', error);
        throw error;
    }
};

/**
 * Load task statuses for a specific week (Auth - Firestore)
 */
export const loadTaskStatusesAuth = async (
    userId: string,
    weekNumber: number
): Promise<TaskStatusData> => {
    console.log('[reminderPersistence] Loading tasks (Auth) for week:', weekNumber);

    try {
        const q = query(
            collection(db, 'userTaskStatuses'),
            where('user_id', '==', userId),
            where('week_number', '==', weekNumber)
        );

        const snapshot = await getDocs(q);
        const statuses: TaskStatusData = {};

        snapshot.docs.forEach(doc => {
            const data = doc.data() as UserTaskStatus;
            const key = `${data.task_id}_w${data.week_number}`;
            statuses[key] = {
                completed: data.completed,
                completedAt: data.completed_at?.toString(),
            };
        });

        console.log('[reminderPersistence] Loaded', Object.keys(statuses).length, 'task statuses (Auth)');

        return statuses;
    } catch (error) {
        console.error('[reminderPersistence] Error loading tasks (Auth):', error);
        return {};
    }
};

/**
 * Migrate Guest task statuses to Auth on login
 */
export const migrateTaskStatusesToAuth = async (userId: string): Promise<void> => {
    console.log('[reminderPersistence] Migrating task statuses Guest → Auth for:', userId);

    try {
        // Load Guest statuses
        const guestStatuses = await loadTaskStatusesGuest();
        const count = Object.keys(guestStatuses).length;

        if (count === 0) {
            console.log('[reminderPersistence] No Guest task statuses to migrate');
            return;
        }

        // Migrate each status
        let migrated = 0;
        for (const [key, status] of Object.entries(guestStatuses)) {
            // Parse key: taskId_wWeekNumber
            const match = key.match(/(.+)_w(\d+)/);
            if (!match) continue;

            const taskId = match[1];
            const weekNumber = parseInt(match[2]);

            await saveTaskStatusAuth(
                userId,
                taskId,
                weekNumber,
                status.completed
            );
            migrated++;
        }

        console.log('[reminderPersistence] ✅ Migrated', migrated, 'task statuses to Auth');

        // Clear Guest storage after migration
        await AsyncStorage.removeItem(STORAGE_KEYS.TASK_STATUSES);
    } catch (error) {
        console.error('[reminderPersistence] Error migrating task statuses:', error);
    }
};

// ============================================================================
// BABY MESSAGE SETTINGS
// ============================================================================

/**
 * Save baby message enabled setting
 */
export const saveBabyMessageEnabled = async (enabled: boolean): Promise<void> => {
    console.log('[reminderPersistence] Saving baby message enabled:', enabled);

    try {
        await AsyncStorage.setItem(
            STORAGE_KEYS.BABY_MESSAGE_ENABLED,
            JSON.stringify(enabled)
        );
        console.log('[reminderPersistence] ✅ Saved baby message setting');
    } catch (error) {
        console.error('[reminderPersistence] Error saving baby message setting:', error);
    }
};

/**
 * Load baby message enabled setting
 */
export const loadBabyMessageEnabled = async (): Promise<boolean> => {
    console.log('[reminderPersistence] Loading baby message enabled...');

    try {
        const data = await AsyncStorage.getItem(STORAGE_KEYS.BABY_MESSAGE_ENABLED);
        const enabled = data ? JSON.parse(data) : true; // Default: true

        console.log('[reminderPersistence] Baby message enabled:', enabled);
        return enabled;
    } catch (error) {
        console.error('[reminderPersistence] Error loading baby message setting:', error);
        return true; // Default: true
    }
};

/**
 * Save baby message hour
 */
export const saveBabyMessageHour = async (hour: number): Promise<void> => {
    console.log('[reminderPersistence] Saving baby message hour:', hour);

    try {
        await AsyncStorage.setItem(
            STORAGE_KEYS.BABY_MESSAGE_HOUR,
            JSON.stringify(hour)
        );
        console.log('[reminderPersistence] ✅ Saved baby message hour');
    } catch (error) {
        console.error('[reminderPersistence] Error saving baby message hour:', error);
    }
};

/**
 * Load baby message hour
 */
export const loadBabyMessageHour = async (): Promise<number> => {
    console.log('[reminderPersistence] Loading baby message hour...');

    try {
        const data = await AsyncStorage.getItem(STORAGE_KEYS.BABY_MESSAGE_HOUR);
        const hour = data ? JSON.parse(data) : 10; // Default: 10:00

        console.log('[reminderPersistence] Baby message hour:', hour);
        return hour;
    } catch (error) {
        console.error('[reminderPersistence] Error loading baby message hour:', error);
        return 10; // Default: 10:00
    }
};

// ============================================================================
// MIGRATION ON LOGIN
// ============================================================================

/**
 * Migrate all Guest data to Auth on login
 */
export const migrateAllGuestDataToAuth = async (userId: string): Promise<void> => {
    console.log('[reminderPersistence] 🚀 Starting full migration Guest → Auth for:', userId);

    try {
        await Promise.all([
            migrateReminderSettingsToAuth(userId),
            migrateTaskStatusesToAuth(userId),
        ]);

        console.log('[reminderPersistence] ✅ Full migration complete');
    } catch (error) {
        console.error('[reminderPersistence] Error during full migration:', error);
    }
};
