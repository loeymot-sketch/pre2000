import { collection, addDoc, getDocs, query, where, updateDoc, deleteDoc, doc, Timestamp, orderBy } from 'firebase/firestore';
import { db } from '../config/firebase';
import { UserTask } from '../types';

/**
 * Task Service - Manage user-created custom tasks
 * Tasks are stored in Firestore 'userTasks' collection
 */

/**
 * Create a new task for the user
 */
export const createTask = async (
    userId: string,
    title: string,
    priority: 'high' | 'medium' | 'low' = 'medium'
): Promise<UserTask> => {
    try {
        const now = new Date();
        const taskData = {
            user_id: userId,
            title: title.trim(),
            priority,
            completed: false,
            created_at: Timestamp.fromDate(now),
            updated_at: Timestamp.fromDate(now),
        };

        const tasksRef = collection(db, 'userTasks');
        const docRef = await addDoc(tasksRef, taskData);

        return {
            task_id: docRef.id,
            user_id: userId,
            title: taskData.title,
            priority: taskData.priority,
            completed: taskData.completed,
            created_at: now,
            updated_at: now,
        };
    } catch (error) {
        console.error('[taskService] ❌ Error creating task:', error);
        throw error;
    }
};

/**
 * Get all tasks for a user
 * Returns tasks sorted by: incomplete first, then by priority (high → low)
 */
export const getUserTasks = async (userId: string): Promise<UserTask[]> => {
    try {
        const tasksRef = collection(db, 'userTasks');
        const q = query(
            tasksRef,
            where('user_id', '==', userId),
            orderBy('completed', 'asc'),  // Incomplete first
            orderBy('created_at', 'desc')  // Newest first
        );

        const snapshot = await getDocs(q);

        const tasks: UserTask[] = snapshot.docs.map(doc => {
            const data = doc.data();
            return {
                task_id: doc.id,
                user_id: data.user_id,
                title: data.title,
                priority: data.priority,
                completed: data.completed,
                created_at: data.created_at?.toDate() || new Date(),
                updated_at: data.updated_at?.toDate() || new Date(),
                completed_at: data.completed_at?.toDate(),
            };
        });

        // Sort by priority within each completed group
        const incompleteTasks = tasks.filter(t => !t.completed).sort((a, b) => {
            const priorityOrder = { high: 0, medium: 1, low: 2 };
            return priorityOrder[a.priority] - priorityOrder[b.priority];
        });

        const completedTasks = tasks.filter(t => t.completed);

        const sortedTasks = [...incompleteTasks, ...completedTasks];


        return sortedTasks;
    } catch (error) {
        console.error('[taskService] ❌ Error fetching tasks:', error);
        // If index doesn't exist, fetch all and filter manually
        try {
            const tasksRef = collection(db, 'userTasks');
            const q = query(tasksRef, where('user_id', '==', userId));
            const snapshot = await getDocs(q);

            const tasks: UserTask[] = snapshot.docs.map(doc => {
                const data = doc.data();
                return {
                    task_id: doc.id,
                    user_id: data.user_id,
                    title: data.title,
                    priority: data.priority,
                    completed: data.completed,
                    created_at: data.created_at?.toDate() || new Date(),
                    updated_at: data.updated_at?.toDate() || new Date(),
                    completed_at: data.completed_at?.toDate(),
                };
            });


            return tasks;
        } catch (fallbackError) {
            console.error('[taskService] ❌ Fallback also failed:', fallbackError);
            return [];
        }
    }
};

/**
 * Update task completion status
 */
export const updateTaskStatus = async (
    taskId: string,
    completed: boolean
): Promise<void> => {


    try {
        const taskRef = doc(db, 'userTasks', taskId);
        const updateData: any = {
            completed,
            updated_at: Timestamp.fromDate(new Date()),
        };

        if (completed) {
            updateData.completed_at = Timestamp.fromDate(new Date());
        } else {
            // Remove completed_at if unchecking
            updateData.completed_at = null;
        }

        await updateDoc(taskRef, updateData);


    } catch (error) {
        console.error('[taskService] ❌ Error updating task status:', error);
        throw error;
    }
};

/**
 * Delete a task
 */
export const deleteTask = async (taskId: string): Promise<void> => {
    try {
        const taskRef = doc(db, 'userTasks', taskId);
        await deleteDoc(taskRef);


    } catch (error) {
        console.error('[taskService] ❌ Error deleting task:', error);
        throw error;
    }
};
