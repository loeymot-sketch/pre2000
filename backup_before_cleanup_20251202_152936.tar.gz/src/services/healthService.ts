import { db } from '../config/firebase';
import { collection, addDoc, getDocs, query, where, orderBy, Timestamp } from 'firebase/firestore';
import { HealthMetric, HealthStats } from '../types';
import { loadUserEvents } from './calendarService';
import { loadReminderSettingsAuth, loadTaskStatusesAuth } from './reminderPersistence';

/**
 * healthService.ts
 * Service pour la gestion des métriques de santé (poids, tension artérielle)
 */

// ========================================
// WEIGHT TRACKING
// ========================================

export const saveWeightEntry = async (
    userId: string,
    weight: number,
    date: Date,
    week: number,
    notes?: string
): Promise<string> => {
    try {
        const docRef = await addDoc(collection(db, 'healthMetrics'), {
            user_id: userId,
            type: 'weight',
            value: weight,
            date: date.toISOString(),
            week,
            notes: notes || '',
            created_at: Timestamp.now().toDate().toISOString(),
        });
        return docRef.id;
    } catch (error) {
        console.error('[healthService] Error saving weight entry:', error);
        throw error;
    }
};

export const getWeightHistory = async (userId: string): Promise<HealthMetric[]> => {
    try {
        const q = query(
            collection(db, 'healthMetrics'),
            where('user_id', '==', userId),
            where('type', '==', 'weight'),
            orderBy('date', 'asc')
        );
        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => ({
            metric_id: doc.id,
            ...doc.data(),
        } as HealthMetric));
    } catch (error) {
        console.error('[healthService] Error fetching weight history:', error);
        return [];
    }
};

// ========================================
// BLOOD PRESSURE TRACKING
// ========================================

export const saveBloodPressureEntry = async (
    userId: string,
    systolic: number,
    diastolic: number,
    date: Date,
    week: number,
    notes?: string
): Promise<string> => {
    try {
        const docRef = await addDoc(collection(db, 'healthMetrics'), {
            user_id: userId,
            type: 'blood_pressure',
            value: { systolic, diastolic },
            date: date.toISOString(),
            week,
            notes: notes || '',
            created_at: Timestamp.now().toDate().toISOString(),
        });
        return docRef.id;
    } catch (error) {
        console.error('[healthService] Error saving BP entry:', error);
        throw error;
    }
};

export const getBloodPressureHistory = async (userId: string): Promise<HealthMetric[]> => {
    try {
        const q = query(
            collection(db, 'healthMetrics'),
            where('user_id', '==', userId),
            where('type', '==', 'blood_pressure'),
            orderBy('date', 'desc')
        );
        const snapshot = await getDocs(q);
        return snapshot.docs.map(doc => ({
            metric_id: doc.id,
            ...doc.data(),
        } as HealthMetric));
    } catch (error) {
        console.error('[healthService] Error fetching BP history:', error);
        return [];
    }
};

// ========================================
// STATS AGGREGATION
// ========================================

export const getHealthStats = async (userId: string, currentWeek: number): Promise<HealthStats> => {
    try {
        // Fetch weight history
        const weightHistory = await getWeightHistory(userId);
        const weightCurrent = weightHistory.length > 0 ? (weightHistory[weightHistory.length - 1].value as number) : undefined;
        const weightInitial = weightHistory.length > 0 ? (weightHistory[0].value as number) : undefined;
        const weightGain = weightCurrent && weightInitial ? weightCurrent - weightInitial : 0;

        // Fetch last BP
        const bpHistory = await getBloodPressureHistory(userId);
        const lastBP = bpHistory.length > 0
            ? {
                systolic: (bpHistory[0].value as { systolic: number; diastolic: number }).systolic,
                diastolic: (bpHistory[0].value as { systolic: number; diastolic: number }).diastolic,
                date: bpHistory[0].date,
            }
            : undefined;

        // Fetch appointments stats
        const appointments = await loadUserEvents(userId);
        const now = new Date();
        const upcomingAppointments = appointments.filter(a => new Date(a.date) >= now).length;
        const pastAppointments = appointments.filter(a => new Date(a.date) < now).length;

        // Fetch reminders stats
        const reminderSettings = await loadReminderSettingsAuth(userId);
        const taskStatuses = await loadTaskStatusesAuth(userId, currentWeek);
        const remindersCompletedThisWeek = Object.values(taskStatuses).filter(t => t.completed).length;
        const remindersTotalThisWeek = Object.keys(taskStatuses).length;

        return {
            weightCurrent,
            weightInitial,
            weightGain,
            lastBP,
            upcomingAppointments,
            pastAppointments,
            remindersCompletedThisWeek,
            remindersTotalThisWeek,
        };
    } catch (error) {
        console.error('[healthService] Error fetching health stats:', error);
        return {
            upcomingAppointments: 0,
            pastAppointments: 0,
            remindersCompletedThisWeek: 0,
            remindersTotalThisWeek: 0,
        };
    }
};
