import { collection, documentId, getDocs, query, where, doc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { Article, Supplement, ArticleAntigravity } from '../types';

export const getArticlesByIds = async (ids: string[]): Promise<Article[]> => {
    console.log(`[ContentService] 📚 Fetching ${ids.length} articles by IDs:`, ids);
    if (!ids || ids.length === 0) return [];

    // Firestore 'in' query is limited to 10 items. 
    // If we have more, we might need to batch or just fetch all (not efficient) or loop.
    // For now assuming < 10 recommendations per week.
    try {
        const q = query(collection(db, 'articles'), where(documentId(), 'in', ids));
        const snapshot = await getDocs(q);
        const articles = snapshot.docs.map(doc => doc.data() as Article);
        console.log(`[ContentService] ✅ Fetched ${articles.length}/${ids.length} articles`);
        return articles;
    } catch (error) {
        console.error('[ContentService] ❌ Error fetching articles:', error);
        return [];
    }
};

export const getSupplementsByIds = async (ids: string[]): Promise<Supplement[]> => {
    console.log(`[ContentService] 💊 Fetching ${ids.length} supplements by IDs:`, ids);
    if (!ids || ids.length === 0) return [];

    try {
        const q = query(collection(db, 'supplements'), where(documentId(), 'in', ids));
        const snapshot = await getDocs(q);
        const supplements = snapshot.docs.map(doc => doc.data() as Supplement);
        console.log(`[ContentService] ✅ Fetched ${supplements.length}/${ids.length} supplements`);
        return supplements;
    } catch (error) {
        console.error('[ContentService] ❌ Error fetching supplements:', error);
        return [];
    }
};

// ========== ANTIGRAVITY ARTICLES (Trilingual) ==========

/**
 * Get Antigravity article by ID
 */
export const getAntigravityArticle = async (articleId: string): Promise<ArticleAntigravity | null> => {
    console.log(`[ContentService] 📰 Fetching Antigravity article: ${articleId}`);

    try {
        const articleDoc = await getDoc(doc(db, 'articlesAntigravity', articleId));

        if (articleDoc.exists()) {
            const data = articleDoc.data() as ArticleAntigravity;
            console.log(`[ContentService] ✅ Found article: ${data.title_fr}`);
            return data;
        } else {
            console.warn(`[ContentService] ⚠️ Article not found: ${articleId}`);
            return null;
        }
    } catch (error) {
        console.error('[ContentService] ❌ Error fetching Antigravity article:', error);
        return null;
    }
};

/**
 * Get Antigravity articles by category
 */
export const getAntigravityArticlesByCategory = async (category: string): Promise<ArticleAntigravity[]> => {
    console.log(`[ContentService] 🏷️ Fetching Antigravity articles for category: ${category}`);

    try {
        const q = query(
            collection(db, 'articlesAntigravity'),
            where('category', '==', category)
        );

        const snapshot = await getDocs(q);
        const articles = snapshot.docs.map(doc => doc.data() as ArticleAntigravity);

        console.log(`[ContentService] ✅ Found ${articles.length} Antigravity articles in ${category}`);
        return articles;
    } catch (error) {
        console.error('[ContentService] ❌ Error fetching articles by category:', error);
        return [];
    }
};

/**
 * Get Antigravity articles for specific week range
 */
export const getAntigravityArticlesForWeek = async (week: number): Promise<ArticleAntigravity[]> => {
    console.log(`[ContentService] 📅 Fetching Antigravity articles for week ${week}`);

    try {
        const snapshot = await getDocs(collection(db, 'articlesAntigravity'));
        const articles = snapshot.docs
            .map(doc => doc.data() as ArticleAntigravity)
            .filter(article => week >= article.week_min && week <= article.week_max);

        console.log(`[ContentService] ✅ Found ${articles.length} articles for week ${week}`);
        return articles;
    } catch (error) {
        console.error('[ContentService] ❌ Error fetching articles for week:', error);
        return [];
    }
};
