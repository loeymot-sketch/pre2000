import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import { Platform } from 'react-native';

/**
 * Notification Service for V1.2
 * Handles local notifications for reminders and baby messages
 * No remote notifications - 100% local, 0 API cost
 */

// Configure notification handler
Notifications.setNotificationHandler({
    handleNotification: async () => {
        return {
            shouldShowAlert: true,
            shouldPlaySound: true,
            shouldSetBadge: true,
            shouldShowBanner: true,
            shouldShowList: true,
        };
    },
});

/**
 * Request notification permissions
 * iOS requires explicit permission, Android auto-grants
 */
export const requestNotificationPermissions = async (): Promise<boolean> => {
    console.log('[notificationService] Requesting permissions...');

    // Check if physical device
    if (!Device.isDevice) {
        console.warn('[notificationService] Notifications only work on physical devices');
        return false;
    }

    try {
        const { status: existingStatus } = await Notifications.getPermissionsAsync();
        console.log('[notificationService] Existing permission status:', existingStatus);

        let finalStatus = existingStatus;

        if (existingStatus !== 'granted') {
            const { status } = await Notifications.requestPermissionsAsync();
            finalStatus = status;
            console.log('[notificationService] New permission status:', finalStatus);
        }

        if (finalStatus !== 'granted') {
            console.warn('[notificationService] Notification permissions denied');
            return false;
        }

        // Setup notification channel for Android
        if (Platform.OS === 'android') {
            await Notifications.setNotificationChannelAsync('default', {
                name: 'Rappels de grossesse',
                importance: Notifications.AndroidImportance.MAX,
                vibrationPattern: [0, 250, 250, 250],
                lightColor: '#FF6B9D',
                sound: 'default',
            });
            console.log('[notificationService] Android channel configured');
        }

        console.log('[notificationService] ✅ Permissions granted');
        return true;
    } catch (error) {
        console.error('[notificationService] Error requesting permissions:', error);
        return false;
    }
};

/**
 * Schedule a single reminder notification
 */
export const scheduleReminderNotification = async (
    reminderId: string,
    title: string,
    body: string,
    hour: number,
    minute: number = 0
): Promise<string | null> => {
    console.log('[notificationService] Scheduling reminder:', {
        reminderId,
        title,
        hour,
        minute,
    });

    try {
        const notificationId = await Notifications.scheduleNotificationAsync({
            content: {
                title,
                body,
                data: {
                    type: 'reminder',
                    reminderId,
                },
                sound: 'default',
            },
            trigger: {
                type: Notifications.SchedulableTriggerInputTypes.CALENDAR,
                hour,
                minute,
                repeats: true, // Daily repeat
            } as Notifications.CalendarTriggerInput,
        });

        console.log('[notificationService] ✅ Scheduled notification:', notificationId);
        return notificationId;
    } catch (error) {
        console.error('[notificationService] Error scheduling notification:', error);
        return null;
    }
};

/**
 * Schedule multiple reminder notifications (for intensity 3/5/7)
 */
export const scheduleMultipleReminders = async (
    reminderId: string,
    title: string,
    bodyTemplate: string,
    hours: number[]
): Promise<string[]> => {
    console.log('[notificationService] Scheduling multiple reminders:', {
        reminderId,
        count: hours.length,
        hours,
    });

    const notificationIds: string[] = [];

    for (const hour of hours) {
        const body = bodyTemplate;
        const id = await scheduleReminderNotification(
            `${reminderId}_${hour}`,
            title,
            body,
            hour,
            0
        );

        if (id) {
            notificationIds.push(id);
        }
    }

    console.log('[notificationService] ✅ Scheduled', notificationIds.length, 'notifications');
    return notificationIds;
};

/**
 * Cancel all notifications for a specific reminder
 */
export const cancelReminderNotifications = async (reminderId: string): Promise<void> => {
    console.log('[notificationService] Canceling notifications for:', reminderId);

    try {
        const scheduled = await Notifications.getAllScheduledNotificationsAsync();

        // Filter notifications for this reminder
        const toCancel = scheduled.filter(
            notif => {
                const data = notif.content.data as any;
                return data?.reminderId === reminderId ||
                    (typeof data?.reminderId === 'string' && data.reminderId.startsWith(reminderId));
            }
        );

        console.log('[notificationService] Found', toCancel.length, 'notifications to cancel');

        for (const notif of toCancel) {
            await Notifications.cancelScheduledNotificationAsync(notif.identifier);
        }

        console.log('[notificationService] ✅ Canceled notifications for:', reminderId);
    } catch (error) {
        console.error('[notificationService] Error canceling notifications:', error);
    }
};

/**
 * Cancel all scheduled notifications
 */
export const cancelAllNotifications = async (): Promise<void> => {
    console.log('[notificationService] Canceling ALL notifications...');

    try {
        await Notifications.cancelAllScheduledNotificationsAsync();
        console.log('[notificationService] ✅ All notifications canceled');
    } catch (error) {
        console.error('[notificationService] Error canceling all notifications:', error);
    }
};

/**
 * Get all scheduled notifications (for debugging)
 */
export const getScheduledNotifications = async () => {
    console.log('[notificationService] Fetching scheduled notifications...');

    try {
        const scheduled = await Notifications.getAllScheduledNotificationsAsync();
        console.log('[notificationService] Found', scheduled.length, 'scheduled notifications');

        return scheduled.map(notif => ({
            id: notif.identifier,
            title: notif.content.title,
            body: notif.content.body,
            trigger: notif.trigger,
            data: notif.content.data,
        }));
    } catch (error) {
        console.error('[notificationService] Error fetching notifications:', error);
        return [];
    }
};

/**
 * Schedule daily baby message notification
 */
export const scheduleBabyMessage = async (
    message: string,
    emoji: string,
    hour: number = 10,
    minute: number = 0
): Promise<string | null> => {
    console.log('[notificationService] Scheduling baby message:', {
        message: message.substring(0, 50) + '...',
        hour,
        minute,
    });

    try {
        // Cancel existing baby message
        await cancelBabyMessage();

        const notificationId = await Notifications.scheduleNotificationAsync({
            content: {
                title: `${emoji} Message de bébé`,
                body: message,
                data: {
                    type: 'baby_message',
                },
                sound: 'default',
            },
            trigger: {
                type: Notifications.SchedulableTriggerInputTypes.CALENDAR,
                hour,
                minute,
                repeats: true, // Daily
            } as Notifications.CalendarTriggerInput,
        });

        console.log('[notificationService] ✅ Baby message scheduled:', notificationId);
        return notificationId;
    } catch (error) {
        console.error('[notificationService] Error scheduling baby message:', error);
        return null;
    }
};

/**
 * Cancel baby message notification
 */
export const cancelBabyMessage = async (): Promise<void> => {
    console.log('[notificationService] Canceling baby message...');

    try {
        const scheduled = await Notifications.getAllScheduledNotificationsAsync();
        const babyMessages = scheduled.filter(
            notif => notif.content.data?.type === 'baby_message'
        );

        for (const notif of babyMessages) {
            await Notifications.cancelScheduledNotificationAsync(notif.identifier);
        }

        console.log('[notificationService] ✅ Baby message canceled');
    } catch (error) {
        console.error('[notificationService] Error canceling baby message:', error);
    }
};

/**
 * Test notification (for debugging)
 */
export const sendTestNotification = async (): Promise<void> => {
    console.log('[notificationService] Sending test notification...');

    try {
        await Notifications.scheduleNotificationAsync({
            content: {
                title: "Test Notification 🧪",
                body: "Maman, c'est un test ! Les notifications fonctionnent 💕",
                data: { type: 'test' },
            },
            trigger: {
                type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
                seconds: 2,
            } as Notifications.TimeIntervalTriggerInput,
        });

        console.log('[notificationService] ✅ Test notification scheduled');
    } catch (error) {
        console.error('[notificationService] Error sending test notification:', error);
    }
};
