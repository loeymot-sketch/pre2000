import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';
import { BabyMessage } from '../types';
import { scheduleBabyMessage, cancelBabyMessage } from './notificationService';
import { loadBabyMessageEnabled, loadBabyMessageHour } from './reminderPersistence';

/**
 * Baby Message Service for V1.2
 * Handles daily baby messages adapted to pregnancy week
 */

/**
 * Fetch all baby messages for a specific week
 */
export const getBabyMessagesForWeek = async (weekNumber: number): Promise<BabyMessage[]> => {
    console.log('[babyMessageService] Fetching messages for week:', weekNumber);

    try {
        const q = query(
            collection(db, 'babyMessages'),
            where('week', '==', weekNumber)
        );

        const snapshot = await getDocs(q);
        const messages = snapshot.docs.map(doc => doc.data() as BabyMessage);

        console.log('[babyMessageService] Found', messages.length, 'messages for week', weekNumber);
        return messages;
    } catch (error) {
        console.error('[babyMessageService] Error fetching messages:', error);
        return [];
    }
};

/**
 * Get today's baby message for the current week
 * Uses day of week (0-6) to pick message
 */
export const getTodaysBabyMessage = async (weekNumber: number): Promise<BabyMessage | null> => {
    console.log('[babyMessageService] Getting today\'s message for week:', weekNumber);

    try {
        const messages = await getBabyMessagesForWeek(weekNumber);

        if (messages.length === 0) {
            console.warn('[babyMessageService] No messages found for week', weekNumber);
            return null;
        }

        // Get current day of week (0 = Sunday, 1 = Monday, etc.)
        const today = new Date().getDay();

        // Try to find message for today (day 1-7 in our data = Sunday-Saturday)
        const dayNumber = today === 0 ? 7 : today; // Convert Sunday from 0 to 7
        let message = messages.find(m => m.day === dayNumber);

        // Fallback: pick random message if exact day not found
        if (!message) {
            const randomIndex = Math.floor(Math.random() * messages.length);
            message = messages[randomIndex];
            console.log('[babyMessageService] Day', dayNumber, 'not found, using random message');
        }

        console.log('[babyMessageService] Selected message:', message.message_id);
        return message;
    } catch (error) {
        console.error('[babyMessageService] Error getting today\'s message:', error);
        return null;
    }
};

/**
 * Get baby message for specific week and day
 * Similar to getTipForDay for consistency
 */
export const getMessageForDay = async (week: number, day: number): Promise<BabyMessage | null> => {
    console.log(`[babyMessageService] 💝 Fetching message for Week ${week}, Day ${day}`);

    try {
        const messages = await getBabyMessagesForWeek(week);

        if (messages.length === 0) {
            console.warn(`[babyMessageService] ⚠️  No messages found for week ${week}`);
            return null;
        }

        // Find message for specific day (1-7)
        let message = messages.find(m => m.day === day);

        // Fallback: use first message if specific day not found
        if (!message) {
            message = messages[0];
            console.log(`[babyMessageService] ⚠️  Day ${day} not found, using first message`);
        }

        console.log(`[babyMessageService] ✅ Found message: ${message.message_id}`);
        return message;
    } catch (error) {
        console.error('[babyMessageService] ❌ Error fetching message:', error);
        return null;
    }
};

/**
 * Schedule today's baby message notification
 * Called on app start and when settings change
 */
export const scheduleTodaysBabyMessage = async (weekNumber: number): Promise<void> => {
    console.log('[babyMessageService] Scheduling today\'s baby message for week:', weekNumber);

    try {
        // Check if enabled
        const enabled = await loadBabyMessageEnabled();
        if (!enabled) {
            console.log('[babyMessageService] Baby messages disabled, skipping');
            return;
        }

        // Get message
        const message = await getTodaysBabyMessage(weekNumber);
        if (!message) {
            console.warn('[babyMessageService] No message to schedule');
            return;
        }

        // Get hour setting
        const hour = await loadBabyMessageHour();

        // Schedule notification
        await scheduleBabyMessage(
            message.message_fr,
            message.emoji,
            hour,
            0 // minute
        );

        console.log('[babyMessageService] ✅ Scheduled baby message for', hour, ':00');
    } catch (error) {
        console.error('[babyMessageService] Error scheduling message:', error);
    }
};

/**
 * Cancel baby message notification
 * Called when user disables in settings
 */
export const cancelBabyMessageNotification = async (): Promise<void> => {
    console.log('[babyMessageService] Canceling baby message...');

    try {
        await cancelBabyMessage();
        console.log('[babyMessageService] ✅ Baby message canceled');
    } catch (error) {
        console.error('[babyMessageService] Error canceling message:', error);
    }
};

/**
 * Update baby message schedule
 * Called when user changes hour in settings
 */
export const updateBabyMessageSchedule = async (
    weekNumber: number,
    enabled: boolean,
    hour: number
): Promise<void> => {
    console.log('[babyMessageService] Updating baby message schedule:', {
        weekNumber,
        enabled,
        hour,
    });

    try {
        if (!enabled) {
            await cancelBabyMessageNotification();
            return;
        }

        // Reschedule with new hour
        await cancelBabyMessageNotification();

        const message = await getTodaysBabyMessage(weekNumber);
        if (message) {
            await scheduleBabyMessage(message.message_fr, message.emoji, hour, 0);
            console.log('[babyMessageService] ✅ Rescheduled for', hour, ':00');
        }
    } catch (error) {
        console.error('[babyMessageService] Error updating schedule:', error);
    }
};

/**
 * Initialize baby message on app start
 * Should be called in App.tsx or main component
 */
export const initializeBabyMessage = async (weekNumber: number): Promise<void> => {
    console.log('[babyMessageService] 🚀 Initializing baby message for week:', weekNumber);

    try {
        const enabled = await loadBabyMessageEnabled();

        if (enabled) {
            await scheduleTodaysBabyMessage(weekNumber);
        } else {
            console.log('[babyMessageService] Baby messages disabled');
        }
    } catch (error) {
        console.error('[babyMessageService] Error initializing:', error);
    }
};
