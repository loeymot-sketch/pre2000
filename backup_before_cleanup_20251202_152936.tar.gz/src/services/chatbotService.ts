import { collection, getDocs, doc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { RedFlag, Article, ChatbotSuggestion } from '../types';

export interface ChatResponse {
    type: 'red_flag' | 'suggestion' | 'info' | 'unknown';
    message: string;
    redFlag?: RedFlag;
    articles?: Article[];
    suggestions?: ChatbotSuggestion[];
    matchScore?: number;
}

const SEVERITY_PRIORITY: Record<string, number> = {
    'critique': 3,
    'élevé': 2,
    'modéré': 1,
    'faible': 0,
};

/**
 * Enhanced chatbot with 3-tier matching:
 * 1. Red Flags (critical symptoms)
 * 2. Chatbot Suggestions (topic-based with multi-keyword matching)
 * 3. Articles (general information)
 * 4. Neutral Fallback (no hallucination)
 */
export const analyzeMessage = async (text: string): Promise<ChatResponse> => {
    const lowerText = text.toLowerCase().trim();
    const userWords = lowerText.split(/\s+/).filter(w => w.length > 2); // Ignore short words

    console.log('📩 User message:', text);
    console.log('🔍 Extracted words:', userWords);

    // ========== TIER 1: RED FLAGS (CRITICAL) ==========
    try {
        const redFlagsSnapshot = await getDocs(collection(db, 'redFlags'));
        const redFlags = redFlagsSnapshot.docs.map(doc => doc.data() as RedFlag);
        const matchedFlags: { flag: RedFlag; score: number }[] = [];

        for (const flag of redFlags) {
            const keywords = flag.keywords_fr.split(',').map(k => k.trim().toLowerCase());

            // Multi-keyword matching with partial match support
            let matchCount = 0;
            keywords.forEach(keyword => {
                if (userWords.some(word => word.includes(keyword) || keyword.includes(word))) {
                    matchCount++;
                }
            });

            if (matchCount > 0) {
                const severityScore = SEVERITY_PRIORITY[flag.severity?.toLowerCase() || 'faible'] || 0;
                const score = (matchCount * 10) + (severityScore * 5); // Boost severity weight
                matchedFlags.push({ flag, score });
                console.log(`🚩 Red flag matched: ${flag.red_flag_id}, severity: ${flag.severity}, matches: ${matchCount}, score: ${score}`);
            }
        }

        if (matchedFlags.length > 0) {
            matchedFlags.sort((a, b) => b.score - a.score);
            const topFlag = matchedFlags[0].flag;

            console.log(`⚠️  Selected red flag: ${topFlag.red_flag_id} (score: ${matchedFlags[0].score})`);

            // Fetch linked articles
            const linkedArticles: Article[] = [];
            if (topFlag.linked_articles_ids && topFlag.linked_articles_ids.length > 0) {
                for (const articleId of topFlag.linked_articles_ids.slice(0, 3)) {
                    try {
                        const articleDoc = await getDoc(doc(db, 'articles', articleId));
                        if (articleDoc.exists()) {
                            linkedArticles.push(articleDoc.data() as Article);
                        }
                    } catch (err) {
                        console.error(`Failed to fetch article ${articleId}:`, err);
                    }
                }
            }

            return {
                type: 'red_flag',
                message: topFlag.standard_message_fr || "⚠️ Attention, ce symptôme nécessite une vigilance particulière. Consultez rapidement un professionnel de santé.",
                redFlag: topFlag,
                articles: linkedArticles,
                matchScore: matchedFlags[0].score,
            };
        }
    } catch (error) {
        console.error('❌ Error checking red flags:', error);
    }

    // ========== TIER 2: CHATBOT SUGGESTIONS (TOPIC-BASED) ==========
    try {
        const suggestionsSnapshot = await getDocs(collection(db, 'chatbotSuggestionsAG'));
        const suggestions = suggestionsSnapshot.docs.map(doc => doc.data() as ChatbotSuggestion);
        const matchedSuggestions: { suggestion: ChatbotSuggestion; score: number }[] = [];

        for (const suggestion of suggestions) {
            const labelWords = suggestion.label_fr.toLowerCase().split(/\s+/);
            const topicWords = suggestion.topic.toLowerCase().split(/\s+/);

            let score = 0;

            // Score by label match (high weight)
            userWords.forEach(userWord => {
                if (labelWords.some(w => w.includes(userWord) || userWord.includes(w))) {
                    score += 10;
                }
            });

            // Score by topic match (medium weight)
            userWords.forEach(userWord => {
                if (topicWords.some(w => w.includes(userWord) || userWord.includes(w))) {
                    score += 5;
                }
            });

            // Exact phrase match bonus
            if (lowerText.includes(suggestion.label_fr.toLowerCase())) {
                score += 20;
            }

            if (score > 0) {
                matchedSuggestions.push({ suggestion, score });
                console.log(`💡 Suggestion matched: ${suggestion.suggestion_id}, score: ${score}`);
            }
        }

        if (matchedSuggestions.length > 0) {
            matchedSuggestions.sort((a, b) => b.score - a.score);
            const topSuggestion = matchedSuggestions[0].suggestion;

            console.log(`✅ Selected suggestion: ${topSuggestion.suggestion_id} (score: ${matchedSuggestions[0].score})`);

            // Fetch linked articles
            const linkedArticles: Article[] = [];
            if (topSuggestion.linked_article_ids && typeof topSuggestion.linked_article_ids === 'string') {
                const articleIds = topSuggestion.linked_article_ids.split(',').map((id: string) => id.trim());
                for (const articleId of articleIds.slice(0, 3)) {
                    try {
                        const articleDoc = await getDoc(doc(db, 'articles', articleId));
                        if (articleDoc.exists()) {
                            linkedArticles.push(articleDoc.data() as Article);
                        }
                    } catch (err) {
                        console.error(`Failed to fetch article ${articleId}:`, err);
                    }
                }
            }

            // Fetch linked red flags (if any)
            const linkedRedFlags: RedFlag[] = [];
            if (topSuggestion.linked_red_flag_ids && typeof topSuggestion.linked_red_flag_ids === 'string') {
                const redFlagIds = topSuggestion.linked_red_flag_ids.split(',').map((id: string) => id.trim());
                for (const redFlagId of redFlagIds.slice(0, 2)) {
                    try {
                        const redFlagDoc = await getDoc(doc(db, 'redFlags', redFlagId));
                        if (redFlagDoc.exists()) {
                            linkedRedFlags.push(redFlagDoc.data() as RedFlag);
                        }
                    } catch (err) {
                        console.error(`Failed to fetch red flag ${redFlagId}:`, err);
                    }
                }
            }

            // Build response message
            let message = "Voici ce que je peux vous dire :";
            if (linkedRedFlags.length > 0) {
                message = "⚠️ Attention : " + linkedRedFlags[0].standard_message_fr;
            } else if (linkedArticles.length > 0) {
                message = "Ces articles peuvent vous aider :";
            }

            return {
                type: 'suggestion',
                message,
                articles: linkedArticles,
                suggestions: [topSuggestion],
                redFlag: linkedRedFlags[0],
                matchScore: matchedSuggestions[0].score,
            };
        }
    } catch (error) {
        console.error('❌ Error checking suggestions:', error);
    }

    // ========== TIER 3: ARTICLES (GENERAL INFO) ==========
    try {
        const articlesSnapshot = await getDocs(collection(db, 'articles'));
        const articles = articlesSnapshot.docs.map(doc => doc.data() as Article);
        const matchedArticles: { article: Article; score: number }[] = [];

        for (const article of articles) {
            let score = 0;
            const titleWords = article.title_fr.toLowerCase().split(/\s+/);
            const categoryWords = article.category.toLowerCase().split(/\s+/);
            const summaryWords = article.summary_fr.toLowerCase().split(/\s+/);

            // Score by matches
            userWords.forEach(userWord => {
                if (titleWords.some(w => w.includes(userWord) || userWord.includes(w))) score += 5;
                if (categoryWords.some(w => w.includes(userWord) || userWord.includes(w))) score += 3;
                if (summaryWords.some(w => w.includes(userWord) || userWord.includes(w))) score += 1;
            });

            if (score > 0) {
                matchedArticles.push({ article, score });
            }
        }

        if (matchedArticles.length > 0) {
            matchedArticles.sort((a, b) => b.score - a.score);
            const topArticles = matchedArticles.slice(0, 3).map(m => m.article);

            console.log(`📚 Found ${topArticles.length} articles:`, topArticles.map(a => a.article_id));

            return {
                type: 'info',
                message: "Je ne peux pas poser de diagnostic, mais ces articles peuvent vous aider :",
                articles: topArticles,
                matchScore: matchedArticles[0].score,
            };
        }
    } catch (error) {
        console.error('❌ Error searching articles:', error);
    }

    // ========== TIER 4: NEUTRAL FALLBACK (NO HALLUCINATION) ==========
    console.log('❓ No match found, returning neutral fallback');
    return {
        type: 'unknown',
        message: "Je ne suis pas sûre de bien comprendre votre question. Pour votre sécurité, je vous recommande de consulter un professionnel de santé qui pourra vous répondre de manière personnalisée. 💙",
        matchScore: 0,
    };
};

export const fetchSuggestions = async (): Promise<ChatbotSuggestion[]> => {
    try {
        const snapshot = await getDocs(collection(db, 'chatbotSuggestionsAG'));
        return snapshot.docs.map(doc => doc.data() as ChatbotSuggestion);
    } catch (error) {
        console.error('Error fetching suggestions:', error);
        return [];
    }
};
